﻿using System;
using System.Drawing;
using System.Windows.Forms;
using PIA.DpmCtrlLib;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;

namespace TestDPMCtrl
{
    public partial class Mainform : Form
    {
        #region Member Vars
        PIA.DpmCtrlLib.DPMControl _DPMControl;
        PIA.DpmCtrlLib.IDPMDevice _IDPMDevice;
        PIA.DpmCtrlLib.IDPMDeviceSettings _IDPMDeviceSettings;
        PIA.DpmCtrlLib.IDPMDeviceCapabilities _IDPMDeviceCapabilites;
        PIA.DpmCtrlLib.IDPMFileInfo _IDPMFileInfo;
        PIA.DpmCtrlLib.IDPMFileList _IDPMFileList;
        string _BarcodeLayout;
        object _BarcodePrefix, _BarcodePostfix;
        #endregion
        #region Initializations
        public Mainform()
        {
            InitializeComponent();
            // current instance (maintained for OnThreadException)
            Instance = this;
            _DPMControl = new PIA.DpmCtrlLib.DPMControl();

            SetDeviceConfigUITags();
            FillComboBoxItems();

            _DPMControl.DPMEventBarcodeScanned += new _DDPMControlEvents_DPMEventBarcodeScannedEventHandler(_DPMControl_DPMEventBarcodeScanned);
            _DPMControl.DPMEventBarcodeStringScanned += new _DDPMControlEvents_DPMEventBarcodeStringScannedEventHandler(_DPMControl_DPMEventBarcodeStringScanned);
            _DPMControl.DPMEventButton += new _DDPMControlEvents_DPMEventButtonEventHandler(_DPMControl_DPMEventButton);
            _DPMControl.DPMEventDeviceConnected += new _DDPMControlEvents_DPMEventDeviceConnectedEventHandler(_DPMControl_DPMEventDeviceConnected);
            _DPMControl.DPMEventDeviceDisconnected += new _DDPMControlEvents_DPMEventDeviceDisconnectedEventHandler(_DPMControl_DPMEventDeviceDisconnected);
            _DPMControl.DPMEventDeviceReady += new _DDPMControlEvents_DPMEventDeviceReadyEventHandler(_DPMControl_DPMEventDeviceReady);
            _DPMControl.DPMEventError += new _DDPMControlEvents_DPMEventErrorEventHandler(_DPMControl_DPMEventError);
            _DPMControl.DPMEventProgress += new _DDPMControlEvents_DPMEventProgressEventHandler(_DPMControl_DPMEventProgress);
            // initialize data grids showing barcode prefix/postfix
            SetBarcodeDataGridProperties();
            //_cbTrackball.Tag = _btnSetTrackball;
            
        }
        /// <summary>
        /// device configuration Set buttons added to concerning UI controls' tags
        /// </summary>
        private void SetDeviceConfigUITags()
        {
            cmbDDDisplaySymbol.Tag = btnDDDisplaySymbol;
            cmbDDenableLed.Tag = btnDDenableLed;
            cmbAppearance.Tag = btnDSAppearanceSet;
            cmbBarcodeMode.Tag = btnDSBarcodeModeSet;
            cmbBarcodeScanButton.Tag = btnDSBarCodeScanButtonSet;
            cmbDateTimeFormat.Tag = btnDSDateTimeFormatSet;
            cmbFileCounterSource.Tag = btnDSFileCounterSourceSet;
            cmbFileNamePrefixType.Tag = btnDSFileNamePrefixSet;
            cmbFourPosSwitch.Tag = btnDSFourPosSwitchSet;
            cmbFunctionKey.Tag = btnDSFunctionKeySet;
            cmbLowerArea.Tag = btnDSLowerAreaSet;
            cmbMicrophoneSensitivity.Tag = btnDSMicrophoneSensitivitySet;
            cmbOS.Tag = btnDSOsSet;
            cmbRecordingMode.Tag = btnDSRecordingModeSet;
            cmbRequiredInputType.Tag = btnDSRequiredInputTypeSet;
            cmbTotalTimeType.Tag = btnDSTotalTimeTypeSet;
            cbAppendMode.Tag = btnDSAppendModeSet;
            cbCueReviewSound.Tag = btnDSCueReviewSoundSet;
            cbDELButtonEnabled.Tag = btnDSDELButtonEnabledSet;
            cbDeleteFilesAfterDownload.Tag = btnDSDeleteFilesAfterDownloadSet;
            cbDeviceBeep.Tag = btnDSDeviceBeepSet;
            cbDLSButtonEnabled.Tag = btnDSDLSButtonEnabledSet;
            cbEnableUSBAudio.Tag = btnDSEnableUSBAudioSet;
            cbEOLButtonEnabled.Tag = btnDSEOLButtonEnabledSet;
            cbInsertButtonEnabled.Tag = btnDSInsertButtonEnabledSet;
            cbLinkKeywords.Tag = btnDSLinkKeywordsSet;
            cbNoiseReduction.Tag = btnDSNoiseReductionSet;
            cbOneFile.Tag = btnDSOneFileSet;
            cbPCMEnabled.Tag = btnDSPCMEnabledSet;
            cbProhibitFileAlteration.Tag = btnDSProhibitFileAlterationSet;
            cbProMode.Tag = btnDSProModeSet;
            cbProtectDevice.Tag = btnDSProtectDeviceSet;
            cbRecordLevelInd.Tag = btnDSRecordLevelSet;
            cbRecordNotify.Tag = btnDSRecordNotifySet;
            cbScanKeywordsFromBarcode.Tag = btnDSScanKeywordsFromBarcodeSet;
            cbUSBHighPowerMode.Tag = btnDSUSBHighPowerModeSet;
            cbVoiceActivation.Tag = btnDSVoiceActivationSet;
            cbKeywordBarcodeScan.Tag = btnKeywordBarcodeScanSet;
            cbKeywordMandatory.Tag = btnKeywordMandatorySet;
            cbKeywordVoiceCommand.Tag = btnDSKeywordVoiceCommandSet;
            cmbVoiceCommandType.Tag = btnDSVoiceCommandTypeSet;
            cbMassStorageWriteProtection.Tag = btnDSMassStorageWriteProtectionSet;
            cbObligatoryKeywordSelection.Tag = btnDSObligatoryKeywordSelectionSet;
            cbFIEOL.Tag = btnFIEOLSet;
            cbDSSPro256Enabled.Tag = btnDSSPro256EnabledSet;
            cbDisplaySymbolsEnabled.Tag = btnDisplaySymbolsEnabledSet;

            KeywordDisplayAreaStringsCombo.Tag = KeywordDisplayAreaStrings_SetButton;
            EditModeCombo.Tag = EditMode_SetButton;
            FootpedalModeCombo.Tag = FootpedalMode_SetButton;
            SmartButtonConfigurationCombo.Tag = SmartButtonConfiguration_SetButton;
            BacklightCombo.Tag = Backlight_SetButton;
            PlusButtonEnabledCheck.Tag = PlusButtonEnabled_SetButton;
            MinusButtonEnabledCheck.Tag = MinusButtonEnabled_SetButton;
            IsAuthorPinListUsedCheck.Tag = IsAuthorPinListUsed_SetButton;
            ActiveRecordingProfileCombo.Tag = ActiveRecordingProfile_SetButton;
            RecordingModeOnRecordingProfileCombo.Tag = RecordingModeOnRecordingProfile_SetButton;
            MicrophoneSensitivityOnRecordingProfileCombo.Tag = MicrophoneSensitivityOnRecordingProfile_SetButton;
            MicrophoneDirectivityOnRecordingProfileCombo.Tag = MicrophoneDirectivityOnRecordingProfile_SetButton;
        }

        /// <summary>
        /// Fill combo box items
        /// </summary>
        private void FillComboBoxItems()
        {
            FillComboBoxFromEnum(cmbAppearance, typeof(PIA.DpmCtrlLib.dpmAppearance));
            FillComboBoxFromEnum(cmbBarcodeMode, typeof(PIA.DpmCtrlLib.dpmBarcodeMode));
            FillComboBoxFromEnum(cmbBarcodeScanButton, typeof(PIA.DpmCtrlLib.dpmBarcodeScanButton));
            FillComboBoxFromEnum(cmbDateTimeFormat, typeof(PIA.DpmCtrlLib.dpmDateTimeFormat));
            FillComboBoxFromEnum(cmbFileCounterSource, typeof(PIA.DpmCtrlLib.dpmFileCounterSource));
            FillComboBoxFromEnum(cmbFileNamePrefixType, typeof(PIA.DpmCtrlLib.dpmFilenamePrefixType));
            FillComboBoxFromEnum(cmbFourPosSwitch, typeof(PIA.DpmCtrlLib.dpmFourPosSwitch));
            FillComboBoxFromEnum(cmbFunctionKey, typeof(PIA.DpmCtrlLib.dpmFunSettings));
            FillComboBoxFromEnum(cmbLowerArea, typeof(PIA.DpmCtrlLib.dpmLowerArea));
            FillComboBoxFromEnum(cmbMicrophoneSensitivity, typeof(PIA.DpmCtrlLib.dpmMicrophoneSensitivity));
            FillComboBoxFromEnum(cmbOS, typeof(PIA.DpmCtrlLib.dpmOS));
            FillComboBoxFromEnum(cmbRecordingMode, typeof(PIA.DpmCtrlLib.dpmCompressionMode));
            FillComboBoxFromEnum(cmbRequiredInputType, typeof(PIA.DpmCtrlLib.dpmRequiredInputType));
            FillComboBoxFromEnum(cmbTotalTimeType, typeof(PIA.DpmCtrlLib.dpmTotalTimeType));
            FillComboBoxFromEnum(cmbVoiceCommandType, typeof(PIA.DpmCtrlLib.dpmVoiceCommandType));
            FillComboBoxFromEnum(cmbDeviceCapabilitesDeviceType, typeof(PIA.DpmCtrlLib.dpmDeviceType));
            FillComboBoxFromEnum(cmbDCKeywordVoiceCommandMaxCommanfType, typeof(PIA.DpmCtrlLib.dpmVoiceCommandType));
            FillComboBoxFromEnum(cmbDDDisplaySymbol, typeof(PIA.DpmCtrlLib.dpmSymbols));
            FillComboBoxFromEnum(cmbDDenableLed, typeof(PIA.DpmCtrlLib.dpmLED));
            FillComboBoxFromEnum(cmbConvertAudioFormat, typeof(PIA.DpmCtrlLib.dpmAudioFormat));
            FillComboBoxFromEnum(cmbDecryptAudioFormat, typeof(PIA.DpmCtrlLib.dpmAudioFormat));
            FillComboBoxFromEnum(cmbNewFileCompressionMode, typeof(PIA.DpmCtrlLib.dpmCompressionMode));

            FillComboBoxFromEnum (KeywordDisplayAreaStringsCombo, typeof (PIA.DpmCtrlLib.dpmDisplayAreaString));
            FillComboBoxFromEnum (EditModeCombo, typeof (PIA.DpmCtrlLib.dpmEditMode));
            FillComboBoxFromEnum (FootpedalModeCombo, typeof (PIA.DpmCtrlLib.dpmFootpedalMode));
            FillComboBoxFromEnum (SmartButtonConfiguration_ButtonIndexCombo, typeof (PIA.DpmCtrlLib.dpmSmartButtons));
            FillComboBoxFromEnum (SmartButtonConfiguration_RecordingStateCombo, typeof (PIA.DpmCtrlLib.dpmRecordingState));
            FillComboBoxFromEnum (SmartButtonConfigurationCombo, typeof (PIA.DpmCtrlLib.dpmSmartButtonConfiguration));
            FillComboBoxFromEnum (BacklightCombo, typeof (PIA.DpmCtrlLib.dpmBacklight));

            FillComboBoxFromEnum (ActiveRecordingProfileCombo, typeof (PIA.DpmCtrlLib.dpmRecordingProfile));
            FillComboBoxFromEnum (RecordingProfileCombo, typeof (PIA.DpmCtrlLib.dpmRecordingProfile));
            FillComboBoxFromEnum (RecordingModeOnRecordingProfileCombo, typeof (PIA.DpmCtrlLib.dpmCompressionMode));
            FillComboBoxFromEnum (MicrophoneSensitivityOnRecordingProfileCombo, typeof (PIA.DpmCtrlLib.dpmMicrophoneSensitivity));
            FillComboBoxFromEnum (MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo, typeof (PIA.DpmCtrlLib.dpmDevicePosition));
            FillComboBoxFromEnum (MicrophoneDirectivityOnRecordingProfileCombo, typeof (PIA.DpmCtrlLib.dpmMicrophoneDirectivity));

            // fill keyboard layouts
            foreach (string layoutText in KeyboardLayoutManager.KeyboardLayouts.Keys)
            {
                _cbKeyboardLayout.Items.Add(layoutText);
            }
        }

        /// <summary>
        /// Initialize data grids showing barcode prefix/postfix
        /// </summary>
        private void SetBarcodeDataGridProperties()
        {
            for (int i = 0; i < 20; i++)
            {
                DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
                column.Width = 26;
                column.DefaultCellStyle.BackColor = (i % 2 == 0) ? Color.White : Color.LightGray;
                column.DefaultCellStyle.SelectionBackColor = column.DefaultCellStyle.BackColor;
                column.DefaultCellStyle.SelectionForeColor = SystemColors.ControlText;
                _dgBarcodePrefix.Columns.Add(column);
                _dgBarcodePostfix.Columns.Add((DataGridViewTextBoxColumn)column.Clone());
            }

            DataGridViewRow row = new DataGridViewRow();
            row.Height = 20;
            _dgBarcodePrefix.Rows.Add(row);
            _dgBarcodePostfix.Rows.Add((DataGridViewRow)row.Clone());
        }

        #endregion
        #region EventHandlers
        void _DPMControl_DPMEventProgress(string bstrFileName, int PercentComplete, int PercentSingle)
        {
            LogLine(Color.Blue, "DPMEventProgress: bstrFileName={0}; PercentComplete={1}; PercentSingle={2}", bstrFileName, PercentComplete, PercentSingle);
        }

        void _DPMControl_DPMEventError(int deviceId, int ErrorCode)
        {
            LogLine(Color.Red, "DPMEventError: deviceId={0}; ErrorCode={1};", deviceId, ErrorCode);
        }

        void _DPMControl_DPMEventDeviceReady(int deviceId)
        {
            LogLine(Color.Blue, "DPMEventDeviceReady: deviceId={0};", deviceId);
        }

        void _DPMControl_DPMEventDeviceDisconnected(int deviceId)
        {
            LogLine(Color.Blue, "DPMEventDeviceDisconnected: deviceId={0};", deviceId);
        }

        void _DPMControl_DPMEventDeviceConnected(int deviceId)
        {
            LogLine(Color.Blue, "DPMEventDeviceConnected: deviceId={0};", deviceId);
        }

        void _DPMControl_DPMEventButton(int deviceId, dpmButtonEventId EventId)
        {
            LogLine(Color.Blue, "DPMEventButton: deviceId={0};dpmButtonEventId={1}", deviceId, EventId.ToString());
        }

        void _DPMControl_DPMEventBarcodeStringScanned(int deviceId, ref string lPtr)
        {
            LogLine(Color.Blue, "DPMEventBarcodeStringScanned: deviceId={0};lPtr={1}",deviceId, lPtr); 
        }

        void _DPMControl_DPMEventBarcodeScanned(int deviceId)
        {
            LogLine(Color.Blue, "DPMEventBarcodeScanned: deviceId={0};", deviceId);
        }
        #endregion
        #region InitializationPage
        private void btnDeinitialize_Click(object sender, EventArgs e)
        {
            LogBeginCall ("Deinitialize()");
            _DPMControl.Deinitialize();
            LogFinishCall();
            _IDPMDevice = null;
            _IDPMDeviceCapabilites = null;
            _IDPMDeviceSettings = null;
            
            UpdateDPMDevicePanelVisibility();
            HideDeviceSettingsPanel();
        }

        private void btnInitialize_Click(object sender, EventArgs e)
        {
            LogBeginCall("Initialize()");
            _DPMControl.Initialize(false);
            LogFinishCall();
        }
        #endregion

        #region DPMDevicePage
        private void btnGetDeviceType_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.DeviceType");
            string value = textDeviceType.Text = _IDPMDevice.DeviceType.ToString();
            LogFinishCall(value);
        }

        private void btnGetBuildNumber_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.BuildNumber");
            string value = textBuildNumber.Text = _IDPMDevice.BuildNumber.ToString();
            LogFinishCall(value);
        }

        private void btnGetDevice_Click(object sender, EventArgs e)
        {
            LogBeginCall("_DPMControl.get_DPMDevice(0)");
            _IDPMDevice = _DPMControl.get_DPMDevice(0);
            LogFinishCall();
            ResetUI(DeviceInfoPanel);
            UpdateDPMDevicePanelVisibility();
            UpdateDeviceSettingsPutToDeviceButtonVisibility();
        }
        private void UpdateDPMDevicePanelVisibility()
        {
            
            //ResetUI(barcodeSettingsPanel);
            if (_IDPMDevice == null)
            {
                DeviceInfoPanel.Visible = false;
                barcodeSettingsPanel.Visible = false;
                btnGetSettingsFromDevice.Enabled = false;
                //btnbtnGetDeviceCapabilitiesCurrentDevice.Enabled = false;
                btnDCGetFromIDPMDevice.Enabled = false;
                btnFLIDPMDeviceDriveLetterSet.Enabled = false;
            }
            else
            {
                DeviceInfoPanel.Visible = true;
                barcodeSettingsPanel.Visible = true;
                btnGetSettingsFromDevice.Enabled = true;
                //btnbtnGetDeviceCapabilitiesCurrentDevice.Enabled = true;
                btnDCGetFromIDPMDevice.Enabled = true;
                btnFLIDPMDeviceDriveLetterSet.Enabled = true;
            }
        }

        private void btmGetFirmwareVersion_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.FirmwareVersion");
            string value = textFirmwareVersion.Text = _IDPMDevice.FirmwareVersion.ToString();
            LogFinishCall(value);
        }

        private void btnGetMacAddress_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.MACAddress");
            string value = textMacAddress.Text = _IDPMDevice.MACAddress.ToString();
            LogFinishCall(value);
        }

        private void btnGetDriveLetter_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.DriveLetter");
            string value = textDriveLetter.Text = _IDPMDevice.DriveLetter.ToString();
            LogFinishCall(value);
        }

        private void btnGetFreeDiskSpace_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.FreeDiskSpace");
            string value = textFreeDiskSpace.Text = _IDPMDevice.FreeDiskSpace.ToString();
            LogFinishCall(value);
        }

        private void btnFileCount_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.FileCount");
            string value = textFileCount.Text = _IDPMDevice.FileCount.ToString();
            LogFinishCall(value);
        }
        private void btnDDPukSet_Click(object sender, EventArgs e)
        {
            LogBeginCall("(set) _IDPMDevice.PUK = {0}", textDDPUK.Text);
            _IDPMDevice.PUK = textDDPUK.Text;
            LogFinishCall();
        }
        private void btnDDPUKSetGet_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.PUKSet");
            bool value = _IDPMDevice.PUKSet;
            SetCheckboxState(cbDDPUKSet, _IDPMDevice.PUKSet);
            LogFinishCall(value);
        }
        #endregion

        #region Helpers
        private void AppendLog(string message)
        {
            if (textLog.Text != string.Empty)
            {
                textLog.Text += Environment.NewLine;
            }

            textLog.Text += message;

            // Scroll to the bottom, but don't move the caret position.
            WinApi.SendMessage(textLog.Handle, WinApi.WM_VSCROLL, (IntPtr)WinApi.SB_BOTTOM, IntPtr.Zero);
        }
        /// <summary>
        /// Logging helper: adds formatted text to log box
        /// </summary>
        private DateTime LogLine(string format, params object[] args)
        {
            DateTime now = DateTime.Now;
            textLog.AppendText(String.Format("{0} : {1}{2}", now, String.Format(format, args), Environment.NewLine));
            return now;
        }

        /// <summary>
        /// Logging helper: adds formatted text to log box
        /// </summary>
        private DateTime LogLine(Color textColor, string format, params object[] args)
        {
            DateTime now = DateTime.Now;
            Color savedColor = textLog.SelectionColor;
            textLog.SelectionColor = textColor;
            textLog.AppendText(String.Format("{0} : {1}{2}", now, String.Format(format, args), Environment.NewLine));
            textLog.SelectionColor = savedColor;
            return now;
        }

        /// <summary>
        /// Logging helper: begin time of last call to calculate call length
        /// </summary>
        private DateTime LastCallTime;

        /// <summary>
        /// Logging helper: formatted text of last called object
        /// </summary>
        private string LastCalledObject;

        /// <summary>
        /// Logging helper: Log the beginning of the call
        /// </summary>
        private void LogBeginCall(string format, params object[] args)
        {
            // save the object
            LastCalledObject = String.Format(format, args);

            // save beginning time of call
            LastCallTime = LogLine(LastCalledObject);
        }

        /// <summary>
        /// Logging helper: Log the successful finish of the call
        /// </summary>
        private void LogFinishCall()
        {
            // calculate time
            TimeSpan elapsedTime = DateTime.Now - LastCallTime;
            LogLine("{0} - OK, elapsed {1:#####0} ms", LastCalledObject, elapsedTime.TotalMilliseconds);
        }

        /// <summary>
        /// Logging helper: Log the successful finish of the call
        /// </summary>
        private void LogFinishCall(object getResult)
        {
            // calculate time
            TimeSpan elapsedTime = DateTime.Now - LastCallTime;
            LogLine("{0} = {2} - OK, elapsed {1:#####0} ms", LastCalledObject, elapsedTime.TotalMilliseconds, getResult);
        }

        private void LogTxt_TextChanged(object sender, EventArgs e)
        {
            textLog.SelectionStart = textLog.Text.Length;
            textLog.ScrollToCaret();
        }

        private void SaveLogBtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            dlg.DefaultExt = "log";
            dlg.FileName = String.Format("SmExAudio Test {0:yyyyMMdd hhmmss}.log", DateTime.Now);
            dlg.Filter = "Log files (*.log)|*.log|All files|*.*";
            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                using (StreamWriter writer = File.CreateText(dlg.FileName))
                {
                    writer.Write(textLog.Text);
                }
            }
        }

        private void FillComboBoxFromEnum(ComboBox comboBox, Type e)
        {
            foreach (object val in Enum.GetValues(e))
            {
                comboBox.Items.Add(val);
            }

            if (comboBox.Items.Count > 0)
            {
                comboBox.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Reset UI elements of the specified container
        /// </summary>
        /// <param name="container">Container to reset controls of</param>
        private void ResetUI(Control container)
        {
            foreach (Control control in container.Controls)
            {
                if (control is TextBox)
                {
                    ((TextBox)control).Text = string.Empty;
                }
                else if (control is CheckBox)
                {
                    ((CheckBox)control).CheckState = CheckState.Indeterminate;
                }
                else if (control is NumericUpDown)
                {
                    ((NumericUpDown)control).Value = -1;
                }
                else if (control is ComboBox)
                {
                    ((ComboBox)control).SelectedIndex = -1;
                }
                else if (control is GroupBox)
                {
                    ResetUI((GroupBox)control);
                }
                else if (control is Panel)
                {
                    ResetUI((Panel)control);
                }

                // disable set buttons
                if (control.Tag != null)
                {
                    if (control.Tag is Button)
                    {
                        ((Button)control.Tag).Enabled = false;
                    }
                }
            }
        }

        private void SetCheckboxState(CheckBox checkbox, bool isChecked)
        {
            checkbox.CheckState = isChecked ? CheckState.Checked : CheckState.Unchecked;
        }

        #endregion

        #region "Events and Exceptions"

        public static Mainform Instance;

        // event handler for all exceptions
        // has to be static, otherwise it does not work, because the event is static
        public static void OnThreadException(object sender, ThreadExceptionEventArgs e)
        {
            Instance.Cursor = Cursors.Default;

            Exception ex = e.Exception;
            COMException ce = ex as COMException;

            // if it is a COM exception, cast the error code to spmError enum in the COM object
            if (ce != null)
            {
                // show error info
                Instance.LogLine(Color.Red, ex.Source + "." + ex.TargetSite.Name + ": " + (PIA.DpmCtrlLib.dpmCtrlError)ce.ErrorCode + ". Message: " + ce.Message);

                return;
            }

            ArgumentException ae = ex as ArgumentException;
            if (ae != null)
            {
                // show error info
                Instance.LogLine(Color.Red, ex.Source + "." + ex.TargetSite.Name + ": ArgumentException");
                return;
            }

            // show the (non-COM) exception's description
            MessageBox.Show(ex.ToString());
        }
        #endregion
        #region DeviceSettingsPageHelpers
        private void HideDeviceSettingsPanel()
        {
            deviceSettingsTabControl.Visible = false;
            btnPutSettingsToDevice.Enabled = false;
            UpdateDeviceSettingsPutToDeviceButtonVisibility();
        }
        private void ShowDeviceSettingsPanel()
        {
            ClearDeviceSettingsPanel();
            deviceSettingsTabControl.Visible = true;
            btnPutSettingsToDevice.Enabled = true;
            UpdateDeviceSettingsPutToDeviceButtonVisibility();
            //_IDPMDeviceSettings.Appearance = dpmAppearance.
        }

        private void UpdateDeviceSettingsPutToDeviceButtonVisibility()
        {
            if (_IDPMDevice != null)
            {
                btnPutSettingsToDevice.Visible = true;
            }
            else
            {
                btnPutSettingsToDevice.Visible = false;
            }
        }

        private void ClearDeviceSettingsPanel()
        {
            ResetUI(deviceSettings1TabPage);
            ResetUI(deviceSettings2TabPage);
            ResetUI(deviceSettings3TabPage);
            ResetUI(deviceSettings4TabPage);
            ResetUI(deviceSettings5TabPage);
            ResetUI(deviceSettings6TabPage);

            RecordingProfileGroup.Visible = false;
        }

        private void btnImportConfig_Click(object sender, EventArgs e)
        {
            HideDeviceSettingsPanel();
            _IDPMDeviceSettings = _DPMControl.ImportConfigurationFile(textConfigFilePath.Text);
            ShowDeviceSettingsPanel();
        }

        private void btnConfigFileBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            dlgOpen.CheckFileExists = false;
            dlgOpen.RestoreDirectory = true;
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textConfigFilePath.Text = dlgOpen.FileName;
            }
        }

        private void btnExportConfig_Click(object sender, EventArgs e)
        {
            _DPMControl.ExportConfigurationFile(textConfigFilePath.Text, _IDPMDeviceSettings);
        }

        private void btnGetSettingsFromDevice_Click(object sender, EventArgs e)
        {
            HideDeviceSettingsPanel();
            LogBeginCall("(get) _IDPMDevice.DeviceSettings");
            _IDPMDeviceSettings = _IDPMDevice.DeviceSettings;
            LogFinishCall();
            ShowDeviceSettingsPanel();
        }
        #endregion
        #region DeviceSettingsGetButtons
        private void btnDSAppearanceGet_Click(object sender, EventArgs e)
        {
            cmbAppearance.SelectedItem = _IDPMDeviceSettings.Appearance;
        }

        private void btnDSBarcodeModeGet_Click(object sender, EventArgs e)
        {
            cmbBarcodeMode.SelectedItem = _IDPMDeviceSettings.BarcodeMode;
        }

        private void btnDSBarCodeScanButtonGet_Click(object sender, EventArgs e)
        {
            cmbBarcodeScanButton.SelectedItem = _IDPMDeviceSettings.BarcodeScanButton;
        }

        private void btnDSDateTimeFormatGet_Click(object sender, EventArgs e)
        {
            cmbDateTimeFormat.SelectedItem = _IDPMDeviceSettings.DateTimeFormat;
        }

        private void btnDSFileCounterSourceGet_Click(object sender, EventArgs e)
        {
            cmbFileCounterSource.SelectedItem = _IDPMDeviceSettings.FileCounterSource;
        }

        private void btnDSFileNamePrefixGet_Click(object sender, EventArgs e)
        {
            cmbFileNamePrefixType.SelectedItem = _IDPMDeviceSettings.FileNamePrefixType;
        }

        private void btnDSFourPosSwitchGet_Click(object sender, EventArgs e)
        {
            cmbFourPosSwitch.SelectedItem = _IDPMDeviceSettings.FourPosSwitch;
        }

        private void btnDSFunctionKeyGet_Click(object sender, EventArgs e)
        {
            cmbFunctionKey.SelectedItem = _IDPMDeviceSettings.FunctionKey;
        }

        private void btnDSLowerAreaGet_Click(object sender, EventArgs e)
        {
            cmbLowerArea.SelectedItem = _IDPMDeviceSettings.LowerArea;
        }

        private void btnDSMicrophoneSensitivityGet_Click(object sender, EventArgs e)
        {
            cmbMicrophoneSensitivity.SelectedItem = _IDPMDeviceSettings.MicrophoneSensitivity;
        }

        private void btnDSOsGet_Click(object sender, EventArgs e)
        {
            cmbOS.SelectedItem = _IDPMDeviceSettings.OS;
        }

        private void btnDSRecordingModeGet_Click(object sender, EventArgs e)
        {
            cmbRecordingMode.SelectedItem = _IDPMDeviceSettings.RecordingMode;
        }

        private void btnDSRequiredInputTypeGet_Click(object sender, EventArgs e)
        {
            cmbRequiredInputType.SelectedItem = _IDPMDeviceSettings.RequiredInputType;
        }

        private void btnDSTotalTimeTypeGet_Click(object sender, EventArgs e)
        {
            cmbTotalTimeType.SelectedItem = _IDPMDeviceSettings.TotalTimeType;
        }
        private void btnDSAppendModeGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbAppendMode, _IDPMDeviceSettings.AppendMode);
        }

        private void btnDSCueReviewSoundGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbCueReviewSound, _IDPMDeviceSettings.CueReviewSound);
        }

        private void btnDSDELButtonEnabledGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDELButtonEnabled, _IDPMDeviceSettings.DELButtonEnabled);
        }

        private void btnDSDeleteFilesAfterDownloadGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDeleteFilesAfterDownload, _IDPMDeviceSettings.DeleteFilesAfterDownload);
        }

        private void btnDSDeviceBeepGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDeviceBeep, _IDPMDeviceSettings.DeviceBeep);
        }

        private void btnDSDLSButtonEnabledGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDLSButtonEnabled, _IDPMDeviceSettings.DLSButtonEnabled);
        }

        private void btnDSEnabledUSBAudioGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbEnableUSBAudio, _IDPMDeviceSettings.EnableUSBAudio);
        }

        private void btnDSEOLButtonEnabledGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbEOLButtonEnabled, _IDPMDeviceSettings.EOLButtonEnabled);
        }

        private void btnDSInsertButtonEnabledGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbInsertButtonEnabled, _IDPMDeviceSettings.InsertButtonEnabled);
        }

        private void btnDSLinkKeywordsGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbLinkKeywords, _IDPMDeviceSettings.LinkKeywords);
        }

        private void btnDSNoiseReductionGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbNoiseReduction, _IDPMDeviceSettings.NoiseReduction);
        }

        private void btnDSOneFileGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbOneFile, _IDPMDeviceSettings.OneFile);
        }

        private void btnDSPCMEnabledGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbPCMEnabled, _IDPMDeviceSettings.PCMEnabled);
        }

        private void btnDSProhibitFileAlterationGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbProhibitFileAlteration, _IDPMDeviceSettings.ProhibitFileAlteration);
        }

        private void btnDSProModeGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbProMode, _IDPMDeviceSettings.ProMode);
        }

        private void btnDSProtectDeviceGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbProtectDevice, _IDPMDeviceSettings.ProtectDevice);
        }

        private void btnDSRecordLevelGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbRecordLevelInd, _IDPMDeviceSettings.RecordLevelInd);
        }

        private void btnDSRecordNotifyGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbRecordNotify, _IDPMDeviceSettings.RecordNotify);
        }

        private void btnDSScanKeywordsFromBarcodeGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbScanKeywordsFromBarcode, _IDPMDeviceSettings.ScanKeywordsFromBarcode);
        }

        private void btnDSUSBHighPowerModeGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbUSBHighPowerMode, _IDPMDeviceSettings.USBHighPowerMode);
        }

        private void btnDSVoiceActivationGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbVoiceActivation, _IDPMDeviceSettings.VoiceActivation);
        }

        private void btnDSMassStorageWriteProtectionGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbMassStorageWriteProtection, _IDPMDeviceSettings.MassStorageWriteProtection);
        }

        private void btnDSFileNamePrefixStringGet_Click(object sender, EventArgs e)
        {
            textFileNamePrefixString.Text = _IDPMDeviceSettings.FileNamePrefixString;
        }

        private void btnDSFirmwareVersionGet_Click(object sender, EventArgs e)
        {
            textDSFirmwareVersion.Text = _IDPMDeviceSettings.FirmwareVersion;
        }

        private void btnDSKeyword1StringGet_Click(object sender, EventArgs e)
        {
            textKeyword1String.Text = _IDPMDeviceSettings.Keyword1String;
        }

        private void btnDSMACAddressGet_Click(object sender, EventArgs e)
        {
            textDSMACAddress.Text = _IDPMDeviceSettings.MACAddress;
        }

        private void btnPutSettingsToDevice_Click(object sender, EventArgs e)
        {
            LogBeginCall("(get) _IDPMDevice.DeviceSettings");
            _IDPMDevice.DeviceSettings = _IDPMDeviceSettings;
            LogFinishCall();
        }

        private void btnDSDisplayKeywordsGet_Click(object sender, EventArgs e)
        {
            numDisplayKeywords.Value = _IDPMDeviceSettings.DisplayKeywords;
        }

        private void btnDSFileCounterGet_Click(object sender, EventArgs e)
        {
            numFileCounter.Value = _IDPMDeviceSettings.FileCounter;
        }

        private void btnDSDownloadModeGet_Click(object sender, EventArgs e)
        {
            numDownloadMode.Value = _IDPMDeviceSettings.DownloadMode;
        }

        private void btnDSDownloadFilterGet_Click(object sender, EventArgs e)
        {
            numDownloadFilter.Value = _IDPMDeviceSettings.DownloadFilter;
        }

        private void btnDSKeywordContentCountGet_Click(object sender, EventArgs e)
        {
            numKeywordContentCount.Value = _IDPMDeviceSettings.KeywordContentCount;
        }

        private void btnDSKeywordUsageCountGet_Click(object sender, EventArgs e)
        {
            numKeywordUsageCount.Value = _IDPMDeviceSettings.KeywordUsageCount;
        }

        private void btnLockTimeGet_Click(object sender, EventArgs e)
        {
            numLockTime.Value = _IDPMDeviceSettings.LockTime;
        }

        private void btnDSUserStringCountGet_Click(object sender, EventArgs e)
        {
            numUserStringCount.Value = _IDPMDeviceSettings.UserStringCount;
        }

        private void btnKeywordBarcodeScanGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbKeywordBarcodeScan, _IDPMDeviceSettings.get_KeywordBarcodeScan((int)numKeywordBarcodeScanIndex.Value));
        }

        private void btnKeywordMandatoryGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbKeywordMandatory, _IDPMDeviceSettings.get_KeywordMandatory((int)numKeywordMandatoryIndex.Value));
        }

        private void btnDSKeywordVoiceCommandGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbKeywordVoiceCommand, _IDPMDeviceSettings.get_KeywordVoiceCommand((int)numKeywordVoiceCommandIndex.Value));
        }

        private void btnDSKeywordContentStringGet_Click(object sender, EventArgs e)
        {
            textKeywordContentString.Text = _IDPMDeviceSettings.get_KeywordContentString((int)numKeywordContentStringUsageIndex.Value, (int)numKeywordContentStringContentIndex.Value);
        }

        private void btnKeywordUsageStringGet_Click(object sender, EventArgs e)
        {
            textKeywordUsageString.Text = _IDPMDeviceSettings.get_KeywordUsageString((int)numKeywordUsageStringIndex.Value);
        }

        private void btnDSVoiceCommandTypeGet_Click(object sender, EventArgs e)
        {
            cmbVoiceCommandType.SelectedItem = _IDPMDeviceSettings.get_VoiceCommandType((int)numVoiceCommandTypeIndex.Value);
        }

        private void btnDSObligatoryKeywordSelectionGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbObligatoryKeywordSelection, _IDPMDeviceSettings.ObligatoryKeywordSelection);
        }
        private void btnDSSliderJumpBackTimeGet_Click(object sender, EventArgs e)
        {
            numSliderJumpBackTime.Value = _IDPMDeviceSettings.SliderJumpBackTime;
        }

#endregion
        #region DeviceSettingsSetButtons
        private void btnDSAppearanceSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.Appearance = (dpmAppearance)cmbAppearance.SelectedItem;
        }

        private void btnDSBarcodeModeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.BarcodeMode = (dpmBarcodeMode)cmbBarcodeMode.SelectedItem;
        }

        private void btnDSBarCodeScanButtonSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.BarcodeScanButton = (dpmBarcodeScanButton)cmbBarcodeScanButton.SelectedItem;
        }

        private void btnDSDateTimeFormatSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DateTimeFormat = (dpmDateTimeFormat)cmbDateTimeFormat.SelectedItem;
        }

        private void btnDSFileCounterSourceSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FileCounterSource = (dpmFileCounterSource)cmbFileCounterSource.SelectedItem;
        }

        private void btnDSFileNamePrefixSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FileNamePrefixType = (dpmFilenamePrefixType)cmbFileNamePrefixType.SelectedItem;
        }

        private void btnDSFourPosSwitchSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FourPosSwitch = (dpmFourPosSwitch)cmbFourPosSwitch.SelectedItem;
        }

        private void btnDSFunctionKeySet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FunctionKey = (dpmFunSettings)cmbFunctionKey.SelectedItem;
        }

        private void btnDSLowerAreaSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.LowerArea = (dpmLowerArea)cmbLowerArea.SelectedItem;
        }

        private void btnDSMicrophoneSensitivitySet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.MicrophoneSensitivity = (dpmMicrophoneSensitivity)cmbMicrophoneSensitivity.SelectedItem;
        }

        private void btnDSOsSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.OS = (dpmOS)cmbOS.SelectedItem;
        }

        private void btnDSRecordingModeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.RecordingMode = (dpmCompressionMode)cmbRecordingMode.SelectedItem;
        }

        private void btnDSRequiredInputTypeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.RequiredInputType = (dpmRequiredInputType)cmbRequiredInputType.SelectedItem;
        }

        private void btnDSTotalTimeTypeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.TotalTimeType = (dpmTotalTimeType)cmbTotalTimeType.SelectedItem;
        }

        private void btnDSAppendModeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.AppendMode = cbAppendMode.Checked;
        }

        private void btnDSCueReviewSoundSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.CueReviewSound = cbCueReviewSound.Checked;
        }

        private void btnDSDELButtonEnabledSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DELButtonEnabled = cbDELButtonEnabled.Checked;
        }

        private void btnDSDeleteFilesAfterDownloadSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DeleteFilesAfterDownload = cbDeleteFilesAfterDownload.Checked;
        }

        private void btnDSDeviceBeepSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DeviceBeep = cbDeviceBeep.Checked;
        }

        private void btnDSDLSButtonEnabledSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DLSButtonEnabled = cbDLSButtonEnabled.Checked;
        }

        private void btnDSEnableUSBAudioSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.EnableUSBAudio = cbEnableUSBAudio.Checked;
        }

        private void btnDSEOLButtonEnabledSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.EOLButtonEnabled = cbEOLButtonEnabled.Checked;
        }

        private void btnDSInsertButtonEnabledSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.InsertButtonEnabled = cbInsertButtonEnabled.Checked;
        }

        private void btnDSLinkKeywordsSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.LinkKeywords = cbLinkKeywords.Checked;
        }

        private void btnDSNoiseReductionSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.NoiseReduction = cbNoiseReduction.Checked;
        }

        private void btnDSOneFileSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.OneFile = cbOneFile.Checked;
        }

        private void btnDSPCMEnabledSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.PCMEnabled = cbPCMEnabled.Checked;
        }

        private void btnDSProhibitFileAlterationSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.ProhibitFileAlteration = cbProhibitFileAlteration.Checked;
        }

        private void btnDSProModeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.ProMode = cbProMode.Checked;
        }

        private void btnDSProtectDeviceSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.ProtectDevice = cbProtectDevice.Checked;
        }

        private void btnDSRecordLevelSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.RecordLevelInd = cbRecordLevelInd.Checked;
        }

        private void btnDSRecordNotifySet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.RecordNotify = cbRecordNotify.Checked;
        }

        private void btnDSScanKeywordsFromBarcodeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.ScanKeywordsFromBarcode = cbScanKeywordsFromBarcode.Checked;
        }

        private void btnDSUSBHighPowerModeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.USBHighPowerMode = cbUSBHighPowerMode.Checked;
        }

        private void btnDSVoiceActivationSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.VoiceActivation = cbVoiceActivation.Checked;
        }

        private void btnDSFileNamePrefixStringSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FileNamePrefixString = textFileNamePrefixString.Text;
        }

        private void btnDSKeyword1StringSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.Keyword1String = textKeyword1String.Text;
        }

        private void btnDSDisplayKeywordsSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DisplayKeywords = (int)numDisplayKeywords.Value;
        }

        private void btnDSFileCounterSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FileCounter = (int)numFileCounter.Value;
        }

        private void btnDSDownloadModeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DownloadMode = (int)numDownloadMode.Value;
        }

        private void btnDSDownloadFilterSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.DownloadFilter = (int)numDownloadFilter.Value;
        }

        private void btnDSLockTimeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.LockTime = (int)numLockTime.Value;
        }

        private void btnDSUserStringCountSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.UserStringCount = (int)numUserStringCount.Value;
        }

        private void btnKeywordBarcodeScanSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_KeywordBarcodeScan((int)numKeywordBarcodeScanIndex.Value, cbKeywordBarcodeScan.Checked);
        }

        private void btnKeywordMandatorySet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_KeywordMandatory((int)numKeywordMandatoryIndex.Value, cbKeywordMandatory.Checked);
        }

        private void btnDSKeywordVoiceCommandSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_KeywordVoiceCommand((int)numKeywordVoiceCommandIndex.Value, cbKeywordVoiceCommand.Checked);
        }

        private void btnDSKeywordContentStringSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_KeywordContentString((int)numKeywordContentStringUsageIndex.Value,
                                                         (int)numKeywordContentStringContentIndex.Value,
                                                          textKeywordContentString.Text);
        }

        private void btnDSKeywordUsageStringSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_KeywordUsageString((int)numKeywordUsageStringIndex.Value,
                                                        textKeywordUsageString.Text);
        }

        private void btnDSVoiceCommandTypeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_VoiceCommandType((int)numVoiceCommandTypeIndex.Value,
                                                     (dpmVoiceCommandType)cmbVoiceCommandType.SelectedItem);
        }
        private void btnDSMassStorageWriteProtectionSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.MassStorageWriteProtection = cbMassStorageWriteProtection.Checked;
        }
        private void btnDSObligatoryKeywordSelection_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.ObligatoryKeywordSelection = cbObligatoryKeywordSelection.Checked;
        }

        private void btnDSSliderJumpBackTimeSet_Click(object sender, EventArgs e)
        {
            _IDPMDeviceSettings.SliderJumpBackTime = (int)numSliderJumpBackTime.Value;
        }
        #endregion

        #region DeviceCapabilitesPage
        private void btnGetDeviceCapabilities_Click(object sender, EventArgs e)
        {
            _IDPMDeviceCapabilites = _DPMControl.get_DPMCapabilities((dpmDeviceType)cmbDeviceCapabilitesDeviceType.SelectedItem);
            UpdateDeviceCapabilitesPanelVisibility();
            
        }

        private void btnbtnGetDeviceCapabilitiesCurrentDevice_Click(object sender, EventArgs e)
        {
            _IDPMDeviceCapabilites = _DPMControl.get_DPMCapabilities(_IDPMDevice.DeviceType);
            UpdateDeviceCapabilitesPanelVisibility();
        }

        private void btnDCGetFromIDPMDevice_Click(object sender, EventArgs e)
        {
            _IDPMDeviceCapabilites = _IDPMDevice.DeviceCapacilities;
            UpdateDeviceCapabilitesPanelVisibility();
        }

        private void UpdateDeviceCapabilitesPanelVisibility()
        {
            if (_IDPMDeviceCapabilites == null)
            {
                deviceCapabilitesPanel.Visible = false;
            }
            else
            {
                ResetUI(deviceCapabilitesPanel);
                cmbDCKeywordVoiceCommandMaxCommanfType.SelectedIndex = 0;
                deviceCapabilitesPanel.Visible = true;
            }
        }
        #endregion
        #region DeviceCapabilitiesPage
        private void btnDCBarcodeEventGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCBarcodeEvent, _IDPMDeviceCapabilites.BarcodeEvent);
        }

        private void btnDCBarcodeScanButtonGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCBarcodeScanButton, _IDPMDeviceCapabilites.BarcodeScanButton);
        }

        private void btnDCEncryptionGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCEncryption, _IDPMDeviceCapabilites.Encryption);
        }

        private void btnDCFourPosSwitchGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCFourPosSwitch, _IDPMDeviceCapabilites.FourPosSwitch);
        }

        private void btnDCFunctionKey_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCFunctionKey, _IDPMDeviceCapabilites.FunctionKey);
        }

        private void btnDCInstructionGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCInstruction, _IDPMDeviceCapabilites.Instruction);
        }

        private void btnDCKeywordBarcodeScanGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCKeywordBarcodeScan, _IDPMDeviceCapabilites.KeywordBarcodeScan);
        }

        private void btnDCKeywordMandatoryGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCKeywordMandatory, _IDPMDeviceCapabilites.KeywordMandatory);
        }

        private void btnDCKeywordsReadOnlyGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCKeywordsReadOnly, _IDPMDeviceCapabilites.KeywordsReadOnly);
        }

        private void btnDCKeywordVoiceCommandGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCKeywordVoiceCommand, _IDPMDeviceCapabilites.KeywordVoiceCommand);
        }

        private void btnDCLinkKeywordsGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCLinkKeywords, _IDPMDeviceCapabilites.LinkKeywords);
        }

        private void btnDCPriorityGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCPriority, _IDPMDeviceCapabilites.Priority);
        }

        private void btnDCProhibitFileAlterationGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCProhibitFileAlteration, _IDPMDeviceCapabilites.ProhibitFileAlteration);
        }

        private void btnDCQualityPlayGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCQualityPlay, _IDPMDeviceCapabilites.QualityPlay);
        }

        private void btnDCRequiredInputTypeGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCRequiredInputType, _IDPMDeviceCapabilites.RequiredInputType);
        }

        private void btnDCScanKeywordsFromBarcodeGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCScanKeywordsFromBarcode, _IDPMDeviceCapabilites.ScanKeywordsFromBarcode);
        }

        private void btnDcSecurityGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDCSecurity, _IDPMDeviceCapabilites.Security);
        }

        private void btnDCDeviceNameGet_Click(object sender, EventArgs e)
        {
            textDCDeviceName.Text = _IDPMDeviceCapabilites.DeviceName;
        }

        private void btnDCDisplayModeCountGet_Click(object sender, EventArgs e)
        {
            textDCDisplayModeCount.Text = _IDPMDeviceCapabilites.DisplayModeCount.ToString();
        }

        private void btnDCKeywordContentMaxGet_Click(object sender, EventArgs e)
        {
            textDCKeywordContentMax.Text = _IDPMDeviceCapabilites.KeywordContentMax.ToString();
        }

        private void btnDCKeywordUsageMaxGet_Click(object sender, EventArgs e)
        {
            textDCKeywordUsageMax.Text = _IDPMDeviceCapabilites.KeywordUsageMax.ToString();
        }

        private void btnDCMaxKeywordLengthGet_Click (object sender, EventArgs e)
        {
            textDCMaxKeywordLength.Text = _IDPMDeviceCapabilites.MaxKeywordLength.ToString ();
        }

        private void btnDCProductIdGet_Click(object sender, EventArgs e)
        {
            textDCProductId.Text = _IDPMDeviceCapabilites.ProductId.ToString();
        }

        private void btnDCUserStringMaxGet_Click(object sender, EventArgs e)
        {
            textDCUserStringMax.Text = _IDPMDeviceCapabilites.UserStringMax.ToString();
        }

        private void btnDCVendorIdGet_Click(object sender, EventArgs e)
        {
            textDCVendorId.Text = _IDPMDeviceCapabilites.VendorId.ToString();
        }

        private void btnDCKeywordVoiceCommandMaxGet_Click(object sender, EventArgs e)
        {
            textDcKeywordVoiceCommandMax.Text = _IDPMDeviceCapabilites.get_KeywordVoiceCommandMax((dpmVoiceCommandType)cmbDCKeywordVoiceCommandMaxCommanfType.SelectedItem).ToString();
        }
        #endregion
        #region FileListPage
        private void btnFLPathGet_Click(object sender, EventArgs e)
        {
            textFLPath.Text = _IDPMFileList.Path;
        }

        private void btnFLPathSet_Click(object sender, EventArgs e)
        {
            _IDPMFileList.Path = textFLPath.Text;
        }

        private void btnFLPathBrowse_Click(object sender, EventArgs e)
        {
            //OpenFileDialog dlgOpen = new OpenFileDialog();
            FolderBrowserDialog dlgOpen = new FolderBrowserDialog();
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textFLPath.Text = dlgOpen.SelectedPath;
            }
        }

        private void btnDSCountGet_Click(object sender, EventArgs e)
        {
            textFLCount.Text = _IDPMFileList.Count.ToString();
        }

        private void btnFLFilesGet_Click(object sender, EventArgs e)
        {
            cmbFLFileList.Items.Clear();
            cmbFLFileList.SelectedIndex = -1;
            cmbFLFileList.Text = "";
            foreach (string fileName in _IDPMFileList)
            {
                cmbFLFileList.Items.Add(fileName);
            }

        }
        private void btnFLIDPMDeviceDriveLetterSet_Click(object sender, EventArgs e)
        {
            textFLPath.Text = _IDPMDevice.DriveLetter;
            _IDPMFileList.Path = textFLPath.Text;
        }
        #endregion
        #region DPMDevicePage
        private void btnDDDeleteFile_Click(object sender, EventArgs e)
        {
            _IDPMDevice.DeleteFile(textDDDeleteFile.Text);
        }

        private void btnDDDeleteFileBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            dlgOpen.CheckFileExists = false;
            dlgOpen.RestoreDirectory = true;
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textDDDeleteFile.Text = System.IO.Path.GetFileName(dlgOpen.FileName);
            }
        }

        private void btnDDDisplayScreen_Click(object sender, EventArgs e)
        {
            _IDPMDevice.DisplayScreen(textDDDisplayScreen.Text);
        }

        private void btnDDDisplayScreenBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            dlgOpen.CheckFileExists = false;
            dlgOpen.RestoreDirectory = true;
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textDDDisplayScreen.Text = dlgOpen.FileName;
            }
        }

        private void btnDDDisplaySymbol_Click(object sender, EventArgs e)
        {
            _IDPMDevice.DisplaySymbol((dpmSymbols)cmbDDDisplaySymbol.SelectedItem);
        }

        private void btnDDenableLed_Click(object sender, EventArgs e)
        {
            _IDPMDevice.EnableLED((int)numDDenableLedIndex.Value, (dpmLED)cmbDDenableLed.SelectedItem);
        }

        private void btnDDFormatCard_Click(object sender, EventArgs e)
        {
            _IDPMDevice.FormatCard();
        }

        private void btnDDSetEncryptionPassword_Click(object sender, EventArgs e)
        {
            _IDPMDevice.set_EncryptionPassword(textDDSetEncriptionPasswordoldKey.Text, textDDSetEncriptionPasswordp2.Text);
        }

        private void btnDDSetPIN_Click(object sender, EventArgs e)
        {
            _IDPMDevice.set_PIN(textDDSetPIN_PUK.Text, textDDSetPIN_p2.Text);
        }

        private void btnDDSynchronizeDateTime_Click(object sender, EventArgs e)
        {
            _IDPMDevice.SynchronizeDateTime();
        }
        #endregion
        #region BarcodeSettingsPage
        private void _cbKeyboardLayout_SelectedIndexChanged(object sender, EventArgs e)
        {
            _txtLayoutID.Text = KeyboardLayoutManager.KeyboardLayouts[_cbKeyboardLayout.SelectedItem.ToString()].ToString();
        }

        private void _btnGetBarcodeConfiguration_Click(object sender, EventArgs e)
        {
            LogBeginCall("_IDPMDevice.GetBarcodeKeyboardSettings()");
            _IDPMDevice.GetBarcodeKeyboardSettings(out _BarcodeLayout, out _BarcodePrefix, out _BarcodePostfix);
            LogFinishCall();

            int[,] prefixValues = (int[,])_BarcodePrefix;

            for (int i = 0; i < 10; i++)
            {
                _dgBarcodePrefix.Rows[0].Cells[i * 2].Value = prefixValues[0, i];
                _dgBarcodePrefix.Rows[0].Cells[i * 2 + 1].Value = prefixValues[1, i];
            }
            int[,] postfixValues = (int[,])_BarcodePostfix;

            for (int i = 0; i < 10; i++)
            {
                _dgBarcodePostfix.Rows[0].Cells[i * 2].Value = postfixValues[0, i];
                _dgBarcodePostfix.Rows[0].Cells[i * 2 + 1].Value = postfixValues[1, i];
            }

            _txtLayoutID.Text = _BarcodeLayout;
            foreach (string name in KeyboardLayoutManager.KeyboardLayouts.Keys)
            {
                if (KeyboardLayoutManager.KeyboardLayouts[name].ToString() == _BarcodeLayout)
                    _cbKeyboardLayout.SelectedItem = name;
            }

        }


        private void _btnSetBarcodeConfiguration_Click(object sender, EventArgs e)
        {
            try
            {
                int[,] prefixValues = new int[2, 10];

                for (int i = 0; i < 10; i++)
                {
                    prefixValues[0, i] = Convert.ToInt32(_dgBarcodePrefix.Rows[0].Cells[i * 2].Value);
                    prefixValues[1, i] = Convert.ToInt32(_dgBarcodePrefix.Rows[0].Cells[i * 2 + 1].Value);
                }

                _BarcodePrefix = prefixValues;
            }
            catch (FormatException)
            {
                MessageBox.Show("Please provide numeric values. Method not called.", "Wrong parameter");
            }

            try
            {
                int[,] postfixValues = new int[2, 10];

                for (int i = 0; i < 10; i++)
                {
                    postfixValues[0, i] = Convert.ToInt32(_dgBarcodePostfix.Rows[0].Cells[i * 2].Value);
                    postfixValues[1, i] = Convert.ToInt32(_dgBarcodePostfix.Rows[0].Cells[i * 2 + 1].Value);
                }

                _BarcodePostfix = postfixValues;
            }
            catch (FormatException)
            {
                MessageBox.Show("Please provide numeric values. Method not called.", "Wrong parameter");
            }

            _BarcodeLayout = _txtLayoutID.Text;

            LogBeginCall("_IDPMDevice.PutBarcodeKeyboardSettings()");
            _IDPMDevice.PutBarcodeKeyboardSettings(_BarcodeLayout, ref _BarcodePrefix, ref _BarcodePostfix);
            LogFinishCall();
        }
        #endregion

        #region FileInfoPage
        private void btnFLSelectFile_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo = _DPMControl.get_FileInfo(Path.Combine (_IDPMFileList.Path, cmbFLFileList.Text));
            UpdateFileInfoPanelVisibility();
        }

        private void UpdateFileInfoPanelVisibility()
        {
            ResetUI(fileInfoPanel);
            if (_IDPMFileInfo != null)
            {
                fileInfoPanel.Visible = true;
                tabControl1.SelectedIndex = 6;
            }
            else
            {
                fileInfoPanel.Visible = false;
            }
            //s _IDPMFileInfo.Author
            //s _IDPMFileInfo.BarcodeString
            //e _IDPMFileInfo.CompressionMode
            //i _IDPMFileInfo.DictationLength
            //s _IDPMFileInfo.DownloadDate
            //s _IDPMFileInfo.DownloadTime
            //b _IDPMFileInfo.EOL
            //s _IDPMFileInfo.FileName
            //e _IDPMFileInfo.FileType
            //s _IDPMFileInfo.FirmwareVersion
            //s _IDPMFileInfo.get_KeywordContentString(i index
            //s _IDPMFileInfo.get_KeywordUsageString(i index
            //s _IDPMFileInfo.get_UserString( i index
            //b _IDPMFileInfo.InstructionFileExists
            //s _IDPMFileInfo.InstructionFileName
            //i _IDPMFileInfo.InstructionLength
            //b _IDPMFileInfo.IsEncrypted
            //i _IDPMFileInfo.JobNumber
            //i _IDPMFileInfo.KeywordContentCount
            //i _IDPMFileInfo.KeywordUsageCount
            //s _IDPMFileInfo.LastModifiedDate
            //s _IDPMFileInfo.LastModifiedTime
            //s _IDPMFileInfo.MACAddress
            //i _IDPMFileInfo.Priority
            //i _IDPMFileInfo.ProductId
            //s _IDPMFileInfo.RecordingEndDate
            //s _IDPMFileInfo.RecordingEndTime
            //s _IDPMFileInfo.RecordingStartDate
            //s _IDPMFileInfo.RecordingStartTime
            //_IDPMFileInfo.set_KeywordContentString( indexer, s pval
            //_IDPMFileInfo.set_KeywordUsageString(index, string pval
            //_IDPMFileInfo.set_UserString( i indexer, string pval
            //o _IDPMFileInfo.SpokenInstructionList
            //int _IDPMFileInfo.UserStringCount
        }

        private void btnFIAuthor_Click(object sender, EventArgs e)
        {
            textFIAuthor.Text = _IDPMFileInfo.Author;
        }

        private void btnFIBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            dlgOpen.CheckFileExists = false;
            dlgOpen.RestoreDirectory = true;
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textFISourceFileNameAndPath.Text = dlgOpen.FileName;
            }
        }

        private void btnFISetFile_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo = _DPMControl.get_FileInfo(textFISourceFileNameAndPath.Text);
            UpdateFileInfoPanelVisibility();
        }

        private void btnFIBarcodeString_Click(object sender, EventArgs e)
        {
            textFIBarcodeString.Text = _IDPMFileInfo.BarcodeString;
        }

        private void btnFICompressionMode_Click(object sender, EventArgs e)
        {
            textFICompressionMode.Text = _IDPMFileInfo.CompressionMode.ToString();
        }

        private void btnFIDictationLength_Click(object sender, EventArgs e)
        {
            textFIDictationLength.Text = _IDPMFileInfo.DictationLength.ToString();
        }

        private void btnFIAuthorSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.Author = textFIAuthor.Text;
        }

        private void btnFIDownloadDate_Click(object sender, EventArgs e)
        {
            textFIDownloadDate.Text = _IDPMFileInfo.DownloadDate;
        }

        private void btnFIDownloadDateSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.DownloadDate = textFIDownloadDate.Text;
        }

        private void btnFIDownloadTime_Click(object sender, EventArgs e)
        {
            textFIDownloadTime.Text = _IDPMFileInfo.DownloadTime;
        }

        private void btnFIDownloadTimeSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.DownloadTime = textFIDownloadTime.Text;
        }

        private void btnFIEOL_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbFIEOL, _IDPMFileInfo.EOL);
        }

        private void btnFIEOLSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.EOL = cbFIEOL.Checked;
        }

        private void btnFIFileName_Click(object sender, EventArgs e)
        {
            textFIFileName.Text = _IDPMFileInfo.FileName;
        }

        private void btnFIFileType_Click(object sender, EventArgs e)
        {
            textFIFileType.Text = _IDPMFileInfo.FileType.ToString(); ;
        }

        private void btnFIFirmwareVersion_Click(object sender, EventArgs e)
        {
            textFIFirmwareVersion.Text = _IDPMFileInfo.FirmwareVersion;
        }

        private void btnFIInstructionFileExists_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbFIInstructionFileExists, _IDPMFileInfo.InstructionFileExists);
        }

        private void btnFIKeywordContentStringGet_Click(object sender, EventArgs e)
        {
            textFIKeywordContentString.Text = _IDPMFileInfo.get_KeywordContentString((int)numFIKeywordContentStringIndex.Value);
        }

        private void btnFIKeywordContentStringSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.set_KeywordContentString((int)numFIKeywordContentStringIndex.Value, textFIKeywordContentString.Text);
        }

        private void btnFIKeywordUsageStringGet_Click(object sender, EventArgs e)
        {
            textFIKeywordUsageString.Text = _IDPMFileInfo.get_KeywordUsageString((int)numFIKeywordUsageStringIndex.Value);
        }

        private void btnFIKeywordUsageStringSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.set_KeywordUsageString((int)numFIKeywordUsageStringIndex.Value, textFIKeywordUsageString.Text);
        }

        private void btnFIUserStringGet_Click(object sender, EventArgs e)
        {
            textFIUserString.Text = _IDPMFileInfo.get_UserString((int)numFIUserStringIndex.Value);
        }

        private void btnFIUserStringSet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.set_UserString((int)numFIUserStringIndex.Value, textFIUserString.Text);
        }

        private void btnFIInstructionFileName_Click(object sender, EventArgs e)
        {
            textFIInstructionFileName.Text = _IDPMFileInfo.InstructionFileName;
        }

        private void btnFIInstructionLength_Click(object sender, EventArgs e)
        {
            textFIInstructionLength.Text = _IDPMFileInfo.InstructionLength.ToString();
        }

        private void btnFIJobNumber_Click(object sender, EventArgs e)
        {
            textFIJobNumber.Text = _IDPMFileInfo.JobNumber.ToString();
        }

        private void btnFIKeywordContentCount_Click(object sender, EventArgs e)
        {
            textFIKeywordContentCount.Text = _IDPMFileInfo.KeywordContentCount.ToString();
        }

        private void btnFIKeywordUsageCount_Click(object sender, EventArgs e)
        {
            textFIKeywordUsageCount.Text = _IDPMFileInfo.KeywordUsageCount.ToString();
        }

        private void btnFILastModifiedDate_Click(object sender, EventArgs e)
        {
            textFILastModifiedDate.Text = _IDPMFileInfo.LastModifiedDate;
        }

        private void btnFILastModifiedTime_Click(object sender, EventArgs e)
        {
            textFILastModifiedTime.Text = _IDPMFileInfo.LastModifiedTime;
        }

        private void btnFIMACAddress_Click(object sender, EventArgs e)
        {
            textFIMACAddress.Text = _IDPMFileInfo.MACAddress;
        }

        private void btnFIPriorityGet_Click(object sender, EventArgs e)
        {
            numFIPriority.Value = _IDPMFileInfo.Priority;
        }

        private void btnFIPrioritySet_Click(object sender, EventArgs e)
        {
            _IDPMFileInfo.Priority = (int)numFIPriority.Value;
        }

        private void btnFIProductId_Click(object sender, EventArgs e)
        {
            textFIProductId.Text = _IDPMFileInfo.ProductId.ToString();
        }

        private void btnFIRecordingEndDate_Click(object sender, EventArgs e)
        {
            textFIRecordingEndDate.Text = _IDPMFileInfo.RecordingEndDate;
        }

        private void btnFIRecordingEndTime_Click(object sender, EventArgs e)
        {
            textFIRecordingEndTime.Text = _IDPMFileInfo.RecordingEndTime;
        }

        private void btnFIRecordingStartDate_Click(object sender, EventArgs e)
        {
            textFIRecordingStartDate.Text = _IDPMFileInfo.RecordingStartDate;
        }

        private void btnFIRecordingStartTime_Click(object sender, EventArgs e)
        {
            textFIRecordingStartTime.Text = _IDPMFileInfo.RecordingStartTime;
        }

        private void btnFIUserStringCount_Click(object sender, EventArgs e)
        {
            textFIUserStringCount.Text = _IDPMFileInfo.UserStringCount.ToString();
        }

        private void btnFIIsEncrypted_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbFIIsEncrypted, _IDPMFileInfo.IsEncrypted);
        }

        private void btnFISpokenInstructionList_Click(object sender, EventArgs e)
        {
            SpokenInstructionListForm sil = new SpokenInstructionListForm();
            sil.SpokenInstructions = (int[,])_IDPMFileInfo.SpokenInstructionList;
            sil.ShowDialog();
        }
#endregion
        #region DPMCtrlPage
        private void btnBarcodeModuleStatusGet_Click(object sender, EventArgs e)
        {
            textBarcodeModuleStatus.Text = _DPMControl.BarcodeModuleStatus.ToString();
        }

        private void btnDeviceStatus_Click(object sender, EventArgs e)
        {
            textDeviceStatus.Text = _DPMControl.DeviceStatus.ToString();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            //_DPMControl.set_CustomAudioFormat(
            _DPMControl.Convert(textbstrFileName.Text, textbstrDestPath.Text, (dpmAudioFormat)(cmbConvertAudioFormat.SelectedItem), cbDelayTasks.Checked);
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            _DPMControl.Copy(textbstrFileName.Text, textbstrDestPath.Text, cbDelayTasks.Checked);
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            _DPMControl.Decrypt(textbstrFileName.Text, textbstrDestPath.Text, (dpmAudioFormat)(cmbDecryptAudioFormat.SelectedItem), cbDelayTasks.Checked, textDecryptbstrPassword.Text);
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            _DPMControl.Move(textbstrFileName.Text, textbstrDestPath.Text, cbDelayTasks.Checked);
        }

        private void btnNewFile_Click(object sender, EventArgs e)
        {
            _DPMControl.NewFile(textbstrFileNameNewFile.Text, textNewFilePassword.Text, (dpmCompressionMode)(cmbNewFileCompressionMode.SelectedItem));
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            _DPMControl.Delete(textbstrFileName.Text, cbDelayTasks.Checked);
        }

        private void btnStartDelayedTasks_Click(object sender, EventArgs e)
        {
            _DPMControl.StartDelayedTasks();
        }

        private void btnSeparateSpokenInstructions_Click(object sender, EventArgs e)
        {
            _DPMControl.SeparateSpokenInstructions(textbstrFileName.Text, textbstrDestPath.Text, cbSeparateSpokenInstructionsbCreateDictation.Checked, cbSeparateSpokenInstructionsbCreateInstruction.Checked, cbDelayTasks.Checked);
        }

        private void btnbstrFileNameBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            dlgOpen.CheckFileExists = false;
            dlgOpen.RestoreDirectory = true;
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textbstrFileName.Text = dlgOpen.FileName;
            }
        }

        private void btnbstrDestPathBrowse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlgOpen = new FolderBrowserDialog();
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textbstrDestPath.Text = dlgOpen.SelectedPath;
            }
        }
        #endregion
        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            textLog.Text = string.Empty;
        }

        private void btnbstrFileNameBrowseNewFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlgOpen = new OpenFileDialog();
            dlgOpen.CheckFileExists = false;
            dlgOpen.RestoreDirectory = true;
            if (dlgOpen.ShowDialog() == DialogResult.OK)
            {
                textbstrFileNameNewFile.Text = dlgOpen.FileName;
            }
        }
        
        private dpmWAVEFORMATEX CustomAudioFormat;

        private void btnDCEditCustomAudioFormat_Click(object sender, EventArgs e)
        {
            CustomFormatEditForm editor = new CustomFormatEditForm(CustomAudioFormat);
            if (editor.ShowDialog(this) == DialogResult.OK)
            {
                CustomAudioFormat = editor.Result;
            }
            _DPMControl.set_CustomAudioFormat(ref CustomAudioFormat);
        }

        private void EnableAssociatedSetButton(object sender, EventArgs e)
        {
            var button = ((Control)sender).Tag as Button;
            if (button != null)
            {
                button.Enabled = true;
            }
        }

        private void btnGetIFileList_Click(object sender, EventArgs e)
        {
            _IDPMFileList = _DPMControl.FileList;
            if (_IDPMFileList != null)
            {
                fileListPanel.Visible = true;
            }
            else
            {
                fileListPanel.Visible = false;
            }
        }

        private void btnDSSPro256EnabledGet_Click (object sender, EventArgs e)
        {
            SetCheckboxState (cbDSSPro256Enabled, _DPMControl.DSSPro256Enabled);
        }

        private void btnDSSPro256EnabledSet_Click (object sender, EventArgs e)
        {
            _DPMControl.DSSPro256Enabled = cbDSSPro256Enabled.Checked;
        }

        private void ResetToFactoryDefaultsButton_Click (object sender, EventArgs e)
        {
            _IDPMDevice.ResetToFactoryDefaults ();
        }


        private void KeywordDisplayAreaStrings_GetButton_Click (object sender, EventArgs e)
        {
            KeywordDisplayAreaStringsCombo.SelectedItem = _IDPMDeviceSettings.get_KeywordDisplayAreaStrings ((int)KeywordDisplayAreaStringsIndexNum.Value);
        }

        private void KeywordDisplayAreaStrings_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.set_KeywordDisplayAreaStrings ((int)KeywordDisplayAreaStringsIndexNum.Value, (dpmDisplayAreaString)KeywordDisplayAreaStringsCombo.SelectedItem);
        }

        private void EditMode_GetButton_Click (object sender, EventArgs e)
        {
            EditModeCombo.SelectedItem = _IDPMDeviceSettings.EditMode;
        }

        private void EditMode_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.EditMode = (dpmEditMode)EditModeCombo.SelectedItem;
        }

        private void FootpedalMode_GetButton_Click (object sender, EventArgs e)
        {
            FootpedalModeCombo.SelectedItem = _IDPMDeviceSettings.FootpedalMode;
        }

        private void FootpedalMode_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.FootpedalMode = (dpmFootpedalMode)FootpedalModeCombo.SelectedItem;
        }

        private bool CheckSmartButtonConfigurationParameters ()
        {
            if (SmartButtonConfiguration_ButtonIndexCombo.SelectedItem == null || SmartButtonConfiguration_RecordingStateCombo.SelectedItem == null)
            {
                LogLine (Color.Red, "Please specify buttonIndex and recordingState for SmartButtonConfiguration");
                return false;
            }
            else
            {
                return true;
            }
        }

        private void SmartButtonConfiguration_GetButton_Click (object sender, EventArgs e)
        {
            if (!CheckSmartButtonConfigurationParameters ()) return;
            SmartButtonConfigurationCombo.SelectedItem = _IDPMDeviceSettings.get_SmartButtonConfiguration ((dpmSmartButtons)SmartButtonConfiguration_ButtonIndexCombo.SelectedItem, (dpmRecordingState)SmartButtonConfiguration_RecordingStateCombo.SelectedItem);
        }

        private void SmartButtonConfiguration_SetButton_Click (object sender, EventArgs e)
        {
            if (!CheckSmartButtonConfigurationParameters ()) return;
            _IDPMDeviceSettings.set_SmartButtonConfiguration ((dpmSmartButtons)SmartButtonConfiguration_ButtonIndexCombo.SelectedItem, (dpmRecordingState)SmartButtonConfiguration_RecordingStateCombo.SelectedItem, (dpmSmartButtonConfiguration)SmartButtonConfigurationCombo.SelectedItem);
        }

        private void Backlight_GetButton_Click (object sender, EventArgs e)
        {
            BacklightCombo.SelectedItem = _IDPMDeviceSettings.Backlight;
        }

        private void Backlight_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.Backlight = (dpmBacklight)BacklightCombo.SelectedItem;
        }

        private void PlusButtonEnabled_GetButton_Click (object sender, EventArgs e)
        {
            SetCheckboxState (PlusButtonEnabledCheck, _IDPMDeviceSettings.PlusButtonEnabled);
        }

        private void PlusButtonEnabled_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.PlusButtonEnabled = PlusButtonEnabledCheck.Checked;
        }

        private void MinusButtonEnabled_GetButton_Click (object sender, EventArgs e)
        {
            SetCheckboxState (MinusButtonEnabledCheck, _IDPMDeviceSettings.MinusButtonEnabled);
        }

        private void MinusButtonEnabled_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.MinusButtonEnabled = MinusButtonEnabledCheck.Checked;
        }

        private void IsAuthorPinListUsed_GetButton_Click (object sender, EventArgs e)
        {
            SetCheckboxState (IsAuthorPinListUsedCheck, _IDPMDeviceSettings.IsAuthorPinListUsed);
        }

        private void IsAuthorPinListUsed_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.IsAuthorPinListUsed = IsAuthorPinListUsedCheck.Checked;
        }

        private void ActiveRecordingProfile_GetButton_Click (object sender, EventArgs e)
        {
            ActiveRecordingProfileCombo.SelectedItem = _IDPMDeviceSettings.ActiveRecordingProfile;
        }

        private void ActiveRecordingProfile_SetButton_Click (object sender, EventArgs e)
        {
            _IDPMDeviceSettings.ActiveRecordingProfile = (dpmRecordingProfile)ActiveRecordingProfileCombo.SelectedItem;
        }

        private void RecordingProfile_GetButton_Click (object sender, EventArgs e)
        {
            if (RecordingProfileCombo.SelectedItem == null)
            {
                LogLine (Color.Red, "Please specify recording profile");
                return;
            }

            ResetUI (RecordingProfileGroup);
            _CurrentRecordingProfile = _IDPMDeviceSettings.get_RecordingProfile ((dpmRecordingProfile)RecordingProfileCombo.SelectedItem);
            RecordingProfileGroup.Text = ((dpmRecordingProfile)RecordingProfileCombo.SelectedItem).ToString ();
            RecordingProfileGroup.Visible = true;
        }

        private IDPMRecordingProfile _CurrentRecordingProfile;

        private void RecordingModeOnRecordingProfile_GetButton_Click (object sender, EventArgs e)
        {
            RecordingModeOnRecordingProfileCombo.SelectedItem = _CurrentRecordingProfile.RecordingMode;
        }

        private void RecordingModeOnRecordingProfile_SetButton_Click (object sender, EventArgs e)
        {
            _CurrentRecordingProfile.RecordingMode = (dpmCompressionMode)RecordingModeOnRecordingProfileCombo.SelectedItem;

        }

        private void MicrophoneSensitivityOnRecordingProfile_GetButton_Click (object sender, EventArgs e)
        {
            MicrophoneSensitivityOnRecordingProfileCombo.SelectedItem = _CurrentRecordingProfile.MicrophoneSensitivity;
        }

        private void MicrophoneSensitivityOnRecordingProfile_SetButton_Click (object sender, EventArgs e)
        {
            _CurrentRecordingProfile.MicrophoneSensitivity = (dpmMicrophoneSensitivity)MicrophoneSensitivityOnRecordingProfileCombo.SelectedItem;
        }

        private bool CheckMicrophoneDirectivityOnRecordingProfileParameters ()
        {
            if (MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.SelectedItem == null)
            {
                LogLine (Color.Red, "Please specify index for MicrophoneDirectivity");
                return false;
            }
            else
            {
                return true;
            }
        }

        private void MicrophoneDirectivityOnRecordingProfile_GetButton_Click (object sender, EventArgs e)
        {
            if (!CheckMicrophoneDirectivityOnRecordingProfileParameters ()) return;
            MicrophoneDirectivityOnRecordingProfileCombo.SelectedItem = _CurrentRecordingProfile.get_MicrophoneDirectivity ((dpmDevicePosition)MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.SelectedItem);
        }

        private void MicrophoneDirectivityOnRecordingProfile_SetButton_Click (object sender, EventArgs e)
        {
            if (!CheckMicrophoneDirectivityOnRecordingProfileParameters ()) return;
            _CurrentRecordingProfile.set_MicrophoneDirectivity ((dpmDevicePosition)MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.SelectedItem, (dpmMicrophoneDirectivity)MicrophoneDirectivityOnRecordingProfileCombo.SelectedItem);
        }

        private void WelcomeScreenHashGetButton_Click (object sender, EventArgs e)
        {
            LogBeginCall ("(get) _IDPMDevice.WelcomeScreenHashGetButton");
            string formattedValue = String.Empty;

            var value = _IDPMDevice.WelcomeScreenHash;
            if (value != null && value is byte[])
            {
                var formatter = new System.Text.StringBuilder (40);
                foreach (var b in (byte[])value)
                {
                    formatter.AppendFormat ("{0:X2}", b);
                }
                formattedValue = WelcomeScreenHashTxt.Text = formatter.ToString ();
            }

            LogFinishCall (formattedValue);
        }

        private void btnDisplaySymbolsEnabledGet_Click(object sender, EventArgs e)
        {
            SetCheckboxState(cbDisplaySymbolsEnabled, _DPMControl.DisplaySymbolsEnabled);
        }

        private void btnDisplaySymbolsEnabledSet_Click(object sender, EventArgs e)
        {
            _DPMControl.DisplaySymbolsEnabled = cbDisplaySymbolsEnabled.Checked;                        
        }
     }
}
