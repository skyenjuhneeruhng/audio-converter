﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TestDPMCtrl
{
    public partial class SpokenInstructionListForm : Form
    {
        public int[,] SpokenInstructions
        {
            set
            {
                if (value.Length > 0)
                {
                    DataGridViewTextBoxColumn columnStart = new DataGridViewTextBoxColumn();
                    DataGridViewTextBoxColumn columnStop = new DataGridViewTextBoxColumn();
                    columnStop.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    columnStart.Resizable = DataGridViewTriState.False;
                    columnStart.Name = "Start";
                    columnStop.Name = "Stop";

                    dataGridViewSpokenInstructionList.Columns.Add(columnStart);
                    dataGridViewSpokenInstructionList.Columns.Add(columnStop);

                    int[,] spokenInstructionList = value;
                    for (int i = 0; i < spokenInstructionList.Length / 2; i++)
                    {
                        DataGridViewRow dgvRow = new DataGridViewRow();
                        dgvRow.HeaderCell.Value = (i+1).ToString();

                        dgvRow.Resizable = DataGridViewTriState.False;
                        dataGridViewSpokenInstructionList.Rows.Add(dgvRow);
                        dataGridViewSpokenInstructionList.Rows[i].Cells[0].Value = spokenInstructionList[0, i];
                        dataGridViewSpokenInstructionList.Rows[i].Cells[1].Value = spokenInstructionList[1, i];
                    }
                }
            }
        }
        public SpokenInstructionListForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
