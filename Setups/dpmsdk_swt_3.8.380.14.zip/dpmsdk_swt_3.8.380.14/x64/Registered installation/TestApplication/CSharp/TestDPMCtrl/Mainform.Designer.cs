﻿namespace TestDPMCtrl
{
    partial class Mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.deviceSettingsTabPage = new System.Windows.Forms.TabPage();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.btnPutSettingsToDevice = new System.Windows.Forms.Button();
            this.btnConfigFileBrowse = new System.Windows.Forms.Button();
            this.textConfigFilePath = new System.Windows.Forms.TextBox();
            this.btnGetSettingsFromDevice = new System.Windows.Forms.Button();
            this.btnExportConfig = new System.Windows.Forms.Button();
            this.deviceSettingsTabControl = new System.Windows.Forms.TabControl();
            this.deviceSettings1TabPage = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.btnDSTotalTimeTypeSet = new System.Windows.Forms.Button();
            this.btnDSTotalTimeTypeGet = new System.Windows.Forms.Button();
            this.btnDSRequiredInputTypeSet = new System.Windows.Forms.Button();
            this.btnDSRequiredInputTypeGet = new System.Windows.Forms.Button();
            this.btnDSRecordingModeSet = new System.Windows.Forms.Button();
            this.btnDSRecordingModeGet = new System.Windows.Forms.Button();
            this.btnDSOsSet = new System.Windows.Forms.Button();
            this.btnDSOsGet = new System.Windows.Forms.Button();
            this.btnDSMicrophoneSensitivitySet = new System.Windows.Forms.Button();
            this.btnDSMicrophoneSensitivityGet = new System.Windows.Forms.Button();
            this.btnDSLowerAreaSet = new System.Windows.Forms.Button();
            this.btnDSLowerAreaGet = new System.Windows.Forms.Button();
            this.btnDSFunctionKeySet = new System.Windows.Forms.Button();
            this.btnDSFunctionKeyGet = new System.Windows.Forms.Button();
            this.cmbTotalTimeType = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbRequiredInputType = new System.Windows.Forms.ComboBox();
            this.cmbRecordingMode = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbOS = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbMicrophoneSensitivity = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbLowerArea = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbFunctionKey = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnDSFourPosSwitchSet = new System.Windows.Forms.Button();
            this.btnDSFourPosSwitchGet = new System.Windows.Forms.Button();
            this.btnDSFileNamePrefixSet = new System.Windows.Forms.Button();
            this.btnDSFileNamePrefixGet = new System.Windows.Forms.Button();
            this.btnDSFileCounterSourceSet = new System.Windows.Forms.Button();
            this.btnDSFileCounterSourceGet = new System.Windows.Forms.Button();
            this.btnDSDateTimeFormatSet = new System.Windows.Forms.Button();
            this.btnDSDateTimeFormatGet = new System.Windows.Forms.Button();
            this.btnDSBarCodeScanButtonSet = new System.Windows.Forms.Button();
            this.btnDSBarCodeScanButtonGet = new System.Windows.Forms.Button();
            this.btnDSBarcodeModeSet = new System.Windows.Forms.Button();
            this.btnDSBarcodeModeGet = new System.Windows.Forms.Button();
            this.cmbFourPosSwitch = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbFileNamePrefixType = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbFileCounterSource = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbDateTimeFormat = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbBarcodeScanButton = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbBarcodeMode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDSAppearanceSet = new System.Windows.Forms.Button();
            this.btnDSAppearanceGet = new System.Windows.Forms.Button();
            this.AppearanceLabel = new System.Windows.Forms.Label();
            this.cmbAppearance = new System.Windows.Forms.ComboBox();
            this.deviceSettings2TabPage = new System.Windows.Forms.TabPage();
            this.btnDSObligatoryKeywordSelectionSet = new System.Windows.Forms.Button();
            this.btnDSObligatoryKeywordSelectionGet = new System.Windows.Forms.Button();
            this.cbObligatoryKeywordSelection = new System.Windows.Forms.CheckBox();
            this.btnDSMassStorageWriteProtectionSet = new System.Windows.Forms.Button();
            this.btnDSMassStorageWriteProtectionGet = new System.Windows.Forms.Button();
            this.cbMassStorageWriteProtection = new System.Windows.Forms.CheckBox();
            this.btnDSVoiceActivationSet = new System.Windows.Forms.Button();
            this.btnDSVoiceActivationGet = new System.Windows.Forms.Button();
            this.cbVoiceActivation = new System.Windows.Forms.CheckBox();
            this.btnDSUSBHighPowerModeSet = new System.Windows.Forms.Button();
            this.btnDSUSBHighPowerModeGet = new System.Windows.Forms.Button();
            this.btnDSScanKeywordsFromBarcodeSet = new System.Windows.Forms.Button();
            this.btnDSScanKeywordsFromBarcodeGet = new System.Windows.Forms.Button();
            this.btnDSRecordNotifySet = new System.Windows.Forms.Button();
            this.btnDSRecordNotifyGet = new System.Windows.Forms.Button();
            this.btnDSRecordLevelSet = new System.Windows.Forms.Button();
            this.btnDSRecordLevelGet = new System.Windows.Forms.Button();
            this.cbUSBHighPowerMode = new System.Windows.Forms.CheckBox();
            this.cbScanKeywordsFromBarcode = new System.Windows.Forms.CheckBox();
            this.cbRecordNotify = new System.Windows.Forms.CheckBox();
            this.cbRecordLevelInd = new System.Windows.Forms.CheckBox();
            this.btnDSProtectDeviceSet = new System.Windows.Forms.Button();
            this.btnDSProtectDeviceGet = new System.Windows.Forms.Button();
            this.btnDSProModeSet = new System.Windows.Forms.Button();
            this.btnDSProModeGet = new System.Windows.Forms.Button();
            this.btnDSProhibitFileAlterationSet = new System.Windows.Forms.Button();
            this.btnDSProhibitFileAlterationGet = new System.Windows.Forms.Button();
            this.btnDSPCMEnabledSet = new System.Windows.Forms.Button();
            this.btnDSPCMEnabledGet = new System.Windows.Forms.Button();
            this.btnDSOneFileSet = new System.Windows.Forms.Button();
            this.btnDSOneFileGet = new System.Windows.Forms.Button();
            this.btnDSNoiseReductionSet = new System.Windows.Forms.Button();
            this.btnDSNoiseReductionGet = new System.Windows.Forms.Button();
            this.btnDSLinkKeywordsSet = new System.Windows.Forms.Button();
            this.btnDSLinkKeywordsGet = new System.Windows.Forms.Button();
            this.btnDSInsertButtonEnabledSet = new System.Windows.Forms.Button();
            this.btnDSInsertButtonEnabledGet = new System.Windows.Forms.Button();
            this.cbProtectDevice = new System.Windows.Forms.CheckBox();
            this.cbProMode = new System.Windows.Forms.CheckBox();
            this.cbProhibitFileAlteration = new System.Windows.Forms.CheckBox();
            this.cbPCMEnabled = new System.Windows.Forms.CheckBox();
            this.cbOneFile = new System.Windows.Forms.CheckBox();
            this.cbNoiseReduction = new System.Windows.Forms.CheckBox();
            this.cbLinkKeywords = new System.Windows.Forms.CheckBox();
            this.cbInsertButtonEnabled = new System.Windows.Forms.CheckBox();
            this.btnDSEOLButtonEnabledSet = new System.Windows.Forms.Button();
            this.btnDSEOLButtonEnabledGet = new System.Windows.Forms.Button();
            this.btnDSEnableUSBAudioSet = new System.Windows.Forms.Button();
            this.btnDSEnabledUSBAudioGet = new System.Windows.Forms.Button();
            this.btnDSDLSButtonEnabledSet = new System.Windows.Forms.Button();
            this.btnDSDLSButtonEnabledGet = new System.Windows.Forms.Button();
            this.btnDSDeviceBeepSet = new System.Windows.Forms.Button();
            this.btnDSDeviceBeepGet = new System.Windows.Forms.Button();
            this.cbEOLButtonEnabled = new System.Windows.Forms.CheckBox();
            this.cbEnableUSBAudio = new System.Windows.Forms.CheckBox();
            this.cbDLSButtonEnabled = new System.Windows.Forms.CheckBox();
            this.cbDeviceBeep = new System.Windows.Forms.CheckBox();
            this.btnDSDeleteFilesAfterDownloadSet = new System.Windows.Forms.Button();
            this.btnDSDeleteFilesAfterDownloadGet = new System.Windows.Forms.Button();
            this.btnDSDELButtonEnabledSet = new System.Windows.Forms.Button();
            this.btnDSDELButtonEnabledGet = new System.Windows.Forms.Button();
            this.btnDSCueReviewSoundSet = new System.Windows.Forms.Button();
            this.btnDSCueReviewSoundGet = new System.Windows.Forms.Button();
            this.cbDeleteFilesAfterDownload = new System.Windows.Forms.CheckBox();
            this.cbDELButtonEnabled = new System.Windows.Forms.CheckBox();
            this.cbCueReviewSound = new System.Windows.Forms.CheckBox();
            this.btnDSAppendModeSet = new System.Windows.Forms.Button();
            this.btnDSAppendModeGet = new System.Windows.Forms.Button();
            this.cbAppendMode = new System.Windows.Forms.CheckBox();
            this.deviceSettings3TabPage = new System.Windows.Forms.TabPage();
            this.numSliderJumpBackTime = new System.Windows.Forms.NumericUpDown();
            this.btnDSSliderJumpBackTimeSet = new System.Windows.Forms.Button();
            this.btnDSSliderJumpBackTimeGet = new System.Windows.Forms.Button();
            this.label82 = new System.Windows.Forms.Label();
            this.numUserStringCount = new System.Windows.Forms.NumericUpDown();
            this.btnDSUserStringCountSet = new System.Windows.Forms.Button();
            this.btnDSUserStringCountGet = new System.Windows.Forms.Button();
            this.btnDSLockTimeSet = new System.Windows.Forms.Button();
            this.btnLockTimeGet = new System.Windows.Forms.Button();
            this.btnDSKeywordUsageCountGet = new System.Windows.Forms.Button();
            this.btnDSKeywordContentCountGet = new System.Windows.Forms.Button();
            this.btnDSDownloadFilterSet = new System.Windows.Forms.Button();
            this.btnDSDownloadFilterGet = new System.Windows.Forms.Button();
            this.btnDSDownloadModeSet = new System.Windows.Forms.Button();
            this.btnDSDownloadModeGet = new System.Windows.Forms.Button();
            this.btnDSFileCounterSet = new System.Windows.Forms.Button();
            this.btnDSFileCounterGet = new System.Windows.Forms.Button();
            this.btnDSDisplayKeywordsSet = new System.Windows.Forms.Button();
            this.btnDSDisplayKeywordsGet = new System.Windows.Forms.Button();
            this.numLockTime = new System.Windows.Forms.NumericUpDown();
            this.numKeywordUsageCount = new System.Windows.Forms.NumericUpDown();
            this.numKeywordContentCount = new System.Windows.Forms.NumericUpDown();
            this.numDownloadFilter = new System.Windows.Forms.NumericUpDown();
            this.numDownloadMode = new System.Windows.Forms.NumericUpDown();
            this.numFileCounter = new System.Windows.Forms.NumericUpDown();
            this.numDisplayKeywords = new System.Windows.Forms.NumericUpDown();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.btnDSMACAddressGet = new System.Windows.Forms.Button();
            this.btnDSKeyword1StringSet = new System.Windows.Forms.Button();
            this.btnDSKeyword1StringGet = new System.Windows.Forms.Button();
            this.btnDSFirmwareVersionGet = new System.Windows.Forms.Button();
            this.btnDSFileNamePrefixStringSet = new System.Windows.Forms.Button();
            this.btnDSFileNamePrefixStringGet = new System.Windows.Forms.Button();
            this.textDSMACAddress = new System.Windows.Forms.TextBox();
            this.textKeyword1String = new System.Windows.Forms.TextBox();
            this.textDSFirmwareVersion = new System.Windows.Forms.TextBox();
            this.textFileNamePrefixString = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.deviceSettings4TabPage = new System.Windows.Forms.TabPage();
            this.label53 = new System.Windows.Forms.Label();
            this.numKeywordContentStringUsageIndex = new System.Windows.Forms.NumericUpDown();
            this.cmbVoiceCommandType = new System.Windows.Forms.ComboBox();
            this.btnDSVoiceCommandTypeSet = new System.Windows.Forms.Button();
            this.btnDSVoiceCommandTypeGet = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.numVoiceCommandTypeIndex = new System.Windows.Forms.NumericUpDown();
            this.btnDSKeywordUsageStringSet = new System.Windows.Forms.Button();
            this.btnKeywordUsageStringGet = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.numKeywordUsageStringIndex = new System.Windows.Forms.NumericUpDown();
            this.btnDSKeywordContentStringSet = new System.Windows.Forms.Button();
            this.btnDSKeywordContentStringGet = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.numKeywordContentStringContentIndex = new System.Windows.Forms.NumericUpDown();
            this.textKeywordUsageString = new System.Windows.Forms.TextBox();
            this.textKeywordContentString = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.btnDSKeywordVoiceCommandSet = new System.Windows.Forms.Button();
            this.btnDSKeywordVoiceCommandGet = new System.Windows.Forms.Button();
            this.numKeywordVoiceCommandIndex = new System.Windows.Forms.NumericUpDown();
            this.cbKeywordVoiceCommand = new System.Windows.Forms.CheckBox();
            this.label45 = new System.Windows.Forms.Label();
            this.btnKeywordMandatorySet = new System.Windows.Forms.Button();
            this.btnKeywordMandatoryGet = new System.Windows.Forms.Button();
            this.numKeywordMandatoryIndex = new System.Windows.Forms.NumericUpDown();
            this.cbKeywordMandatory = new System.Windows.Forms.CheckBox();
            this.label44 = new System.Windows.Forms.Label();
            this.btnKeywordBarcodeScanSet = new System.Windows.Forms.Button();
            this.btnKeywordBarcodeScanGet = new System.Windows.Forms.Button();
            this.numKeywordBarcodeScanIndex = new System.Windows.Forms.NumericUpDown();
            this.cbKeywordBarcodeScan = new System.Windows.Forms.CheckBox();
            this.deviceSettings5TabPage = new System.Windows.Forms.TabPage();
            this.IsAuthorPinListUsed_SetButton = new System.Windows.Forms.Button();
            this.MinusButtonEnabled_SetButton = new System.Windows.Forms.Button();
            this.PlusButtonEnabled_SetButton = new System.Windows.Forms.Button();
            this.IsAuthorPinListUsed_GetButton = new System.Windows.Forms.Button();
            this.MinusButtonEnabled_GetButton = new System.Windows.Forms.Button();
            this.PlusButtonEnabled_GetButton = new System.Windows.Forms.Button();
            this.IsAuthorPinListUsedCheck = new System.Windows.Forms.CheckBox();
            this.MinusButtonEnabledCheck = new System.Windows.Forms.CheckBox();
            this.PlusButtonEnabledCheck = new System.Windows.Forms.CheckBox();
            this.Backlight_SetButton = new System.Windows.Forms.Button();
            this.Backlight_GetButton = new System.Windows.Forms.Button();
            this.label90 = new System.Windows.Forms.Label();
            this.BacklightCombo = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.KeywordDisplayAreaStringsIndexNum = new System.Windows.Forms.NumericUpDown();
            this.SmartButtonConfiguration_SetButton = new System.Windows.Forms.Button();
            this.FootpedalMode_SetButton = new System.Windows.Forms.Button();
            this.SmartButtonConfiguration_GetButton = new System.Windows.Forms.Button();
            this.FootpedalMode_GetButton = new System.Windows.Forms.Button();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.SmartButtonConfiguration_RecordingStateCombo = new System.Windows.Forms.ComboBox();
            this.SmartButtonConfiguration_ButtonIndexCombo = new System.Windows.Forms.ComboBox();
            this.SmartButtonConfigurationCombo = new System.Windows.Forms.ComboBox();
            this.FootpedalModeCombo = new System.Windows.Forms.ComboBox();
            this.KeywordDisplayAreaStrings_SetButton = new System.Windows.Forms.Button();
            this.KeywordDisplayAreaStrings_GetButton = new System.Windows.Forms.Button();
            this.EditMode_SetButton = new System.Windows.Forms.Button();
            this.EditMode_GetButton = new System.Windows.Forms.Button();
            this.label86 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.KeywordDisplayAreaStringsCombo = new System.Windows.Forms.ComboBox();
            this.EditModeCombo = new System.Windows.Forms.ComboBox();
            this.deviceSettings6TabPage = new System.Windows.Forms.TabPage();
            this.RecordingProfileGroup = new System.Windows.Forms.GroupBox();
            this.MicrophoneDirectivityOnRecordingProfile_SetButton = new System.Windows.Forms.Button();
            this.MicrophoneSensitivityOnRecordingProfile_SetButton = new System.Windows.Forms.Button();
            this.MicrophoneDirectivityOnRecordingProfile_GetButton = new System.Windows.Forms.Button();
            this.MicrophoneSensitivityOnRecordingProfile_GetButton = new System.Windows.Forms.Button();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo = new System.Windows.Forms.ComboBox();
            this.MicrophoneDirectivityOnRecordingProfileCombo = new System.Windows.Forms.ComboBox();
            this.MicrophoneSensitivityOnRecordingProfileCombo = new System.Windows.Forms.ComboBox();
            this.RecordingModeOnRecordingProfile_SetButton = new System.Windows.Forms.Button();
            this.RecordingModeOnRecordingProfile_GetButton = new System.Windows.Forms.Button();
            this.label97 = new System.Windows.Forms.Label();
            this.RecordingModeOnRecordingProfileCombo = new System.Windows.Forms.ComboBox();
            this.RecordingProfile_GetButton = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.RecordingProfileCombo = new System.Windows.Forms.ComboBox();
            this.ActiveRecordingProfile_SetButton = new System.Windows.Forms.Button();
            this.ActiveRecordingProfile_GetButton = new System.Windows.Forms.Button();
            this.label91 = new System.Windows.Forms.Label();
            this.ActiveRecordingProfileCombo = new System.Windows.Forms.ComboBox();
            this.btnImportConfig = new System.Windows.Forms.Button();
            this.capabilitiesTabPage = new System.Windows.Forms.TabPage();
            this.btnDCGetFromIDPMDevice = new System.Windows.Forms.Button();
            this.cmbDeviceCapabilitesDeviceType = new System.Windows.Forms.ComboBox();
            this.btnGetDeviceCapabilities = new System.Windows.Forms.Button();
            this.deviceCapabilitesPanel = new System.Windows.Forms.Panel();
            this.textDcKeywordVoiceCommandMax = new System.Windows.Forms.TextBox();
            this.textDCVendorId = new System.Windows.Forms.TextBox();
            this.textDCUserStringMax = new System.Windows.Forms.TextBox();
            this.textDCProductId = new System.Windows.Forms.TextBox();
            this.textDCKeywordUsageMax = new System.Windows.Forms.TextBox();
            this.textDCMaxKeywordLength = new System.Windows.Forms.TextBox();
            this.textDCKeywordContentMax = new System.Windows.Forms.TextBox();
            this.textDCDisplayModeCount = new System.Windows.Forms.TextBox();
            this.textDCDeviceName = new System.Windows.Forms.TextBox();
            this.btnDCKeywordVoiceCommandMaxGet = new System.Windows.Forms.Button();
            this.cmbDCKeywordVoiceCommandMaxCommanfType = new System.Windows.Forms.ComboBox();
            this.btnDCDeviceNameGet = new System.Windows.Forms.Button();
            this.btnDCBarcodeScanButtonGet = new System.Windows.Forms.Button();
            this.btnDCVendorIdGet = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            this.btnDCUserStringMaxGet = new System.Windows.Forms.Button();
            this.label65 = new System.Windows.Forms.Label();
            this.btnDcSecurityGet = new System.Windows.Forms.Button();
            this.cbDCSecurity = new System.Windows.Forms.CheckBox();
            this.btnDCScanKeywordsFromBarcodeGet = new System.Windows.Forms.Button();
            this.cbDCScanKeywordsFromBarcode = new System.Windows.Forms.CheckBox();
            this.btnDCRequiredInputTypeGet = new System.Windows.Forms.Button();
            this.cbDCRequiredInputType = new System.Windows.Forms.CheckBox();
            this.btnDCQualityPlayGet = new System.Windows.Forms.Button();
            this.cbDCQualityPlay = new System.Windows.Forms.CheckBox();
            this.btnDCProhibitFileAlterationGet = new System.Windows.Forms.Button();
            this.cbDCProhibitFileAlteration = new System.Windows.Forms.CheckBox();
            this.btnDCProductIdGet = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.btnDCPriorityGet = new System.Windows.Forms.Button();
            this.cbDCPriority = new System.Windows.Forms.CheckBox();
            this.btnDCLinkKeywordsGet = new System.Windows.Forms.Button();
            this.cbDCLinkKeywords = new System.Windows.Forms.CheckBox();
            this.btnDCKeywordVoiceCommandGet = new System.Windows.Forms.Button();
            this.cbDCKeywordVoiceCommand = new System.Windows.Forms.CheckBox();
            this.btnDCKeywordUsageMaxGet = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.btnDCKeywordsReadOnlyGet = new System.Windows.Forms.Button();
            this.cbDCKeywordsReadOnly = new System.Windows.Forms.CheckBox();
            this.btnDCKeywordMandatoryGet = new System.Windows.Forms.Button();
            this.cbDCKeywordMandatory = new System.Windows.Forms.CheckBox();
            this.btnDCMaxKeywordLengthGet = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.btnDCKeywordContentMaxGet = new System.Windows.Forms.Button();
            this.label59 = new System.Windows.Forms.Label();
            this.btnDCDisplayModeCountGet = new System.Windows.Forms.Button();
            this.btnDCKeywordBarcodeScanGet = new System.Windows.Forms.Button();
            this.cbDCKeywordBarcodeScan = new System.Windows.Forms.CheckBox();
            this.btnDCInstructionGet = new System.Windows.Forms.Button();
            this.cbDCInstruction = new System.Windows.Forms.CheckBox();
            this.btnDCFunctionKey = new System.Windows.Forms.Button();
            this.cbDCFunctionKey = new System.Windows.Forms.CheckBox();
            this.btnDCFourPosSwitchGet = new System.Windows.Forms.Button();
            this.cbDCFourPosSwitch = new System.Windows.Forms.CheckBox();
            this.btnDCEncryptionGet = new System.Windows.Forms.Button();
            this.cbDCEncryption = new System.Windows.Forms.CheckBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.cbDCBarcodeScanButton = new System.Windows.Forms.CheckBox();
            this.btnDCBarcodeEventGet = new System.Windows.Forms.Button();
            this.cbDCBarcodeEvent = new System.Windows.Forms.CheckBox();
            this.deviceTabPage = new System.Windows.Forms.TabPage();
            this.btnGetDevice = new System.Windows.Forms.Button();
            this.DeviceInfoPanel = new System.Windows.Forms.Panel();
            this.label57 = new System.Windows.Forms.Label();
            this.btnDDPUKSetGet = new System.Windows.Forms.Button();
            this.cbDDPUKSet = new System.Windows.Forms.CheckBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textDDPUK = new System.Windows.Forms.TextBox();
            this.btnDDPukSet = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.textDDSetPIN_PUK = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.textDDSetPIN_p2 = new System.Windows.Forms.TextBox();
            this.textDDSetEncriptionPasswordoldKey = new System.Windows.Forms.TextBox();
            this.btnDDSetPIN = new System.Windows.Forms.Button();
            this.textDDSetEncriptionPasswordp2 = new System.Windows.Forms.TextBox();
            this.WelcomeScreenHashGetButton = new System.Windows.Forms.Button();
            this.ResetToFactoryDefaultsButton = new System.Windows.Forms.Button();
            this.btnDDSynchronizeDateTime = new System.Windows.Forms.Button();
            this.btnDDSetEncryptionPassword = new System.Windows.Forms.Button();
            this.btnDDFormatCard = new System.Windows.Forms.Button();
            this.numDDenableLedIndex = new System.Windows.Forms.NumericUpDown();
            this.cmbDDenableLed = new System.Windows.Forms.ComboBox();
            this.btnDDenableLed = new System.Windows.Forms.Button();
            this.cmbDDDisplaySymbol = new System.Windows.Forms.ComboBox();
            this.btnDDDisplaySymbol = new System.Windows.Forms.Button();
            this.btnDDDisplayScreen = new System.Windows.Forms.Button();
            this.btnDDDisplayScreenBrowse = new System.Windows.Forms.Button();
            this.textDDDisplayScreen = new System.Windows.Forms.TextBox();
            this.btnDDDeleteFile = new System.Windows.Forms.Button();
            this.btnDDDeleteFileBrowse = new System.Windows.Forms.Button();
            this.textDDDeleteFile = new System.Windows.Forms.TextBox();
            this.WelcomeScreenHashTxt = new System.Windows.Forms.TextBox();
            this.textFileCount = new System.Windows.Forms.TextBox();
            this.btnFileCount = new System.Windows.Forms.Button();
            this.textFreeDiskSpace = new System.Windows.Forms.TextBox();
            this.textMacAddress = new System.Windows.Forms.TextBox();
            this.textDriveLetter = new System.Windows.Forms.TextBox();
            this.btnGetFreeDiskSpace = new System.Windows.Forms.Button();
            this.btnGetMacAddress = new System.Windows.Forms.Button();
            this.textFirmwareVersion = new System.Windows.Forms.TextBox();
            this.btmGetFirmwareVersion = new System.Windows.Forms.Button();
            this.btnGetDriveLetter = new System.Windows.Forms.Button();
            this.textBuildNumber = new System.Windows.Forms.TextBox();
            this.textDeviceType = new System.Windows.Forms.TextBox();
            this.btnGetBuildNumber = new System.Windows.Forms.Button();
            this.btnGetDeviceType = new System.Windows.Forms.Button();
            this.initializationTabPage = new System.Windows.Forms.TabPage();
            this.btnDisplaySymbolsEnabledSet = new System.Windows.Forms.Button();
            this.btnDisplaySymbolsEnabledGet = new System.Windows.Forms.Button();
            this.cbDisplaySymbolsEnabled = new System.Windows.Forms.CheckBox();
            this.btnDSSPro256EnabledSet = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbSeparateSpokenInstructionsbCreateInstruction = new System.Windows.Forms.CheckBox();
            this.cbSeparateSpokenInstructionsbCreateDictation = new System.Windows.Forms.CheckBox();
            this.btnSeparateSpokenInstructions = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label79 = new System.Windows.Forms.Label();
            this.textDecryptbstrPassword = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.cmbDecryptAudioFormat = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDCEditCustomAudioFormat = new System.Windows.Forms.Button();
            this.label78 = new System.Windows.Forms.Label();
            this.btnConvert = new System.Windows.Forms.Button();
            this.cmbConvertAudioFormat = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.btnStartDelayedTasks = new System.Windows.Forms.Button();
            this.textbstrFileName = new System.Windows.Forms.TextBox();
            this.btnbstrFileNameBrowse = new System.Windows.Forms.Button();
            this.label75 = new System.Windows.Forms.Label();
            this.textbstrDestPath = new System.Windows.Forms.TextBox();
            this.btnbstrDestPathBrowse = new System.Windows.Forms.Button();
            this.btnMove = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.cbDelayTasks = new System.Windows.Forms.CheckBox();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnDSSPro256EnabledGet = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnbstrFileNameBrowseNewFile = new System.Windows.Forms.Button();
            this.textbstrFileNameNewFile = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.textNewFilePassword = new System.Windows.Forms.TextBox();
            this.cmbNewFileCompressionMode = new System.Windows.Forms.ComboBox();
            this.btnNewFile = new System.Windows.Forms.Button();
            this.cbDSSPro256Enabled = new System.Windows.Forms.CheckBox();
            this.textDeviceStatus = new System.Windows.Forms.TextBox();
            this.btnDeviceStatus = new System.Windows.Forms.Button();
            this.textBarcodeModuleStatus = new System.Windows.Forms.TextBox();
            this.btnBarcodeModuleStatusGet = new System.Windows.Forms.Button();
            this.InitializationGroupBox = new System.Windows.Forms.GroupBox();
            this.btnDeinitialize = new System.Windows.Forms.Button();
            this.btnInitialize = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this._tbBarcodeConfiguration = new System.Windows.Forms.TabPage();
            this.btnGetDeviceBarcode = new System.Windows.Forms.Button();
            this.barcodeSettingsPanel = new System.Windows.Forms.Panel();
            this._dgBarcodePostfix = new System.Windows.Forms.DataGridView();
            this._dgBarcodePrefix = new System.Windows.Forms.DataGridView();
            this._lblKeyboardLayout = new System.Windows.Forms.Label();
            this._txtInfo = new System.Windows.Forms.Label();
            this._btnSetBarcodeConfiguration = new System.Windows.Forms.Button();
            this._btnGetBarcodeConfiguration = new System.Windows.Forms.Button();
            this._lblBarcodePostfix = new System.Windows.Forms.Label();
            this._lblPrefixCaption = new System.Windows.Forms.Label();
            this._lblKeyboardLayoutCaption = new System.Windows.Forms.Label();
            this._txtLayoutID = new System.Windows.Forms.TextBox();
            this._cbKeyboardLayout = new System.Windows.Forms.ComboBox();
            this.dpmFilesTabPage = new System.Windows.Forms.TabPage();
            this.btnGetIFileList = new System.Windows.Forms.Button();
            this.fileListPanel = new System.Windows.Forms.Panel();
            this.btnFLIDPMDeviceDriveLetterSet = new System.Windows.Forms.Button();
            this.btnFLSelectFile = new System.Windows.Forms.Button();
            this.btnFLFilesGet = new System.Windows.Forms.Button();
            this.cmbFLFileList = new System.Windows.Forms.ComboBox();
            this.btnDSCountGet = new System.Windows.Forms.Button();
            this.textFLCount = new System.Windows.Forms.TextBox();
            this.btnFLPathBrowse = new System.Windows.Forms.Button();
            this.btnFLPathSet = new System.Windows.Forms.Button();
            this.btnFLPathGet = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.textFLPath = new System.Windows.Forms.TextBox();
            this.dpmFileInfoPage = new System.Windows.Forms.TabPage();
            this.btnFIBrowse = new System.Windows.Forms.Button();
            this.btnFISetFile = new System.Windows.Forms.Button();
            this.label66 = new System.Windows.Forms.Label();
            this.textFISourceFileNameAndPath = new System.Windows.Forms.TextBox();
            this.fileInfoPanel = new System.Windows.Forms.Panel();
            this.btnFISpokenInstructionList = new System.Windows.Forms.Button();
            this.btnFIUserStringCount = new System.Windows.Forms.Button();
            this.textFIUserStringCount = new System.Windows.Forms.TextBox();
            this.btnFIRecordingStartTime = new System.Windows.Forms.Button();
            this.textFIRecordingStartTime = new System.Windows.Forms.TextBox();
            this.btnFIRecordingStartDate = new System.Windows.Forms.Button();
            this.textFIRecordingStartDate = new System.Windows.Forms.TextBox();
            this.btnFIRecordingEndTime = new System.Windows.Forms.Button();
            this.textFIRecordingEndTime = new System.Windows.Forms.TextBox();
            this.btnFIRecordingEndDate = new System.Windows.Forms.Button();
            this.textFIRecordingEndDate = new System.Windows.Forms.TextBox();
            this.btnFIProductId = new System.Windows.Forms.Button();
            this.textFIProductId = new System.Windows.Forms.TextBox();
            this.numFIPriority = new System.Windows.Forms.NumericUpDown();
            this.btnFIPrioritySet = new System.Windows.Forms.Button();
            this.btnFIPriorityGet = new System.Windows.Forms.Button();
            this.btnFIMACAddress = new System.Windows.Forms.Button();
            this.textFIMACAddress = new System.Windows.Forms.TextBox();
            this.btnFILastModifiedTime = new System.Windows.Forms.Button();
            this.textFILastModifiedTime = new System.Windows.Forms.TextBox();
            this.btnFILastModifiedDate = new System.Windows.Forms.Button();
            this.textFILastModifiedDate = new System.Windows.Forms.TextBox();
            this.btnFIKeywordUsageCount = new System.Windows.Forms.Button();
            this.textFIKeywordUsageCount = new System.Windows.Forms.TextBox();
            this.btnFIKeywordContentCount = new System.Windows.Forms.Button();
            this.textFIKeywordContentCount = new System.Windows.Forms.TextBox();
            this.btnFIJobNumber = new System.Windows.Forms.Button();
            this.textFIJobNumber = new System.Windows.Forms.TextBox();
            this.btnFIIsEncrypted = new System.Windows.Forms.Button();
            this.cbFIIsEncrypted = new System.Windows.Forms.CheckBox();
            this.btnFIInstructionLength = new System.Windows.Forms.Button();
            this.textFIInstructionLength = new System.Windows.Forms.TextBox();
            this.btnFIInstructionFileName = new System.Windows.Forms.Button();
            this.textFIInstructionFileName = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.numFIUserStringIndex = new System.Windows.Forms.NumericUpDown();
            this.numFIKeywordUsageStringIndex = new System.Windows.Forms.NumericUpDown();
            this.numFIKeywordContentStringIndex = new System.Windows.Forms.NumericUpDown();
            this.btnFIUserStringSet = new System.Windows.Forms.Button();
            this.btnFIUserStringGet = new System.Windows.Forms.Button();
            this.textFIUserString = new System.Windows.Forms.TextBox();
            this.btnFIKeywordUsageStringSet = new System.Windows.Forms.Button();
            this.btnFIKeywordUsageStringGet = new System.Windows.Forms.Button();
            this.textFIKeywordUsageString = new System.Windows.Forms.TextBox();
            this.btnFIKeywordContentStringSet = new System.Windows.Forms.Button();
            this.btnFIKeywordContentStringGet = new System.Windows.Forms.Button();
            this.textFIKeywordContentString = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.btnFIInstructionFileExists = new System.Windows.Forms.Button();
            this.cbFIInstructionFileExists = new System.Windows.Forms.CheckBox();
            this.btnFIFirmwareVersion = new System.Windows.Forms.Button();
            this.textFIFirmwareVersion = new System.Windows.Forms.TextBox();
            this.btnFIFileType = new System.Windows.Forms.Button();
            this.textFIFileType = new System.Windows.Forms.TextBox();
            this.btnFIFileName = new System.Windows.Forms.Button();
            this.textFIFileName = new System.Windows.Forms.TextBox();
            this.btnFIEOLSet = new System.Windows.Forms.Button();
            this.btnFIEOL = new System.Windows.Forms.Button();
            this.cbFIEOL = new System.Windows.Forms.CheckBox();
            this.btnFIDownloadTimeSet = new System.Windows.Forms.Button();
            this.btnFIDownloadTime = new System.Windows.Forms.Button();
            this.textFIDownloadTime = new System.Windows.Forms.TextBox();
            this.btnFIDownloadDateSet = new System.Windows.Forms.Button();
            this.btnFIDownloadDate = new System.Windows.Forms.Button();
            this.textFIDownloadDate = new System.Windows.Forms.TextBox();
            this.btnFIDictationLength = new System.Windows.Forms.Button();
            this.textFIDictationLength = new System.Windows.Forms.TextBox();
            this.btnFICompressionMode = new System.Windows.Forms.Button();
            this.textFICompressionMode = new System.Windows.Forms.TextBox();
            this.btnFIAuthorSet = new System.Windows.Forms.Button();
            this.btnFIBarcodeString = new System.Windows.Forms.Button();
            this.textFIBarcodeString = new System.Windows.Forms.TextBox();
            this.btnFIAuthor = new System.Windows.Forms.Button();
            this.textFIAuthor = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textLog = new System.Windows.Forms.RichTextBox();
            this.deviceSettingsTabPage.SuspendLayout();
            this.deviceSettingsTabControl.SuspendLayout();
            this.deviceSettings1TabPage.SuspendLayout();
            this.deviceSettings2TabPage.SuspendLayout();
            this.deviceSettings3TabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSliderJumpBackTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserStringCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLockTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordUsageCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordContentCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDownloadFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDownloadMode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFileCounter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDisplayKeywords)).BeginInit();
            this.deviceSettings4TabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordContentStringUsageIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVoiceCommandTypeIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordUsageStringIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordContentStringContentIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordVoiceCommandIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordMandatoryIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordBarcodeScanIndex)).BeginInit();
            this.deviceSettings5TabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KeywordDisplayAreaStringsIndexNum)).BeginInit();
            this.deviceSettings6TabPage.SuspendLayout();
            this.RecordingProfileGroup.SuspendLayout();
            this.capabilitiesTabPage.SuspendLayout();
            this.deviceCapabilitesPanel.SuspendLayout();
            this.deviceTabPage.SuspendLayout();
            this.DeviceInfoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDDenableLedIndex)).BeginInit();
            this.initializationTabPage.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.InitializationGroupBox.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this._tbBarcodeConfiguration.SuspendLayout();
            this.barcodeSettingsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dgBarcodePostfix)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._dgBarcodePrefix)).BeginInit();
            this.dpmFilesTabPage.SuspendLayout();
            this.fileListPanel.SuspendLayout();
            this.dpmFileInfoPage.SuspendLayout();
            this.fileInfoPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numFIPriority)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFIUserStringIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFIKeywordUsageStringIndex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFIKeywordContentStringIndex)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClearLog
            // 
            this.btnClearLog.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnClearLog.Location = new System.Drawing.Point(299, 636);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(163, 23);
            this.btnClearLog.TabIndex = 2;
            this.btnClearLog.Text = "ClearLog";
            this.btnClearLog.UseVisualStyleBackColor = true;
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);
            // 
            // deviceSettingsTabPage
            // 
            this.deviceSettingsTabPage.Controls.Add(this.label81);
            this.deviceSettingsTabPage.Controls.Add(this.label80);
            this.deviceSettingsTabPage.Controls.Add(this.btnPutSettingsToDevice);
            this.deviceSettingsTabPage.Controls.Add(this.btnConfigFileBrowse);
            this.deviceSettingsTabPage.Controls.Add(this.textConfigFilePath);
            this.deviceSettingsTabPage.Controls.Add(this.btnGetSettingsFromDevice);
            this.deviceSettingsTabPage.Controls.Add(this.btnExportConfig);
            this.deviceSettingsTabPage.Controls.Add(this.deviceSettingsTabControl);
            this.deviceSettingsTabPage.Controls.Add(this.btnImportConfig);
            this.deviceSettingsTabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettingsTabPage.Name = "deviceSettingsTabPage";
            this.deviceSettingsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.deviceSettingsTabPage.Size = new System.Drawing.Size(722, 510);
            this.deviceSettingsTabPage.TabIndex = 7;
            this.deviceSettingsTabPage.Text = "IDPMDeviceSettings";
            this.deviceSettingsTabPage.UseVisualStyleBackColor = true;
            // 
            // label81
            // 
            this.label81.Location = new System.Drawing.Point(107, 381);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(600, 37);
            this.label81.TabIndex = 6;
            this.label81.Text = "The IDPMDeviceSettings is retrieved from the IDPMDevice instance. If their instan" +
    "ces do not represent the currently connected device or no device is connected th" +
    "en errors are expected.";
            // 
            // label80
            // 
            this.label80.Location = new System.Drawing.Point(107, 14);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(600, 37);
            this.label80.TabIndex = 6;
            this.label80.Text = "The IDPMDeviceSettings is retrieved from the IDPMDevice instance. If their instan" +
    "ces do not represent the currently connected device or no device is connected th" +
    "en errors are expected.";
            // 
            // btnPutSettingsToDevice
            // 
            this.btnPutSettingsToDevice.Enabled = false;
            this.btnPutSettingsToDevice.Location = new System.Drawing.Point(10, 381);
            this.btnPutSettingsToDevice.Name = "btnPutSettingsToDevice";
            this.btnPutSettingsToDevice.Size = new System.Drawing.Size(91, 23);
            this.btnPutSettingsToDevice.TabIndex = 5;
            this.btnPutSettingsToDevice.Text = "Put to device";
            this.btnPutSettingsToDevice.UseVisualStyleBackColor = true;
            this.btnPutSettingsToDevice.Visible = false;
            this.btnPutSettingsToDevice.Click += new System.EventHandler(this.btnPutSettingsToDevice_Click);
            // 
            // btnConfigFileBrowse
            // 
            this.btnConfigFileBrowse.Location = new System.Drawing.Point(423, 421);
            this.btnConfigFileBrowse.Name = "btnConfigFileBrowse";
            this.btnConfigFileBrowse.Size = new System.Drawing.Size(91, 23);
            this.btnConfigFileBrowse.TabIndex = 3;
            this.btnConfigFileBrowse.Text = "Browse";
            this.btnConfigFileBrowse.UseVisualStyleBackColor = true;
            this.btnConfigFileBrowse.Click += new System.EventHandler(this.btnConfigFileBrowse_Click);
            // 
            // textConfigFilePath
            // 
            this.textConfigFilePath.Location = new System.Drawing.Point(10, 422);
            this.textConfigFilePath.Name = "textConfigFilePath";
            this.textConfigFilePath.Size = new System.Drawing.Size(407, 20);
            this.textConfigFilePath.TabIndex = 2;
            // 
            // btnGetSettingsFromDevice
            // 
            this.btnGetSettingsFromDevice.Enabled = false;
            this.btnGetSettingsFromDevice.Location = new System.Drawing.Point(10, 14);
            this.btnGetSettingsFromDevice.Name = "btnGetSettingsFromDevice";
            this.btnGetSettingsFromDevice.Size = new System.Drawing.Size(91, 23);
            this.btnGetSettingsFromDevice.TabIndex = 4;
            this.btnGetSettingsFromDevice.Text = "GetFromDevice";
            this.btnGetSettingsFromDevice.UseVisualStyleBackColor = true;
            this.btnGetSettingsFromDevice.Click += new System.EventHandler(this.btnGetSettingsFromDevice_Click);
            // 
            // btnExportConfig
            // 
            this.btnExportConfig.Location = new System.Drawing.Point(617, 421);
            this.btnExportConfig.Name = "btnExportConfig";
            this.btnExportConfig.Size = new System.Drawing.Size(91, 23);
            this.btnExportConfig.TabIndex = 1;
            this.btnExportConfig.Text = "Export Config";
            this.btnExportConfig.UseVisualStyleBackColor = true;
            this.btnExportConfig.Click += new System.EventHandler(this.btnExportConfig_Click);
            // 
            // deviceSettingsTabControl
            // 
            this.deviceSettingsTabControl.Controls.Add(this.deviceSettings1TabPage);
            this.deviceSettingsTabControl.Controls.Add(this.deviceSettings2TabPage);
            this.deviceSettingsTabControl.Controls.Add(this.deviceSettings3TabPage);
            this.deviceSettingsTabControl.Controls.Add(this.deviceSettings4TabPage);
            this.deviceSettingsTabControl.Controls.Add(this.deviceSettings5TabPage);
            this.deviceSettingsTabControl.Controls.Add(this.deviceSettings6TabPage);
            this.deviceSettingsTabControl.Location = new System.Drawing.Point(6, 54);
            this.deviceSettingsTabControl.Name = "deviceSettingsTabControl";
            this.deviceSettingsTabControl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.deviceSettingsTabControl.SelectedIndex = 0;
            this.deviceSettingsTabControl.Size = new System.Drawing.Size(712, 310);
            this.deviceSettingsTabControl.TabIndex = 0;
            this.deviceSettingsTabControl.Visible = false;
            // 
            // deviceSettings1TabPage
            // 
            this.deviceSettings1TabPage.Controls.Add(this.label12);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSTotalTimeTypeSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSTotalTimeTypeGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSRequiredInputTypeSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSRequiredInputTypeGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSRecordingModeSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSRecordingModeGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSOsSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSOsGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSMicrophoneSensitivitySet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSMicrophoneSensitivityGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSLowerAreaSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSLowerAreaGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFunctionKeySet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFunctionKeyGet);
            this.deviceSettings1TabPage.Controls.Add(this.cmbTotalTimeType);
            this.deviceSettings1TabPage.Controls.Add(this.label13);
            this.deviceSettings1TabPage.Controls.Add(this.cmbRequiredInputType);
            this.deviceSettings1TabPage.Controls.Add(this.cmbRecordingMode);
            this.deviceSettings1TabPage.Controls.Add(this.label11);
            this.deviceSettings1TabPage.Controls.Add(this.cmbOS);
            this.deviceSettings1TabPage.Controls.Add(this.label10);
            this.deviceSettings1TabPage.Controls.Add(this.cmbMicrophoneSensitivity);
            this.deviceSettings1TabPage.Controls.Add(this.label9);
            this.deviceSettings1TabPage.Controls.Add(this.cmbLowerArea);
            this.deviceSettings1TabPage.Controls.Add(this.label8);
            this.deviceSettings1TabPage.Controls.Add(this.cmbFunctionKey);
            this.deviceSettings1TabPage.Controls.Add(this.label7);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFourPosSwitchSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFourPosSwitchGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFileNamePrefixSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFileNamePrefixGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFileCounterSourceSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSFileCounterSourceGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSDateTimeFormatSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSDateTimeFormatGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSBarCodeScanButtonSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSBarCodeScanButtonGet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSBarcodeModeSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSBarcodeModeGet);
            this.deviceSettings1TabPage.Controls.Add(this.cmbFourPosSwitch);
            this.deviceSettings1TabPage.Controls.Add(this.label6);
            this.deviceSettings1TabPage.Controls.Add(this.cmbFileNamePrefixType);
            this.deviceSettings1TabPage.Controls.Add(this.label5);
            this.deviceSettings1TabPage.Controls.Add(this.cmbFileCounterSource);
            this.deviceSettings1TabPage.Controls.Add(this.label4);
            this.deviceSettings1TabPage.Controls.Add(this.cmbDateTimeFormat);
            this.deviceSettings1TabPage.Controls.Add(this.label3);
            this.deviceSettings1TabPage.Controls.Add(this.cmbBarcodeScanButton);
            this.deviceSettings1TabPage.Controls.Add(this.label2);
            this.deviceSettings1TabPage.Controls.Add(this.cmbBarcodeMode);
            this.deviceSettings1TabPage.Controls.Add(this.label1);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSAppearanceSet);
            this.deviceSettings1TabPage.Controls.Add(this.btnDSAppearanceGet);
            this.deviceSettings1TabPage.Controls.Add(this.AppearanceLabel);
            this.deviceSettings1TabPage.Controls.Add(this.cmbAppearance);
            this.deviceSettings1TabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettings1TabPage.Name = "deviceSettings1TabPage";
            this.deviceSettings1TabPage.Padding = new System.Windows.Forms.Padding(3);
            this.deviceSettings1TabPage.Size = new System.Drawing.Size(704, 284);
            this.deviceSettings1TabPage.TabIndex = 0;
            this.deviceSettings1TabPage.Text = "Settings 1";
            this.deviceSettings1TabPage.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(377, 161);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 13);
            this.label12.TabIndex = 127;
            this.label12.Text = "RequiredInputType";
            // 
            // btnDSTotalTimeTypeSet
            // 
            this.btnDSTotalTimeTypeSet.Enabled = false;
            this.btnDSTotalTimeTypeSet.Location = new System.Drawing.Point(667, 186);
            this.btnDSTotalTimeTypeSet.Name = "btnDSTotalTimeTypeSet";
            this.btnDSTotalTimeTypeSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSTotalTimeTypeSet.TabIndex = 126;
            this.btnDSTotalTimeTypeSet.Text = "set";
            this.btnDSTotalTimeTypeSet.UseVisualStyleBackColor = true;
            this.btnDSTotalTimeTypeSet.Click += new System.EventHandler(this.btnDSTotalTimeTypeSet_Click);
            // 
            // btnDSTotalTimeTypeGet
            // 
            this.btnDSTotalTimeTypeGet.Location = new System.Drawing.Point(634, 186);
            this.btnDSTotalTimeTypeGet.Name = "btnDSTotalTimeTypeGet";
            this.btnDSTotalTimeTypeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSTotalTimeTypeGet.TabIndex = 125;
            this.btnDSTotalTimeTypeGet.Text = "get";
            this.btnDSTotalTimeTypeGet.UseVisualStyleBackColor = true;
            this.btnDSTotalTimeTypeGet.Click += new System.EventHandler(this.btnDSTotalTimeTypeGet_Click);
            // 
            // btnDSRequiredInputTypeSet
            // 
            this.btnDSRequiredInputTypeSet.Enabled = false;
            this.btnDSRequiredInputTypeSet.Location = new System.Drawing.Point(667, 157);
            this.btnDSRequiredInputTypeSet.Name = "btnDSRequiredInputTypeSet";
            this.btnDSRequiredInputTypeSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSRequiredInputTypeSet.TabIndex = 124;
            this.btnDSRequiredInputTypeSet.Text = "set";
            this.btnDSRequiredInputTypeSet.UseVisualStyleBackColor = true;
            this.btnDSRequiredInputTypeSet.Click += new System.EventHandler(this.btnDSRequiredInputTypeSet_Click);
            // 
            // btnDSRequiredInputTypeGet
            // 
            this.btnDSRequiredInputTypeGet.Location = new System.Drawing.Point(634, 157);
            this.btnDSRequiredInputTypeGet.Name = "btnDSRequiredInputTypeGet";
            this.btnDSRequiredInputTypeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSRequiredInputTypeGet.TabIndex = 123;
            this.btnDSRequiredInputTypeGet.Text = "get";
            this.btnDSRequiredInputTypeGet.UseVisualStyleBackColor = true;
            this.btnDSRequiredInputTypeGet.Click += new System.EventHandler(this.btnDSRequiredInputTypeGet_Click);
            // 
            // btnDSRecordingModeSet
            // 
            this.btnDSRecordingModeSet.Enabled = false;
            this.btnDSRecordingModeSet.Location = new System.Drawing.Point(667, 128);
            this.btnDSRecordingModeSet.Name = "btnDSRecordingModeSet";
            this.btnDSRecordingModeSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSRecordingModeSet.TabIndex = 122;
            this.btnDSRecordingModeSet.Text = "set";
            this.btnDSRecordingModeSet.UseVisualStyleBackColor = true;
            this.btnDSRecordingModeSet.Click += new System.EventHandler(this.btnDSRecordingModeSet_Click);
            // 
            // btnDSRecordingModeGet
            // 
            this.btnDSRecordingModeGet.Location = new System.Drawing.Point(634, 128);
            this.btnDSRecordingModeGet.Name = "btnDSRecordingModeGet";
            this.btnDSRecordingModeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSRecordingModeGet.TabIndex = 121;
            this.btnDSRecordingModeGet.Text = "get";
            this.btnDSRecordingModeGet.UseVisualStyleBackColor = true;
            this.btnDSRecordingModeGet.Click += new System.EventHandler(this.btnDSRecordingModeGet_Click);
            // 
            // btnDSOsSet
            // 
            this.btnDSOsSet.Enabled = false;
            this.btnDSOsSet.Location = new System.Drawing.Point(667, 99);
            this.btnDSOsSet.Name = "btnDSOsSet";
            this.btnDSOsSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSOsSet.TabIndex = 120;
            this.btnDSOsSet.Text = "set";
            this.btnDSOsSet.UseVisualStyleBackColor = true;
            this.btnDSOsSet.Click += new System.EventHandler(this.btnDSOsSet_Click);
            // 
            // btnDSOsGet
            // 
            this.btnDSOsGet.Location = new System.Drawing.Point(634, 99);
            this.btnDSOsGet.Name = "btnDSOsGet";
            this.btnDSOsGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSOsGet.TabIndex = 119;
            this.btnDSOsGet.Text = "get";
            this.btnDSOsGet.UseVisualStyleBackColor = true;
            this.btnDSOsGet.Click += new System.EventHandler(this.btnDSOsGet_Click);
            // 
            // btnDSMicrophoneSensitivitySet
            // 
            this.btnDSMicrophoneSensitivitySet.Enabled = false;
            this.btnDSMicrophoneSensitivitySet.Location = new System.Drawing.Point(667, 70);
            this.btnDSMicrophoneSensitivitySet.Name = "btnDSMicrophoneSensitivitySet";
            this.btnDSMicrophoneSensitivitySet.Size = new System.Drawing.Size(35, 21);
            this.btnDSMicrophoneSensitivitySet.TabIndex = 118;
            this.btnDSMicrophoneSensitivitySet.Text = "set";
            this.btnDSMicrophoneSensitivitySet.UseVisualStyleBackColor = true;
            this.btnDSMicrophoneSensitivitySet.Click += new System.EventHandler(this.btnDSMicrophoneSensitivitySet_Click);
            // 
            // btnDSMicrophoneSensitivityGet
            // 
            this.btnDSMicrophoneSensitivityGet.Location = new System.Drawing.Point(634, 70);
            this.btnDSMicrophoneSensitivityGet.Name = "btnDSMicrophoneSensitivityGet";
            this.btnDSMicrophoneSensitivityGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSMicrophoneSensitivityGet.TabIndex = 117;
            this.btnDSMicrophoneSensitivityGet.Text = "get";
            this.btnDSMicrophoneSensitivityGet.UseVisualStyleBackColor = true;
            this.btnDSMicrophoneSensitivityGet.Click += new System.EventHandler(this.btnDSMicrophoneSensitivityGet_Click);
            // 
            // btnDSLowerAreaSet
            // 
            this.btnDSLowerAreaSet.Enabled = false;
            this.btnDSLowerAreaSet.Location = new System.Drawing.Point(667, 41);
            this.btnDSLowerAreaSet.Name = "btnDSLowerAreaSet";
            this.btnDSLowerAreaSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSLowerAreaSet.TabIndex = 116;
            this.btnDSLowerAreaSet.Text = "set";
            this.btnDSLowerAreaSet.UseVisualStyleBackColor = true;
            this.btnDSLowerAreaSet.Click += new System.EventHandler(this.btnDSLowerAreaSet_Click);
            // 
            // btnDSLowerAreaGet
            // 
            this.btnDSLowerAreaGet.Location = new System.Drawing.Point(634, 41);
            this.btnDSLowerAreaGet.Name = "btnDSLowerAreaGet";
            this.btnDSLowerAreaGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSLowerAreaGet.TabIndex = 115;
            this.btnDSLowerAreaGet.Text = "get";
            this.btnDSLowerAreaGet.UseVisualStyleBackColor = true;
            this.btnDSLowerAreaGet.Click += new System.EventHandler(this.btnDSLowerAreaGet_Click);
            // 
            // btnDSFunctionKeySet
            // 
            this.btnDSFunctionKeySet.Enabled = false;
            this.btnDSFunctionKeySet.Location = new System.Drawing.Point(667, 12);
            this.btnDSFunctionKeySet.Name = "btnDSFunctionKeySet";
            this.btnDSFunctionKeySet.Size = new System.Drawing.Size(35, 21);
            this.btnDSFunctionKeySet.TabIndex = 114;
            this.btnDSFunctionKeySet.Text = "set";
            this.btnDSFunctionKeySet.UseVisualStyleBackColor = true;
            this.btnDSFunctionKeySet.Click += new System.EventHandler(this.btnDSFunctionKeySet_Click);
            // 
            // btnDSFunctionKeyGet
            // 
            this.btnDSFunctionKeyGet.Location = new System.Drawing.Point(634, 12);
            this.btnDSFunctionKeyGet.Name = "btnDSFunctionKeyGet";
            this.btnDSFunctionKeyGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFunctionKeyGet.TabIndex = 113;
            this.btnDSFunctionKeyGet.Text = "get";
            this.btnDSFunctionKeyGet.UseVisualStyleBackColor = true;
            this.btnDSFunctionKeyGet.Click += new System.EventHandler(this.btnDSFunctionKeyGet_Click);
            // 
            // cmbTotalTimeType
            // 
            this.cmbTotalTimeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTotalTimeType.FormattingEnabled = true;
            this.cmbTotalTimeType.Location = new System.Drawing.Point(479, 186);
            this.cmbTotalTimeType.Name = "cmbTotalTimeType";
            this.cmbTotalTimeType.Size = new System.Drawing.Size(151, 21);
            this.cmbTotalTimeType.TabIndex = 112;
            this.cmbTotalTimeType.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(397, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(78, 13);
            this.label13.TabIndex = 111;
            this.label13.Text = "TotalTimeType";
            // 
            // cmbRequiredInputType
            // 
            this.cmbRequiredInputType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRequiredInputType.FormattingEnabled = true;
            this.cmbRequiredInputType.Location = new System.Drawing.Point(479, 157);
            this.cmbRequiredInputType.Name = "cmbRequiredInputType";
            this.cmbRequiredInputType.Size = new System.Drawing.Size(151, 21);
            this.cmbRequiredInputType.TabIndex = 110;
            this.cmbRequiredInputType.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cmbRecordingMode
            // 
            this.cmbRecordingMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRecordingMode.DropDownWidth = 200;
            this.cmbRecordingMode.FormattingEnabled = true;
            this.cmbRecordingMode.Location = new System.Drawing.Point(479, 128);
            this.cmbRecordingMode.Name = "cmbRecordingMode";
            this.cmbRecordingMode.Size = new System.Drawing.Size(151, 21);
            this.cmbRecordingMode.TabIndex = 109;
            this.cmbRecordingMode.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(392, 132);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 13);
            this.label11.TabIndex = 108;
            this.label11.Text = "RecordingMode";
            // 
            // cmbOS
            // 
            this.cmbOS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOS.FormattingEnabled = true;
            this.cmbOS.Location = new System.Drawing.Point(479, 99);
            this.cmbOS.Name = "cmbOS";
            this.cmbOS.Size = new System.Drawing.Size(151, 21);
            this.cmbOS.TabIndex = 107;
            this.cmbOS.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(453, 103);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 13);
            this.label10.TabIndex = 106;
            this.label10.Text = "OS";
            // 
            // cmbMicrophoneSensitivity
            // 
            this.cmbMicrophoneSensitivity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMicrophoneSensitivity.FormattingEnabled = true;
            this.cmbMicrophoneSensitivity.Location = new System.Drawing.Point(479, 70);
            this.cmbMicrophoneSensitivity.Name = "cmbMicrophoneSensitivity";
            this.cmbMicrophoneSensitivity.Size = new System.Drawing.Size(151, 21);
            this.cmbMicrophoneSensitivity.TabIndex = 105;
            this.cmbMicrophoneSensitivity.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(365, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 13);
            this.label9.TabIndex = 104;
            this.label9.Text = "MicrophoneSensitivity";
            // 
            // cmbLowerArea
            // 
            this.cmbLowerArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLowerArea.FormattingEnabled = true;
            this.cmbLowerArea.Location = new System.Drawing.Point(479, 41);
            this.cmbLowerArea.Name = "cmbLowerArea";
            this.cmbLowerArea.Size = new System.Drawing.Size(151, 21);
            this.cmbLowerArea.TabIndex = 103;
            this.cmbLowerArea.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(417, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 102;
            this.label8.Text = "LowerArea";
            // 
            // cmbFunctionKey
            // 
            this.cmbFunctionKey.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFunctionKey.FormattingEnabled = true;
            this.cmbFunctionKey.Location = new System.Drawing.Point(479, 12);
            this.cmbFunctionKey.Name = "cmbFunctionKey";
            this.cmbFunctionKey.Size = new System.Drawing.Size(151, 21);
            this.cmbFunctionKey.TabIndex = 101;
            this.cmbFunctionKey.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(409, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 100;
            this.label7.Text = "FunctionKey";
            // 
            // btnDSFourPosSwitchSet
            // 
            this.btnDSFourPosSwitchSet.Enabled = false;
            this.btnDSFourPosSwitchSet.Location = new System.Drawing.Point(296, 186);
            this.btnDSFourPosSwitchSet.Name = "btnDSFourPosSwitchSet";
            this.btnDSFourPosSwitchSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSFourPosSwitchSet.TabIndex = 99;
            this.btnDSFourPosSwitchSet.Text = "set";
            this.btnDSFourPosSwitchSet.UseVisualStyleBackColor = true;
            this.btnDSFourPosSwitchSet.Click += new System.EventHandler(this.btnDSFourPosSwitchSet_Click);
            // 
            // btnDSFourPosSwitchGet
            // 
            this.btnDSFourPosSwitchGet.Location = new System.Drawing.Point(259, 186);
            this.btnDSFourPosSwitchGet.Name = "btnDSFourPosSwitchGet";
            this.btnDSFourPosSwitchGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFourPosSwitchGet.TabIndex = 98;
            this.btnDSFourPosSwitchGet.Text = "get";
            this.btnDSFourPosSwitchGet.UseVisualStyleBackColor = true;
            this.btnDSFourPosSwitchGet.Click += new System.EventHandler(this.btnDSFourPosSwitchGet_Click);
            // 
            // btnDSFileNamePrefixSet
            // 
            this.btnDSFileNamePrefixSet.Enabled = false;
            this.btnDSFileNamePrefixSet.Location = new System.Drawing.Point(296, 157);
            this.btnDSFileNamePrefixSet.Name = "btnDSFileNamePrefixSet";
            this.btnDSFileNamePrefixSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSFileNamePrefixSet.TabIndex = 97;
            this.btnDSFileNamePrefixSet.Text = "set";
            this.btnDSFileNamePrefixSet.UseVisualStyleBackColor = true;
            this.btnDSFileNamePrefixSet.Click += new System.EventHandler(this.btnDSFileNamePrefixSet_Click);
            // 
            // btnDSFileNamePrefixGet
            // 
            this.btnDSFileNamePrefixGet.Location = new System.Drawing.Point(259, 157);
            this.btnDSFileNamePrefixGet.Name = "btnDSFileNamePrefixGet";
            this.btnDSFileNamePrefixGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFileNamePrefixGet.TabIndex = 96;
            this.btnDSFileNamePrefixGet.Text = "get";
            this.btnDSFileNamePrefixGet.UseVisualStyleBackColor = true;
            this.btnDSFileNamePrefixGet.Click += new System.EventHandler(this.btnDSFileNamePrefixGet_Click);
            // 
            // btnDSFileCounterSourceSet
            // 
            this.btnDSFileCounterSourceSet.Enabled = false;
            this.btnDSFileCounterSourceSet.Location = new System.Drawing.Point(296, 128);
            this.btnDSFileCounterSourceSet.Name = "btnDSFileCounterSourceSet";
            this.btnDSFileCounterSourceSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSFileCounterSourceSet.TabIndex = 95;
            this.btnDSFileCounterSourceSet.Text = "set";
            this.btnDSFileCounterSourceSet.UseVisualStyleBackColor = true;
            this.btnDSFileCounterSourceSet.Click += new System.EventHandler(this.btnDSFileCounterSourceSet_Click);
            // 
            // btnDSFileCounterSourceGet
            // 
            this.btnDSFileCounterSourceGet.Location = new System.Drawing.Point(259, 128);
            this.btnDSFileCounterSourceGet.Name = "btnDSFileCounterSourceGet";
            this.btnDSFileCounterSourceGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFileCounterSourceGet.TabIndex = 94;
            this.btnDSFileCounterSourceGet.Text = "get";
            this.btnDSFileCounterSourceGet.UseVisualStyleBackColor = true;
            this.btnDSFileCounterSourceGet.Click += new System.EventHandler(this.btnDSFileCounterSourceGet_Click);
            // 
            // btnDSDateTimeFormatSet
            // 
            this.btnDSDateTimeFormatSet.Enabled = false;
            this.btnDSDateTimeFormatSet.Location = new System.Drawing.Point(296, 99);
            this.btnDSDateTimeFormatSet.Name = "btnDSDateTimeFormatSet";
            this.btnDSDateTimeFormatSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSDateTimeFormatSet.TabIndex = 93;
            this.btnDSDateTimeFormatSet.Text = "set";
            this.btnDSDateTimeFormatSet.UseVisualStyleBackColor = true;
            this.btnDSDateTimeFormatSet.Click += new System.EventHandler(this.btnDSDateTimeFormatSet_Click);
            // 
            // btnDSDateTimeFormatGet
            // 
            this.btnDSDateTimeFormatGet.Location = new System.Drawing.Point(259, 99);
            this.btnDSDateTimeFormatGet.Name = "btnDSDateTimeFormatGet";
            this.btnDSDateTimeFormatGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDateTimeFormatGet.TabIndex = 92;
            this.btnDSDateTimeFormatGet.Text = "get";
            this.btnDSDateTimeFormatGet.UseVisualStyleBackColor = true;
            this.btnDSDateTimeFormatGet.Click += new System.EventHandler(this.btnDSDateTimeFormatGet_Click);
            // 
            // btnDSBarCodeScanButtonSet
            // 
            this.btnDSBarCodeScanButtonSet.Enabled = false;
            this.btnDSBarCodeScanButtonSet.Location = new System.Drawing.Point(296, 70);
            this.btnDSBarCodeScanButtonSet.Name = "btnDSBarCodeScanButtonSet";
            this.btnDSBarCodeScanButtonSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSBarCodeScanButtonSet.TabIndex = 91;
            this.btnDSBarCodeScanButtonSet.Text = "set";
            this.btnDSBarCodeScanButtonSet.UseVisualStyleBackColor = true;
            this.btnDSBarCodeScanButtonSet.Click += new System.EventHandler(this.btnDSBarCodeScanButtonSet_Click);
            // 
            // btnDSBarCodeScanButtonGet
            // 
            this.btnDSBarCodeScanButtonGet.Location = new System.Drawing.Point(259, 70);
            this.btnDSBarCodeScanButtonGet.Name = "btnDSBarCodeScanButtonGet";
            this.btnDSBarCodeScanButtonGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSBarCodeScanButtonGet.TabIndex = 90;
            this.btnDSBarCodeScanButtonGet.Text = "get";
            this.btnDSBarCodeScanButtonGet.UseVisualStyleBackColor = true;
            this.btnDSBarCodeScanButtonGet.Click += new System.EventHandler(this.btnDSBarCodeScanButtonGet_Click);
            // 
            // btnDSBarcodeModeSet
            // 
            this.btnDSBarcodeModeSet.Enabled = false;
            this.btnDSBarcodeModeSet.Location = new System.Drawing.Point(296, 41);
            this.btnDSBarcodeModeSet.Name = "btnDSBarcodeModeSet";
            this.btnDSBarcodeModeSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSBarcodeModeSet.TabIndex = 89;
            this.btnDSBarcodeModeSet.Text = "set";
            this.btnDSBarcodeModeSet.UseVisualStyleBackColor = true;
            this.btnDSBarcodeModeSet.Click += new System.EventHandler(this.btnDSBarcodeModeSet_Click);
            // 
            // btnDSBarcodeModeGet
            // 
            this.btnDSBarcodeModeGet.Location = new System.Drawing.Point(259, 41);
            this.btnDSBarcodeModeGet.Name = "btnDSBarcodeModeGet";
            this.btnDSBarcodeModeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSBarcodeModeGet.TabIndex = 88;
            this.btnDSBarcodeModeGet.Text = "get";
            this.btnDSBarcodeModeGet.UseVisualStyleBackColor = true;
            this.btnDSBarcodeModeGet.Click += new System.EventHandler(this.btnDSBarcodeModeGet_Click);
            // 
            // cmbFourPosSwitch
            // 
            this.cmbFourPosSwitch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFourPosSwitch.FormattingEnabled = true;
            this.cmbFourPosSwitch.Location = new System.Drawing.Point(103, 186);
            this.cmbFourPosSwitch.Name = "cmbFourPosSwitch";
            this.cmbFourPosSwitch.Size = new System.Drawing.Size(151, 21);
            this.cmbFourPosSwitch.TabIndex = 86;
            this.cmbFourPosSwitch.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 190);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 13);
            this.label6.TabIndex = 85;
            this.label6.Text = "FourPosSwitch";
            // 
            // cmbFileNamePrefixType
            // 
            this.cmbFileNamePrefixType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFileNamePrefixType.FormattingEnabled = true;
            this.cmbFileNamePrefixType.Location = new System.Drawing.Point(103, 157);
            this.cmbFileNamePrefixType.Name = "cmbFileNamePrefixType";
            this.cmbFileNamePrefixType.Size = new System.Drawing.Size(151, 21);
            this.cmbFileNamePrefixType.TabIndex = 84;
            this.cmbFileNamePrefixType.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-3, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 83;
            this.label5.Text = "FileNamePrefixType";
            // 
            // cmbFileCounterSource
            // 
            this.cmbFileCounterSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFileCounterSource.DropDownWidth = 160;
            this.cmbFileCounterSource.FormattingEnabled = true;
            this.cmbFileCounterSource.Location = new System.Drawing.Point(103, 128);
            this.cmbFileCounterSource.Name = "cmbFileCounterSource";
            this.cmbFileCounterSource.Size = new System.Drawing.Size(151, 21);
            this.cmbFileCounterSource.TabIndex = 82;
            this.cmbFileCounterSource.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 13);
            this.label4.TabIndex = 81;
            this.label4.Text = "FileCounterSource";
            // 
            // cmbDateTimeFormat
            // 
            this.cmbDateTimeFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDateTimeFormat.FormattingEnabled = true;
            this.cmbDateTimeFormat.Location = new System.Drawing.Point(103, 99);
            this.cmbDateTimeFormat.Name = "cmbDateTimeFormat";
            this.cmbDateTimeFormat.Size = new System.Drawing.Size(151, 21);
            this.cmbDateTimeFormat.TabIndex = 80;
            this.cmbDateTimeFormat.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 79;
            this.label3.Text = "DateTimeFormat";
            // 
            // cmbBarcodeScanButton
            // 
            this.cmbBarcodeScanButton.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBarcodeScanButton.FormattingEnabled = true;
            this.cmbBarcodeScanButton.Location = new System.Drawing.Point(103, 70);
            this.cmbBarcodeScanButton.Name = "cmbBarcodeScanButton";
            this.cmbBarcodeScanButton.Size = new System.Drawing.Size(151, 21);
            this.cmbBarcodeScanButton.TabIndex = 78;
            this.cmbBarcodeScanButton.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 77;
            this.label2.Text = "BCScanButton";
            // 
            // cmbBarcodeMode
            // 
            this.cmbBarcodeMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBarcodeMode.FormattingEnabled = true;
            this.cmbBarcodeMode.Location = new System.Drawing.Point(103, 41);
            this.cmbBarcodeMode.Name = "cmbBarcodeMode";
            this.cmbBarcodeMode.Size = new System.Drawing.Size(151, 21);
            this.cmbBarcodeMode.TabIndex = 76;
            this.cmbBarcodeMode.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 75;
            this.label1.Text = "BarcodeMode";
            // 
            // btnDSAppearanceSet
            // 
            this.btnDSAppearanceSet.Enabled = false;
            this.btnDSAppearanceSet.Location = new System.Drawing.Point(296, 12);
            this.btnDSAppearanceSet.Name = "btnDSAppearanceSet";
            this.btnDSAppearanceSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSAppearanceSet.TabIndex = 74;
            this.btnDSAppearanceSet.Text = "set";
            this.btnDSAppearanceSet.UseVisualStyleBackColor = true;
            this.btnDSAppearanceSet.Click += new System.EventHandler(this.btnDSAppearanceSet_Click);
            // 
            // btnDSAppearanceGet
            // 
            this.btnDSAppearanceGet.Location = new System.Drawing.Point(259, 12);
            this.btnDSAppearanceGet.Name = "btnDSAppearanceGet";
            this.btnDSAppearanceGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSAppearanceGet.TabIndex = 73;
            this.btnDSAppearanceGet.Text = "get";
            this.btnDSAppearanceGet.UseVisualStyleBackColor = true;
            this.btnDSAppearanceGet.Click += new System.EventHandler(this.btnDSAppearanceGet_Click);
            // 
            // AppearanceLabel
            // 
            this.AppearanceLabel.AutoSize = true;
            this.AppearanceLabel.Location = new System.Drawing.Point(30, 16);
            this.AppearanceLabel.Name = "AppearanceLabel";
            this.AppearanceLabel.Size = new System.Drawing.Size(65, 13);
            this.AppearanceLabel.TabIndex = 72;
            this.AppearanceLabel.Text = "Appearance";
            // 
            // cmbAppearance
            // 
            this.cmbAppearance.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAppearance.FormattingEnabled = true;
            this.cmbAppearance.Location = new System.Drawing.Point(103, 12);
            this.cmbAppearance.Name = "cmbAppearance";
            this.cmbAppearance.Size = new System.Drawing.Size(151, 21);
            this.cmbAppearance.TabIndex = 71;
            this.cmbAppearance.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // deviceSettings2TabPage
            // 
            this.deviceSettings2TabPage.Controls.Add(this.btnDSObligatoryKeywordSelectionSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSObligatoryKeywordSelectionGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbObligatoryKeywordSelection);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSMassStorageWriteProtectionSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSMassStorageWriteProtectionGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbMassStorageWriteProtection);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSVoiceActivationSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSVoiceActivationGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbVoiceActivation);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSUSBHighPowerModeSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSUSBHighPowerModeGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSScanKeywordsFromBarcodeSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSScanKeywordsFromBarcodeGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSRecordNotifySet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSRecordNotifyGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSRecordLevelSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSRecordLevelGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbUSBHighPowerMode);
            this.deviceSettings2TabPage.Controls.Add(this.cbScanKeywordsFromBarcode);
            this.deviceSettings2TabPage.Controls.Add(this.cbRecordNotify);
            this.deviceSettings2TabPage.Controls.Add(this.cbRecordLevelInd);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSProtectDeviceSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSProtectDeviceGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSProModeSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSProModeGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSProhibitFileAlterationSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSProhibitFileAlterationGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSPCMEnabledSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSPCMEnabledGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSOneFileSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSOneFileGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSNoiseReductionSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSNoiseReductionGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSLinkKeywordsSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSLinkKeywordsGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSInsertButtonEnabledSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSInsertButtonEnabledGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbProtectDevice);
            this.deviceSettings2TabPage.Controls.Add(this.cbProMode);
            this.deviceSettings2TabPage.Controls.Add(this.cbProhibitFileAlteration);
            this.deviceSettings2TabPage.Controls.Add(this.cbPCMEnabled);
            this.deviceSettings2TabPage.Controls.Add(this.cbOneFile);
            this.deviceSettings2TabPage.Controls.Add(this.cbNoiseReduction);
            this.deviceSettings2TabPage.Controls.Add(this.cbLinkKeywords);
            this.deviceSettings2TabPage.Controls.Add(this.cbInsertButtonEnabled);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSEOLButtonEnabledSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSEOLButtonEnabledGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSEnableUSBAudioSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSEnabledUSBAudioGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDLSButtonEnabledSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDLSButtonEnabledGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDeviceBeepSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDeviceBeepGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbEOLButtonEnabled);
            this.deviceSettings2TabPage.Controls.Add(this.cbEnableUSBAudio);
            this.deviceSettings2TabPage.Controls.Add(this.cbDLSButtonEnabled);
            this.deviceSettings2TabPage.Controls.Add(this.cbDeviceBeep);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDeleteFilesAfterDownloadSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDeleteFilesAfterDownloadGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDELButtonEnabledSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSDELButtonEnabledGet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSCueReviewSoundSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSCueReviewSoundGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbDeleteFilesAfterDownload);
            this.deviceSettings2TabPage.Controls.Add(this.cbDELButtonEnabled);
            this.deviceSettings2TabPage.Controls.Add(this.cbCueReviewSound);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSAppendModeSet);
            this.deviceSettings2TabPage.Controls.Add(this.btnDSAppendModeGet);
            this.deviceSettings2TabPage.Controls.Add(this.cbAppendMode);
            this.deviceSettings2TabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettings2TabPage.Name = "deviceSettings2TabPage";
            this.deviceSettings2TabPage.Padding = new System.Windows.Forms.Padding(3);
            this.deviceSettings2TabPage.Size = new System.Drawing.Size(704, 284);
            this.deviceSettings2TabPage.TabIndex = 1;
            this.deviceSettings2TabPage.Text = "Settings 2";
            this.deviceSettings2TabPage.UseVisualStyleBackColor = true;
            // 
            // btnDSObligatoryKeywordSelectionSet
            // 
            this.btnDSObligatoryKeywordSelectionSet.Enabled = false;
            this.btnDSObligatoryKeywordSelectionSet.Location = new System.Drawing.Point(471, 4);
            this.btnDSObligatoryKeywordSelectionSet.Name = "btnDSObligatoryKeywordSelectionSet";
            this.btnDSObligatoryKeywordSelectionSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSObligatoryKeywordSelectionSet.TabIndex = 136;
            this.btnDSObligatoryKeywordSelectionSet.Text = "set";
            this.btnDSObligatoryKeywordSelectionSet.UseVisualStyleBackColor = true;
            this.btnDSObligatoryKeywordSelectionSet.Click += new System.EventHandler(this.btnDSObligatoryKeywordSelection_Click);
            // 
            // btnDSObligatoryKeywordSelectionGet
            // 
            this.btnDSObligatoryKeywordSelectionGet.Location = new System.Drawing.Point(433, 4);
            this.btnDSObligatoryKeywordSelectionGet.Name = "btnDSObligatoryKeywordSelectionGet";
            this.btnDSObligatoryKeywordSelectionGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSObligatoryKeywordSelectionGet.TabIndex = 135;
            this.btnDSObligatoryKeywordSelectionGet.Text = "get";
            this.btnDSObligatoryKeywordSelectionGet.UseVisualStyleBackColor = true;
            this.btnDSObligatoryKeywordSelectionGet.Click += new System.EventHandler(this.btnDSObligatoryKeywordSelectionGet_Click);
            // 
            // cbObligatoryKeywordSelection
            // 
            this.cbObligatoryKeywordSelection.AutoSize = true;
            this.cbObligatoryKeywordSelection.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbObligatoryKeywordSelection.Checked = true;
            this.cbObligatoryKeywordSelection.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbObligatoryKeywordSelection.Location = new System.Drawing.Point(263, 6);
            this.cbObligatoryKeywordSelection.Name = "cbObligatoryKeywordSelection";
            this.cbObligatoryKeywordSelection.Size = new System.Drawing.Size(158, 17);
            this.cbObligatoryKeywordSelection.TabIndex = 134;
            this.cbObligatoryKeywordSelection.Text = "ObligatoryKeywordSelection";
            this.cbObligatoryKeywordSelection.UseVisualStyleBackColor = true;
            this.cbObligatoryKeywordSelection.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSMassStorageWriteProtectionSet
            // 
            this.btnDSMassStorageWriteProtectionSet.Enabled = false;
            this.btnDSMassStorageWriteProtectionSet.Location = new System.Drawing.Point(212, 226);
            this.btnDSMassStorageWriteProtectionSet.Name = "btnDSMassStorageWriteProtectionSet";
            this.btnDSMassStorageWriteProtectionSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSMassStorageWriteProtectionSet.TabIndex = 133;
            this.btnDSMassStorageWriteProtectionSet.Text = "set";
            this.btnDSMassStorageWriteProtectionSet.UseVisualStyleBackColor = true;
            this.btnDSMassStorageWriteProtectionSet.Click += new System.EventHandler(this.btnDSMassStorageWriteProtectionSet_Click);
            // 
            // btnDSMassStorageWriteProtectionGet
            // 
            this.btnDSMassStorageWriteProtectionGet.Location = new System.Drawing.Point(175, 226);
            this.btnDSMassStorageWriteProtectionGet.Name = "btnDSMassStorageWriteProtectionGet";
            this.btnDSMassStorageWriteProtectionGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSMassStorageWriteProtectionGet.TabIndex = 132;
            this.btnDSMassStorageWriteProtectionGet.Text = "get";
            this.btnDSMassStorageWriteProtectionGet.UseVisualStyleBackColor = true;
            this.btnDSMassStorageWriteProtectionGet.Click += new System.EventHandler(this.btnDSMassStorageWriteProtectionGet_Click);
            // 
            // cbMassStorageWriteProtection
            // 
            this.cbMassStorageWriteProtection.AutoSize = true;
            this.cbMassStorageWriteProtection.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbMassStorageWriteProtection.Checked = true;
            this.cbMassStorageWriteProtection.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbMassStorageWriteProtection.Location = new System.Drawing.Point(8, 228);
            this.cbMassStorageWriteProtection.Name = "cbMassStorageWriteProtection";
            this.cbMassStorageWriteProtection.Size = new System.Drawing.Size(161, 17);
            this.cbMassStorageWriteProtection.TabIndex = 131;
            this.cbMassStorageWriteProtection.Text = "MassStorageWriteProtection";
            this.cbMassStorageWriteProtection.UseVisualStyleBackColor = true;
            this.cbMassStorageWriteProtection.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSVoiceActivationSet
            // 
            this.btnDSVoiceActivationSet.Enabled = false;
            this.btnDSVoiceActivationSet.Location = new System.Drawing.Point(471, 234);
            this.btnDSVoiceActivationSet.Name = "btnDSVoiceActivationSet";
            this.btnDSVoiceActivationSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSVoiceActivationSet.TabIndex = 130;
            this.btnDSVoiceActivationSet.Text = "set";
            this.btnDSVoiceActivationSet.UseVisualStyleBackColor = true;
            this.btnDSVoiceActivationSet.Click += new System.EventHandler(this.btnDSVoiceActivationSet_Click);
            // 
            // btnDSVoiceActivationGet
            // 
            this.btnDSVoiceActivationGet.Location = new System.Drawing.Point(433, 234);
            this.btnDSVoiceActivationGet.Name = "btnDSVoiceActivationGet";
            this.btnDSVoiceActivationGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSVoiceActivationGet.TabIndex = 129;
            this.btnDSVoiceActivationGet.Text = "get";
            this.btnDSVoiceActivationGet.UseVisualStyleBackColor = true;
            this.btnDSVoiceActivationGet.Click += new System.EventHandler(this.btnDSVoiceActivationGet_Click);
            // 
            // cbVoiceActivation
            // 
            this.cbVoiceActivation.AutoSize = true;
            this.cbVoiceActivation.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbVoiceActivation.Checked = true;
            this.cbVoiceActivation.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbVoiceActivation.Location = new System.Drawing.Point(321, 236);
            this.cbVoiceActivation.Name = "cbVoiceActivation";
            this.cbVoiceActivation.Size = new System.Drawing.Size(100, 17);
            this.cbVoiceActivation.TabIndex = 128;
            this.cbVoiceActivation.Text = "VoiceActivation";
            this.cbVoiceActivation.UseVisualStyleBackColor = true;
            this.cbVoiceActivation.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSUSBHighPowerModeSet
            // 
            this.btnDSUSBHighPowerModeSet.Enabled = false;
            this.btnDSUSBHighPowerModeSet.Location = new System.Drawing.Point(471, 211);
            this.btnDSUSBHighPowerModeSet.Name = "btnDSUSBHighPowerModeSet";
            this.btnDSUSBHighPowerModeSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSUSBHighPowerModeSet.TabIndex = 127;
            this.btnDSUSBHighPowerModeSet.Text = "set";
            this.btnDSUSBHighPowerModeSet.UseVisualStyleBackColor = true;
            this.btnDSUSBHighPowerModeSet.Click += new System.EventHandler(this.btnDSUSBHighPowerModeSet_Click);
            // 
            // btnDSUSBHighPowerModeGet
            // 
            this.btnDSUSBHighPowerModeGet.Location = new System.Drawing.Point(433, 211);
            this.btnDSUSBHighPowerModeGet.Name = "btnDSUSBHighPowerModeGet";
            this.btnDSUSBHighPowerModeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSUSBHighPowerModeGet.TabIndex = 126;
            this.btnDSUSBHighPowerModeGet.Text = "get";
            this.btnDSUSBHighPowerModeGet.UseVisualStyleBackColor = true;
            this.btnDSUSBHighPowerModeGet.Click += new System.EventHandler(this.btnDSUSBHighPowerModeGet_Click);
            // 
            // btnDSScanKeywordsFromBarcodeSet
            // 
            this.btnDSScanKeywordsFromBarcodeSet.Enabled = false;
            this.btnDSScanKeywordsFromBarcodeSet.Location = new System.Drawing.Point(471, 188);
            this.btnDSScanKeywordsFromBarcodeSet.Name = "btnDSScanKeywordsFromBarcodeSet";
            this.btnDSScanKeywordsFromBarcodeSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSScanKeywordsFromBarcodeSet.TabIndex = 125;
            this.btnDSScanKeywordsFromBarcodeSet.Text = "set";
            this.btnDSScanKeywordsFromBarcodeSet.UseVisualStyleBackColor = true;
            this.btnDSScanKeywordsFromBarcodeSet.Click += new System.EventHandler(this.btnDSScanKeywordsFromBarcodeSet_Click);
            // 
            // btnDSScanKeywordsFromBarcodeGet
            // 
            this.btnDSScanKeywordsFromBarcodeGet.Location = new System.Drawing.Point(433, 188);
            this.btnDSScanKeywordsFromBarcodeGet.Name = "btnDSScanKeywordsFromBarcodeGet";
            this.btnDSScanKeywordsFromBarcodeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSScanKeywordsFromBarcodeGet.TabIndex = 124;
            this.btnDSScanKeywordsFromBarcodeGet.Text = "get";
            this.btnDSScanKeywordsFromBarcodeGet.UseVisualStyleBackColor = true;
            this.btnDSScanKeywordsFromBarcodeGet.Click += new System.EventHandler(this.btnDSScanKeywordsFromBarcodeGet_Click);
            // 
            // btnDSRecordNotifySet
            // 
            this.btnDSRecordNotifySet.Enabled = false;
            this.btnDSRecordNotifySet.Location = new System.Drawing.Point(471, 165);
            this.btnDSRecordNotifySet.Name = "btnDSRecordNotifySet";
            this.btnDSRecordNotifySet.Size = new System.Drawing.Size(31, 21);
            this.btnDSRecordNotifySet.TabIndex = 123;
            this.btnDSRecordNotifySet.Text = "set";
            this.btnDSRecordNotifySet.UseVisualStyleBackColor = true;
            this.btnDSRecordNotifySet.Click += new System.EventHandler(this.btnDSRecordNotifySet_Click);
            // 
            // btnDSRecordNotifyGet
            // 
            this.btnDSRecordNotifyGet.Location = new System.Drawing.Point(433, 165);
            this.btnDSRecordNotifyGet.Name = "btnDSRecordNotifyGet";
            this.btnDSRecordNotifyGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSRecordNotifyGet.TabIndex = 122;
            this.btnDSRecordNotifyGet.Text = "get";
            this.btnDSRecordNotifyGet.UseVisualStyleBackColor = true;
            this.btnDSRecordNotifyGet.Click += new System.EventHandler(this.btnDSRecordNotifyGet_Click);
            // 
            // btnDSRecordLevelSet
            // 
            this.btnDSRecordLevelSet.Enabled = false;
            this.btnDSRecordLevelSet.Location = new System.Drawing.Point(471, 142);
            this.btnDSRecordLevelSet.Name = "btnDSRecordLevelSet";
            this.btnDSRecordLevelSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSRecordLevelSet.TabIndex = 121;
            this.btnDSRecordLevelSet.Text = "set";
            this.btnDSRecordLevelSet.UseVisualStyleBackColor = true;
            this.btnDSRecordLevelSet.Click += new System.EventHandler(this.btnDSRecordLevelSet_Click);
            // 
            // btnDSRecordLevelGet
            // 
            this.btnDSRecordLevelGet.Location = new System.Drawing.Point(433, 142);
            this.btnDSRecordLevelGet.Name = "btnDSRecordLevelGet";
            this.btnDSRecordLevelGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSRecordLevelGet.TabIndex = 120;
            this.btnDSRecordLevelGet.Text = "get";
            this.btnDSRecordLevelGet.UseVisualStyleBackColor = true;
            this.btnDSRecordLevelGet.Click += new System.EventHandler(this.btnDSRecordLevelGet_Click);
            // 
            // cbUSBHighPowerMode
            // 
            this.cbUSBHighPowerMode.AutoSize = true;
            this.cbUSBHighPowerMode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbUSBHighPowerMode.Checked = true;
            this.cbUSBHighPowerMode.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbUSBHighPowerMode.Location = new System.Drawing.Point(294, 213);
            this.cbUSBHighPowerMode.Name = "cbUSBHighPowerMode";
            this.cbUSBHighPowerMode.Size = new System.Drawing.Size(127, 17);
            this.cbUSBHighPowerMode.TabIndex = 119;
            this.cbUSBHighPowerMode.Text = "USBHighPowerMode";
            this.cbUSBHighPowerMode.UseVisualStyleBackColor = true;
            this.cbUSBHighPowerMode.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbScanKeywordsFromBarcode
            // 
            this.cbScanKeywordsFromBarcode.AutoSize = true;
            this.cbScanKeywordsFromBarcode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbScanKeywordsFromBarcode.Checked = true;
            this.cbScanKeywordsFromBarcode.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbScanKeywordsFromBarcode.Location = new System.Drawing.Point(261, 190);
            this.cbScanKeywordsFromBarcode.Name = "cbScanKeywordsFromBarcode";
            this.cbScanKeywordsFromBarcode.Size = new System.Drawing.Size(160, 17);
            this.cbScanKeywordsFromBarcode.TabIndex = 118;
            this.cbScanKeywordsFromBarcode.Text = "ScanKeywordsFromBarcode";
            this.cbScanKeywordsFromBarcode.UseVisualStyleBackColor = true;
            this.cbScanKeywordsFromBarcode.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbRecordNotify
            // 
            this.cbRecordNotify.AutoSize = true;
            this.cbRecordNotify.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbRecordNotify.Checked = true;
            this.cbRecordNotify.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbRecordNotify.Location = new System.Drawing.Point(333, 167);
            this.cbRecordNotify.Name = "cbRecordNotify";
            this.cbRecordNotify.Size = new System.Drawing.Size(88, 17);
            this.cbRecordNotify.TabIndex = 117;
            this.cbRecordNotify.Text = "RecordNotify";
            this.cbRecordNotify.UseVisualStyleBackColor = true;
            this.cbRecordNotify.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbRecordLevelInd
            // 
            this.cbRecordLevelInd.AutoSize = true;
            this.cbRecordLevelInd.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbRecordLevelInd.Checked = true;
            this.cbRecordLevelInd.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbRecordLevelInd.Location = new System.Drawing.Point(319, 144);
            this.cbRecordLevelInd.Name = "cbRecordLevelInd";
            this.cbRecordLevelInd.Size = new System.Drawing.Size(102, 17);
            this.cbRecordLevelInd.TabIndex = 116;
            this.cbRecordLevelInd.Text = "RecordLevelInd";
            this.cbRecordLevelInd.UseVisualStyleBackColor = true;
            this.cbRecordLevelInd.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSProtectDeviceSet
            // 
            this.btnDSProtectDeviceSet.Enabled = false;
            this.btnDSProtectDeviceSet.Location = new System.Drawing.Point(471, 119);
            this.btnDSProtectDeviceSet.Name = "btnDSProtectDeviceSet";
            this.btnDSProtectDeviceSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSProtectDeviceSet.TabIndex = 115;
            this.btnDSProtectDeviceSet.Text = "set";
            this.btnDSProtectDeviceSet.UseVisualStyleBackColor = true;
            this.btnDSProtectDeviceSet.Click += new System.EventHandler(this.btnDSProtectDeviceSet_Click);
            // 
            // btnDSProtectDeviceGet
            // 
            this.btnDSProtectDeviceGet.Location = new System.Drawing.Point(433, 119);
            this.btnDSProtectDeviceGet.Name = "btnDSProtectDeviceGet";
            this.btnDSProtectDeviceGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSProtectDeviceGet.TabIndex = 114;
            this.btnDSProtectDeviceGet.Text = "get";
            this.btnDSProtectDeviceGet.UseVisualStyleBackColor = true;
            this.btnDSProtectDeviceGet.Click += new System.EventHandler(this.btnDSProtectDeviceGet_Click);
            // 
            // btnDSProModeSet
            // 
            this.btnDSProModeSet.Enabled = false;
            this.btnDSProModeSet.Location = new System.Drawing.Point(471, 96);
            this.btnDSProModeSet.Name = "btnDSProModeSet";
            this.btnDSProModeSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSProModeSet.TabIndex = 113;
            this.btnDSProModeSet.Text = "set";
            this.btnDSProModeSet.UseVisualStyleBackColor = true;
            this.btnDSProModeSet.Click += new System.EventHandler(this.btnDSProModeSet_Click);
            // 
            // btnDSProModeGet
            // 
            this.btnDSProModeGet.Location = new System.Drawing.Point(433, 96);
            this.btnDSProModeGet.Name = "btnDSProModeGet";
            this.btnDSProModeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSProModeGet.TabIndex = 112;
            this.btnDSProModeGet.Text = "get";
            this.btnDSProModeGet.UseVisualStyleBackColor = true;
            this.btnDSProModeGet.Click += new System.EventHandler(this.btnDSProModeGet_Click);
            // 
            // btnDSProhibitFileAlterationSet
            // 
            this.btnDSProhibitFileAlterationSet.Enabled = false;
            this.btnDSProhibitFileAlterationSet.Location = new System.Drawing.Point(471, 73);
            this.btnDSProhibitFileAlterationSet.Name = "btnDSProhibitFileAlterationSet";
            this.btnDSProhibitFileAlterationSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSProhibitFileAlterationSet.TabIndex = 111;
            this.btnDSProhibitFileAlterationSet.Text = "set";
            this.btnDSProhibitFileAlterationSet.UseVisualStyleBackColor = true;
            this.btnDSProhibitFileAlterationSet.Click += new System.EventHandler(this.btnDSProhibitFileAlterationSet_Click);
            // 
            // btnDSProhibitFileAlterationGet
            // 
            this.btnDSProhibitFileAlterationGet.Location = new System.Drawing.Point(433, 73);
            this.btnDSProhibitFileAlterationGet.Name = "btnDSProhibitFileAlterationGet";
            this.btnDSProhibitFileAlterationGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSProhibitFileAlterationGet.TabIndex = 110;
            this.btnDSProhibitFileAlterationGet.Text = "get";
            this.btnDSProhibitFileAlterationGet.UseVisualStyleBackColor = true;
            this.btnDSProhibitFileAlterationGet.Click += new System.EventHandler(this.btnDSProhibitFileAlterationGet_Click);
            // 
            // btnDSPCMEnabledSet
            // 
            this.btnDSPCMEnabledSet.Enabled = false;
            this.btnDSPCMEnabledSet.Location = new System.Drawing.Point(471, 50);
            this.btnDSPCMEnabledSet.Name = "btnDSPCMEnabledSet";
            this.btnDSPCMEnabledSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSPCMEnabledSet.TabIndex = 109;
            this.btnDSPCMEnabledSet.Text = "set";
            this.btnDSPCMEnabledSet.UseVisualStyleBackColor = true;
            this.btnDSPCMEnabledSet.Click += new System.EventHandler(this.btnDSPCMEnabledSet_Click);
            // 
            // btnDSPCMEnabledGet
            // 
            this.btnDSPCMEnabledGet.Location = new System.Drawing.Point(433, 50);
            this.btnDSPCMEnabledGet.Name = "btnDSPCMEnabledGet";
            this.btnDSPCMEnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSPCMEnabledGet.TabIndex = 108;
            this.btnDSPCMEnabledGet.Text = "get";
            this.btnDSPCMEnabledGet.UseVisualStyleBackColor = true;
            this.btnDSPCMEnabledGet.Click += new System.EventHandler(this.btnDSPCMEnabledGet_Click);
            // 
            // btnDSOneFileSet
            // 
            this.btnDSOneFileSet.Enabled = false;
            this.btnDSOneFileSet.Location = new System.Drawing.Point(471, 27);
            this.btnDSOneFileSet.Name = "btnDSOneFileSet";
            this.btnDSOneFileSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSOneFileSet.TabIndex = 107;
            this.btnDSOneFileSet.Text = "set";
            this.btnDSOneFileSet.UseVisualStyleBackColor = true;
            this.btnDSOneFileSet.Click += new System.EventHandler(this.btnDSOneFileSet_Click);
            // 
            // btnDSOneFileGet
            // 
            this.btnDSOneFileGet.Location = new System.Drawing.Point(433, 27);
            this.btnDSOneFileGet.Name = "btnDSOneFileGet";
            this.btnDSOneFileGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSOneFileGet.TabIndex = 106;
            this.btnDSOneFileGet.Text = "get";
            this.btnDSOneFileGet.UseVisualStyleBackColor = true;
            this.btnDSOneFileGet.Click += new System.EventHandler(this.btnDSOneFileGet_Click);
            // 
            // btnDSNoiseReductionSet
            // 
            this.btnDSNoiseReductionSet.Enabled = false;
            this.btnDSNoiseReductionSet.Location = new System.Drawing.Point(212, 250);
            this.btnDSNoiseReductionSet.Name = "btnDSNoiseReductionSet";
            this.btnDSNoiseReductionSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSNoiseReductionSet.TabIndex = 105;
            this.btnDSNoiseReductionSet.Text = "set";
            this.btnDSNoiseReductionSet.UseVisualStyleBackColor = true;
            this.btnDSNoiseReductionSet.Click += new System.EventHandler(this.btnDSNoiseReductionSet_Click);
            // 
            // btnDSNoiseReductionGet
            // 
            this.btnDSNoiseReductionGet.Location = new System.Drawing.Point(175, 250);
            this.btnDSNoiseReductionGet.Name = "btnDSNoiseReductionGet";
            this.btnDSNoiseReductionGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSNoiseReductionGet.TabIndex = 104;
            this.btnDSNoiseReductionGet.Text = "get";
            this.btnDSNoiseReductionGet.UseVisualStyleBackColor = true;
            this.btnDSNoiseReductionGet.Click += new System.EventHandler(this.btnDSNoiseReductionGet_Click);
            // 
            // btnDSLinkKeywordsSet
            // 
            this.btnDSLinkKeywordsSet.Enabled = false;
            this.btnDSLinkKeywordsSet.Location = new System.Drawing.Point(212, 203);
            this.btnDSLinkKeywordsSet.Name = "btnDSLinkKeywordsSet";
            this.btnDSLinkKeywordsSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSLinkKeywordsSet.TabIndex = 103;
            this.btnDSLinkKeywordsSet.Text = "set";
            this.btnDSLinkKeywordsSet.UseVisualStyleBackColor = true;
            this.btnDSLinkKeywordsSet.Click += new System.EventHandler(this.btnDSLinkKeywordsSet_Click);
            // 
            // btnDSLinkKeywordsGet
            // 
            this.btnDSLinkKeywordsGet.Location = new System.Drawing.Point(175, 203);
            this.btnDSLinkKeywordsGet.Name = "btnDSLinkKeywordsGet";
            this.btnDSLinkKeywordsGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSLinkKeywordsGet.TabIndex = 102;
            this.btnDSLinkKeywordsGet.Text = "get";
            this.btnDSLinkKeywordsGet.UseVisualStyleBackColor = true;
            this.btnDSLinkKeywordsGet.Click += new System.EventHandler(this.btnDSLinkKeywordsGet_Click);
            // 
            // btnDSInsertButtonEnabledSet
            // 
            this.btnDSInsertButtonEnabledSet.Enabled = false;
            this.btnDSInsertButtonEnabledSet.Location = new System.Drawing.Point(212, 180);
            this.btnDSInsertButtonEnabledSet.Name = "btnDSInsertButtonEnabledSet";
            this.btnDSInsertButtonEnabledSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSInsertButtonEnabledSet.TabIndex = 101;
            this.btnDSInsertButtonEnabledSet.Text = "set";
            this.btnDSInsertButtonEnabledSet.UseVisualStyleBackColor = true;
            this.btnDSInsertButtonEnabledSet.Click += new System.EventHandler(this.btnDSInsertButtonEnabledSet_Click);
            // 
            // btnDSInsertButtonEnabledGet
            // 
            this.btnDSInsertButtonEnabledGet.Location = new System.Drawing.Point(175, 180);
            this.btnDSInsertButtonEnabledGet.Name = "btnDSInsertButtonEnabledGet";
            this.btnDSInsertButtonEnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSInsertButtonEnabledGet.TabIndex = 100;
            this.btnDSInsertButtonEnabledGet.Text = "get";
            this.btnDSInsertButtonEnabledGet.UseVisualStyleBackColor = true;
            this.btnDSInsertButtonEnabledGet.Click += new System.EventHandler(this.btnDSInsertButtonEnabledGet_Click);
            // 
            // cbProtectDevice
            // 
            this.cbProtectDevice.AutoSize = true;
            this.cbProtectDevice.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbProtectDevice.Checked = true;
            this.cbProtectDevice.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbProtectDevice.Location = new System.Drawing.Point(327, 121);
            this.cbProtectDevice.Name = "cbProtectDevice";
            this.cbProtectDevice.Size = new System.Drawing.Size(94, 17);
            this.cbProtectDevice.TabIndex = 99;
            this.cbProtectDevice.Text = "ProtectDevice";
            this.cbProtectDevice.UseVisualStyleBackColor = true;
            this.cbProtectDevice.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbProMode
            // 
            this.cbProMode.AutoSize = true;
            this.cbProMode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbProMode.Checked = true;
            this.cbProMode.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbProMode.Location = new System.Drawing.Point(352, 98);
            this.cbProMode.Name = "cbProMode";
            this.cbProMode.Size = new System.Drawing.Size(69, 17);
            this.cbProMode.TabIndex = 98;
            this.cbProMode.Text = "ProMode";
            this.cbProMode.UseVisualStyleBackColor = true;
            this.cbProMode.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbProhibitFileAlteration
            // 
            this.cbProhibitFileAlteration.AutoSize = true;
            this.cbProhibitFileAlteration.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbProhibitFileAlteration.Checked = true;
            this.cbProhibitFileAlteration.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbProhibitFileAlteration.Location = new System.Drawing.Point(300, 75);
            this.cbProhibitFileAlteration.Name = "cbProhibitFileAlteration";
            this.cbProhibitFileAlteration.Size = new System.Drawing.Size(121, 17);
            this.cbProhibitFileAlteration.TabIndex = 97;
            this.cbProhibitFileAlteration.Text = "ProhibitFileAlteration";
            this.cbProhibitFileAlteration.UseVisualStyleBackColor = true;
            this.cbProhibitFileAlteration.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbPCMEnabled
            // 
            this.cbPCMEnabled.AutoSize = true;
            this.cbPCMEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbPCMEnabled.Checked = true;
            this.cbPCMEnabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbPCMEnabled.Location = new System.Drawing.Point(333, 52);
            this.cbPCMEnabled.Name = "cbPCMEnabled";
            this.cbPCMEnabled.Size = new System.Drawing.Size(88, 17);
            this.cbPCMEnabled.TabIndex = 96;
            this.cbPCMEnabled.Text = "PCMEnabled";
            this.cbPCMEnabled.UseVisualStyleBackColor = true;
            this.cbPCMEnabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbOneFile
            // 
            this.cbOneFile.AutoSize = true;
            this.cbOneFile.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbOneFile.Checked = true;
            this.cbOneFile.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbOneFile.Location = new System.Drawing.Point(359, 29);
            this.cbOneFile.Name = "cbOneFile";
            this.cbOneFile.Size = new System.Drawing.Size(62, 17);
            this.cbOneFile.TabIndex = 95;
            this.cbOneFile.Text = "OneFile";
            this.cbOneFile.UseVisualStyleBackColor = true;
            this.cbOneFile.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbNoiseReduction
            // 
            this.cbNoiseReduction.AutoSize = true;
            this.cbNoiseReduction.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbNoiseReduction.Checked = true;
            this.cbNoiseReduction.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbNoiseReduction.Location = new System.Drawing.Point(67, 252);
            this.cbNoiseReduction.Name = "cbNoiseReduction";
            this.cbNoiseReduction.Size = new System.Drawing.Size(102, 17);
            this.cbNoiseReduction.TabIndex = 94;
            this.cbNoiseReduction.Text = "NoiseReduction";
            this.cbNoiseReduction.UseVisualStyleBackColor = true;
            this.cbNoiseReduction.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbLinkKeywords
            // 
            this.cbLinkKeywords.AutoSize = true;
            this.cbLinkKeywords.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbLinkKeywords.Checked = true;
            this.cbLinkKeywords.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbLinkKeywords.Location = new System.Drawing.Point(77, 205);
            this.cbLinkKeywords.Name = "cbLinkKeywords";
            this.cbLinkKeywords.Size = new System.Drawing.Size(92, 17);
            this.cbLinkKeywords.TabIndex = 93;
            this.cbLinkKeywords.Text = "LinkKeywords";
            this.cbLinkKeywords.UseVisualStyleBackColor = true;
            this.cbLinkKeywords.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbInsertButtonEnabled
            // 
            this.cbInsertButtonEnabled.AutoSize = true;
            this.cbInsertButtonEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbInsertButtonEnabled.Checked = true;
            this.cbInsertButtonEnabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbInsertButtonEnabled.Location = new System.Drawing.Point(47, 182);
            this.cbInsertButtonEnabled.Name = "cbInsertButtonEnabled";
            this.cbInsertButtonEnabled.Size = new System.Drawing.Size(122, 17);
            this.cbInsertButtonEnabled.TabIndex = 92;
            this.cbInsertButtonEnabled.Text = "InsertButtonEnabled";
            this.cbInsertButtonEnabled.UseVisualStyleBackColor = true;
            this.cbInsertButtonEnabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSEOLButtonEnabledSet
            // 
            this.btnDSEOLButtonEnabledSet.Enabled = false;
            this.btnDSEOLButtonEnabledSet.Location = new System.Drawing.Point(212, 158);
            this.btnDSEOLButtonEnabledSet.Name = "btnDSEOLButtonEnabledSet";
            this.btnDSEOLButtonEnabledSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSEOLButtonEnabledSet.TabIndex = 91;
            this.btnDSEOLButtonEnabledSet.Text = "set";
            this.btnDSEOLButtonEnabledSet.UseVisualStyleBackColor = true;
            this.btnDSEOLButtonEnabledSet.Click += new System.EventHandler(this.btnDSEOLButtonEnabledSet_Click);
            // 
            // btnDSEOLButtonEnabledGet
            // 
            this.btnDSEOLButtonEnabledGet.Location = new System.Drawing.Point(175, 158);
            this.btnDSEOLButtonEnabledGet.Name = "btnDSEOLButtonEnabledGet";
            this.btnDSEOLButtonEnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSEOLButtonEnabledGet.TabIndex = 90;
            this.btnDSEOLButtonEnabledGet.Text = "get";
            this.btnDSEOLButtonEnabledGet.UseVisualStyleBackColor = true;
            this.btnDSEOLButtonEnabledGet.Click += new System.EventHandler(this.btnDSEOLButtonEnabledGet_Click);
            // 
            // btnDSEnableUSBAudioSet
            // 
            this.btnDSEnableUSBAudioSet.Enabled = false;
            this.btnDSEnableUSBAudioSet.Location = new System.Drawing.Point(212, 136);
            this.btnDSEnableUSBAudioSet.Name = "btnDSEnableUSBAudioSet";
            this.btnDSEnableUSBAudioSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSEnableUSBAudioSet.TabIndex = 89;
            this.btnDSEnableUSBAudioSet.Text = "set";
            this.btnDSEnableUSBAudioSet.UseVisualStyleBackColor = true;
            this.btnDSEnableUSBAudioSet.Click += new System.EventHandler(this.btnDSEnableUSBAudioSet_Click);
            // 
            // btnDSEnabledUSBAudioGet
            // 
            this.btnDSEnabledUSBAudioGet.Location = new System.Drawing.Point(175, 136);
            this.btnDSEnabledUSBAudioGet.Name = "btnDSEnabledUSBAudioGet";
            this.btnDSEnabledUSBAudioGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSEnabledUSBAudioGet.TabIndex = 88;
            this.btnDSEnabledUSBAudioGet.Text = "get";
            this.btnDSEnabledUSBAudioGet.UseVisualStyleBackColor = true;
            this.btnDSEnabledUSBAudioGet.Click += new System.EventHandler(this.btnDSEnabledUSBAudioGet_Click);
            // 
            // btnDSDLSButtonEnabledSet
            // 
            this.btnDSDLSButtonEnabledSet.Enabled = false;
            this.btnDSDLSButtonEnabledSet.Location = new System.Drawing.Point(212, 114);
            this.btnDSDLSButtonEnabledSet.Name = "btnDSDLSButtonEnabledSet";
            this.btnDSDLSButtonEnabledSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSDLSButtonEnabledSet.TabIndex = 87;
            this.btnDSDLSButtonEnabledSet.Text = "set";
            this.btnDSDLSButtonEnabledSet.UseVisualStyleBackColor = true;
            this.btnDSDLSButtonEnabledSet.Click += new System.EventHandler(this.btnDSDLSButtonEnabledSet_Click);
            // 
            // btnDSDLSButtonEnabledGet
            // 
            this.btnDSDLSButtonEnabledGet.Location = new System.Drawing.Point(175, 114);
            this.btnDSDLSButtonEnabledGet.Name = "btnDSDLSButtonEnabledGet";
            this.btnDSDLSButtonEnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDLSButtonEnabledGet.TabIndex = 86;
            this.btnDSDLSButtonEnabledGet.Text = "get";
            this.btnDSDLSButtonEnabledGet.UseVisualStyleBackColor = true;
            this.btnDSDLSButtonEnabledGet.Click += new System.EventHandler(this.btnDSDLSButtonEnabledGet_Click);
            // 
            // btnDSDeviceBeepSet
            // 
            this.btnDSDeviceBeepSet.Enabled = false;
            this.btnDSDeviceBeepSet.Location = new System.Drawing.Point(212, 92);
            this.btnDSDeviceBeepSet.Name = "btnDSDeviceBeepSet";
            this.btnDSDeviceBeepSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSDeviceBeepSet.TabIndex = 85;
            this.btnDSDeviceBeepSet.Text = "set";
            this.btnDSDeviceBeepSet.UseVisualStyleBackColor = true;
            this.btnDSDeviceBeepSet.Click += new System.EventHandler(this.btnDSDeviceBeepSet_Click);
            // 
            // btnDSDeviceBeepGet
            // 
            this.btnDSDeviceBeepGet.Location = new System.Drawing.Point(175, 92);
            this.btnDSDeviceBeepGet.Name = "btnDSDeviceBeepGet";
            this.btnDSDeviceBeepGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDeviceBeepGet.TabIndex = 84;
            this.btnDSDeviceBeepGet.Text = "get";
            this.btnDSDeviceBeepGet.UseVisualStyleBackColor = true;
            this.btnDSDeviceBeepGet.Click += new System.EventHandler(this.btnDSDeviceBeepGet_Click);
            // 
            // cbEOLButtonEnabled
            // 
            this.cbEOLButtonEnabled.AutoSize = true;
            this.cbEOLButtonEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbEOLButtonEnabled.Checked = true;
            this.cbEOLButtonEnabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbEOLButtonEnabled.Location = new System.Drawing.Point(52, 160);
            this.cbEOLButtonEnabled.Name = "cbEOLButtonEnabled";
            this.cbEOLButtonEnabled.Size = new System.Drawing.Size(117, 17);
            this.cbEOLButtonEnabled.TabIndex = 83;
            this.cbEOLButtonEnabled.Text = "EOLButtonEnabled";
            this.cbEOLButtonEnabled.UseVisualStyleBackColor = true;
            this.cbEOLButtonEnabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbEnableUSBAudio
            // 
            this.cbEnableUSBAudio.AutoSize = true;
            this.cbEnableUSBAudio.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbEnableUSBAudio.Checked = true;
            this.cbEnableUSBAudio.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbEnableUSBAudio.Location = new System.Drawing.Point(61, 138);
            this.cbEnableUSBAudio.Name = "cbEnableUSBAudio";
            this.cbEnableUSBAudio.Size = new System.Drawing.Size(108, 17);
            this.cbEnableUSBAudio.TabIndex = 82;
            this.cbEnableUSBAudio.Text = "EnableUSBAudio";
            this.cbEnableUSBAudio.UseVisualStyleBackColor = true;
            this.cbEnableUSBAudio.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbDLSButtonEnabled
            // 
            this.cbDLSButtonEnabled.AutoSize = true;
            this.cbDLSButtonEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDLSButtonEnabled.Checked = true;
            this.cbDLSButtonEnabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDLSButtonEnabled.Location = new System.Drawing.Point(52, 116);
            this.cbDLSButtonEnabled.Name = "cbDLSButtonEnabled";
            this.cbDLSButtonEnabled.Size = new System.Drawing.Size(117, 17);
            this.cbDLSButtonEnabled.TabIndex = 81;
            this.cbDLSButtonEnabled.Text = "DLSButtonEnabled";
            this.cbDLSButtonEnabled.UseVisualStyleBackColor = true;
            this.cbDLSButtonEnabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbDeviceBeep
            // 
            this.cbDeviceBeep.AutoSize = true;
            this.cbDeviceBeep.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDeviceBeep.Checked = true;
            this.cbDeviceBeep.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDeviceBeep.Location = new System.Drawing.Point(84, 94);
            this.cbDeviceBeep.Name = "cbDeviceBeep";
            this.cbDeviceBeep.Size = new System.Drawing.Size(85, 17);
            this.cbDeviceBeep.TabIndex = 80;
            this.cbDeviceBeep.Text = "DeviceBeep";
            this.cbDeviceBeep.UseVisualStyleBackColor = true;
            this.cbDeviceBeep.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSDeleteFilesAfterDownloadSet
            // 
            this.btnDSDeleteFilesAfterDownloadSet.Enabled = false;
            this.btnDSDeleteFilesAfterDownloadSet.Location = new System.Drawing.Point(212, 70);
            this.btnDSDeleteFilesAfterDownloadSet.Name = "btnDSDeleteFilesAfterDownloadSet";
            this.btnDSDeleteFilesAfterDownloadSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSDeleteFilesAfterDownloadSet.TabIndex = 79;
            this.btnDSDeleteFilesAfterDownloadSet.Text = "set";
            this.btnDSDeleteFilesAfterDownloadSet.UseVisualStyleBackColor = true;
            this.btnDSDeleteFilesAfterDownloadSet.Click += new System.EventHandler(this.btnDSDeleteFilesAfterDownloadSet_Click);
            // 
            // btnDSDeleteFilesAfterDownloadGet
            // 
            this.btnDSDeleteFilesAfterDownloadGet.Location = new System.Drawing.Point(175, 70);
            this.btnDSDeleteFilesAfterDownloadGet.Name = "btnDSDeleteFilesAfterDownloadGet";
            this.btnDSDeleteFilesAfterDownloadGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDeleteFilesAfterDownloadGet.TabIndex = 78;
            this.btnDSDeleteFilesAfterDownloadGet.Text = "get";
            this.btnDSDeleteFilesAfterDownloadGet.UseVisualStyleBackColor = true;
            this.btnDSDeleteFilesAfterDownloadGet.Click += new System.EventHandler(this.btnDSDeleteFilesAfterDownloadGet_Click);
            // 
            // btnDSDELButtonEnabledSet
            // 
            this.btnDSDELButtonEnabledSet.Enabled = false;
            this.btnDSDELButtonEnabledSet.Location = new System.Drawing.Point(212, 48);
            this.btnDSDELButtonEnabledSet.Name = "btnDSDELButtonEnabledSet";
            this.btnDSDELButtonEnabledSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSDELButtonEnabledSet.TabIndex = 77;
            this.btnDSDELButtonEnabledSet.Text = "set";
            this.btnDSDELButtonEnabledSet.UseVisualStyleBackColor = true;
            this.btnDSDELButtonEnabledSet.Click += new System.EventHandler(this.btnDSDELButtonEnabledSet_Click);
            // 
            // btnDSDELButtonEnabledGet
            // 
            this.btnDSDELButtonEnabledGet.Location = new System.Drawing.Point(175, 48);
            this.btnDSDELButtonEnabledGet.Name = "btnDSDELButtonEnabledGet";
            this.btnDSDELButtonEnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDELButtonEnabledGet.TabIndex = 76;
            this.btnDSDELButtonEnabledGet.Text = "get";
            this.btnDSDELButtonEnabledGet.UseVisualStyleBackColor = true;
            this.btnDSDELButtonEnabledGet.Click += new System.EventHandler(this.btnDSDELButtonEnabledGet_Click);
            // 
            // btnDSCueReviewSoundSet
            // 
            this.btnDSCueReviewSoundSet.Enabled = false;
            this.btnDSCueReviewSoundSet.Location = new System.Drawing.Point(212, 26);
            this.btnDSCueReviewSoundSet.Name = "btnDSCueReviewSoundSet";
            this.btnDSCueReviewSoundSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSCueReviewSoundSet.TabIndex = 75;
            this.btnDSCueReviewSoundSet.Text = "set";
            this.btnDSCueReviewSoundSet.UseVisualStyleBackColor = true;
            this.btnDSCueReviewSoundSet.Click += new System.EventHandler(this.btnDSCueReviewSoundSet_Click);
            // 
            // btnDSCueReviewSoundGet
            // 
            this.btnDSCueReviewSoundGet.Location = new System.Drawing.Point(175, 26);
            this.btnDSCueReviewSoundGet.Name = "btnDSCueReviewSoundGet";
            this.btnDSCueReviewSoundGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSCueReviewSoundGet.TabIndex = 74;
            this.btnDSCueReviewSoundGet.Text = "get";
            this.btnDSCueReviewSoundGet.UseVisualStyleBackColor = true;
            this.btnDSCueReviewSoundGet.Click += new System.EventHandler(this.btnDSCueReviewSoundGet_Click);
            // 
            // cbDeleteFilesAfterDownload
            // 
            this.cbDeleteFilesAfterDownload.AutoSize = true;
            this.cbDeleteFilesAfterDownload.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDeleteFilesAfterDownload.Checked = true;
            this.cbDeleteFilesAfterDownload.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDeleteFilesAfterDownload.Location = new System.Drawing.Point(21, 72);
            this.cbDeleteFilesAfterDownload.Name = "cbDeleteFilesAfterDownload";
            this.cbDeleteFilesAfterDownload.Size = new System.Drawing.Size(148, 17);
            this.cbDeleteFilesAfterDownload.TabIndex = 73;
            this.cbDeleteFilesAfterDownload.Text = "DeleteFilesAfterDownload";
            this.cbDeleteFilesAfterDownload.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDeleteFilesAfterDownload.UseVisualStyleBackColor = true;
            this.cbDeleteFilesAfterDownload.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbDELButtonEnabled
            // 
            this.cbDELButtonEnabled.AutoSize = true;
            this.cbDELButtonEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDELButtonEnabled.Checked = true;
            this.cbDELButtonEnabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDELButtonEnabled.Location = new System.Drawing.Point(52, 50);
            this.cbDELButtonEnabled.Name = "cbDELButtonEnabled";
            this.cbDELButtonEnabled.Size = new System.Drawing.Size(117, 17);
            this.cbDELButtonEnabled.TabIndex = 72;
            this.cbDELButtonEnabled.Text = "DELButtonEnabled";
            this.cbDELButtonEnabled.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDELButtonEnabled.UseVisualStyleBackColor = true;
            this.cbDELButtonEnabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // cbCueReviewSound
            // 
            this.cbCueReviewSound.AutoSize = true;
            this.cbCueReviewSound.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbCueReviewSound.Checked = true;
            this.cbCueReviewSound.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbCueReviewSound.Location = new System.Drawing.Point(57, 28);
            this.cbCueReviewSound.Name = "cbCueReviewSound";
            this.cbCueReviewSound.Size = new System.Drawing.Size(112, 17);
            this.cbCueReviewSound.TabIndex = 71;
            this.cbCueReviewSound.Text = "CueReviewSound";
            this.cbCueReviewSound.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbCueReviewSound.UseVisualStyleBackColor = true;
            this.cbCueReviewSound.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSAppendModeSet
            // 
            this.btnDSAppendModeSet.Enabled = false;
            this.btnDSAppendModeSet.Location = new System.Drawing.Point(212, 4);
            this.btnDSAppendModeSet.Name = "btnDSAppendModeSet";
            this.btnDSAppendModeSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSAppendModeSet.TabIndex = 70;
            this.btnDSAppendModeSet.Text = "set";
            this.btnDSAppendModeSet.UseVisualStyleBackColor = true;
            this.btnDSAppendModeSet.Click += new System.EventHandler(this.btnDSAppendModeSet_Click);
            // 
            // btnDSAppendModeGet
            // 
            this.btnDSAppendModeGet.Location = new System.Drawing.Point(175, 4);
            this.btnDSAppendModeGet.Name = "btnDSAppendModeGet";
            this.btnDSAppendModeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSAppendModeGet.TabIndex = 69;
            this.btnDSAppendModeGet.Text = "get";
            this.btnDSAppendModeGet.UseVisualStyleBackColor = true;
            this.btnDSAppendModeGet.Click += new System.EventHandler(this.btnDSAppendModeGet_Click);
            // 
            // cbAppendMode
            // 
            this.cbAppendMode.AutoSize = true;
            this.cbAppendMode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbAppendMode.Checked = true;
            this.cbAppendMode.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbAppendMode.Location = new System.Drawing.Point(79, 6);
            this.cbAppendMode.Name = "cbAppendMode";
            this.cbAppendMode.Size = new System.Drawing.Size(90, 17);
            this.cbAppendMode.TabIndex = 68;
            this.cbAppendMode.Text = "AppendMode";
            this.cbAppendMode.UseVisualStyleBackColor = true;
            this.cbAppendMode.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // deviceSettings3TabPage
            // 
            this.deviceSettings3TabPage.Controls.Add(this.numSliderJumpBackTime);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSSliderJumpBackTimeSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSSliderJumpBackTimeGet);
            this.deviceSettings3TabPage.Controls.Add(this.label82);
            this.deviceSettings3TabPage.Controls.Add(this.numUserStringCount);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSUserStringCountSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSUserStringCountGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSLockTimeSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnLockTimeGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSKeywordUsageCountGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSKeywordContentCountGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSDownloadFilterSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSDownloadFilterGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSDownloadModeSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSDownloadModeGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSFileCounterSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSFileCounterGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSDisplayKeywordsSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSDisplayKeywordsGet);
            this.deviceSettings3TabPage.Controls.Add(this.numLockTime);
            this.deviceSettings3TabPage.Controls.Add(this.numKeywordUsageCount);
            this.deviceSettings3TabPage.Controls.Add(this.numKeywordContentCount);
            this.deviceSettings3TabPage.Controls.Add(this.numDownloadFilter);
            this.deviceSettings3TabPage.Controls.Add(this.numDownloadMode);
            this.deviceSettings3TabPage.Controls.Add(this.numFileCounter);
            this.deviceSettings3TabPage.Controls.Add(this.numDisplayKeywords);
            this.deviceSettings3TabPage.Controls.Add(this.label43);
            this.deviceSettings3TabPage.Controls.Add(this.label42);
            this.deviceSettings3TabPage.Controls.Add(this.label41);
            this.deviceSettings3TabPage.Controls.Add(this.label40);
            this.deviceSettings3TabPage.Controls.Add(this.label39);
            this.deviceSettings3TabPage.Controls.Add(this.label38);
            this.deviceSettings3TabPage.Controls.Add(this.label37);
            this.deviceSettings3TabPage.Controls.Add(this.label36);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSMACAddressGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSKeyword1StringSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSKeyword1StringGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSFirmwareVersionGet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSFileNamePrefixStringSet);
            this.deviceSettings3TabPage.Controls.Add(this.btnDSFileNamePrefixStringGet);
            this.deviceSettings3TabPage.Controls.Add(this.textDSMACAddress);
            this.deviceSettings3TabPage.Controls.Add(this.textKeyword1String);
            this.deviceSettings3TabPage.Controls.Add(this.textDSFirmwareVersion);
            this.deviceSettings3TabPage.Controls.Add(this.textFileNamePrefixString);
            this.deviceSettings3TabPage.Controls.Add(this.label17);
            this.deviceSettings3TabPage.Controls.Add(this.label16);
            this.deviceSettings3TabPage.Controls.Add(this.label15);
            this.deviceSettings3TabPage.Controls.Add(this.label14);
            this.deviceSettings3TabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettings3TabPage.Name = "deviceSettings3TabPage";
            this.deviceSettings3TabPage.Padding = new System.Windows.Forms.Padding(3);
            this.deviceSettings3TabPage.Size = new System.Drawing.Size(704, 284);
            this.deviceSettings3TabPage.TabIndex = 2;
            this.deviceSettings3TabPage.Text = "Settings 3 ";
            this.deviceSettings3TabPage.UseVisualStyleBackColor = true;
            // 
            // numSliderJumpBackTime
            // 
            this.numSliderJumpBackTime.Location = new System.Drawing.Point(457, 191);
            this.numSliderJumpBackTime.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numSliderJumpBackTime.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numSliderJumpBackTime.Name = "numSliderJumpBackTime";
            this.numSliderJumpBackTime.Size = new System.Drawing.Size(50, 20);
            this.numSliderJumpBackTime.TabIndex = 113;
            this.numSliderJumpBackTime.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // btnDSSliderJumpBackTimeSet
            // 
            this.btnDSSliderJumpBackTimeSet.Location = new System.Drawing.Point(554, 189);
            this.btnDSSliderJumpBackTimeSet.Name = "btnDSSliderJumpBackTimeSet";
            this.btnDSSliderJumpBackTimeSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSSliderJumpBackTimeSet.TabIndex = 112;
            this.btnDSSliderJumpBackTimeSet.Text = "set";
            this.btnDSSliderJumpBackTimeSet.UseVisualStyleBackColor = true;
            this.btnDSSliderJumpBackTimeSet.Click += new System.EventHandler(this.btnDSSliderJumpBackTimeSet_Click);
            // 
            // btnDSSliderJumpBackTimeGet
            // 
            this.btnDSSliderJumpBackTimeGet.Location = new System.Drawing.Point(516, 189);
            this.btnDSSliderJumpBackTimeGet.Name = "btnDSSliderJumpBackTimeGet";
            this.btnDSSliderJumpBackTimeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSSliderJumpBackTimeGet.TabIndex = 111;
            this.btnDSSliderJumpBackTimeGet.Text = "get";
            this.btnDSSliderJumpBackTimeGet.UseVisualStyleBackColor = true;
            this.btnDSSliderJumpBackTimeGet.Click += new System.EventHandler(this.btnDSSliderJumpBackTimeGet_Click);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(347, 193);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(106, 13);
            this.label82.TabIndex = 110;
            this.label82.Text = "SliderJumpBackTime";
            // 
            // numUserStringCount
            // 
            this.numUserStringCount.Location = new System.Drawing.Point(457, 168);
            this.numUserStringCount.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numUserStringCount.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numUserStringCount.Name = "numUserStringCount";
            this.numUserStringCount.Size = new System.Drawing.Size(50, 20);
            this.numUserStringCount.TabIndex = 109;
            this.numUserStringCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // btnDSUserStringCountSet
            // 
            this.btnDSUserStringCountSet.Location = new System.Drawing.Point(554, 166);
            this.btnDSUserStringCountSet.Name = "btnDSUserStringCountSet";
            this.btnDSUserStringCountSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSUserStringCountSet.TabIndex = 108;
            this.btnDSUserStringCountSet.Text = "set";
            this.btnDSUserStringCountSet.UseVisualStyleBackColor = true;
            this.btnDSUserStringCountSet.Click += new System.EventHandler(this.btnDSUserStringCountSet_Click);
            // 
            // btnDSUserStringCountGet
            // 
            this.btnDSUserStringCountGet.Location = new System.Drawing.Point(516, 166);
            this.btnDSUserStringCountGet.Name = "btnDSUserStringCountGet";
            this.btnDSUserStringCountGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSUserStringCountGet.TabIndex = 107;
            this.btnDSUserStringCountGet.Text = "get";
            this.btnDSUserStringCountGet.UseVisualStyleBackColor = true;
            this.btnDSUserStringCountGet.Click += new System.EventHandler(this.btnDSUserStringCountGet_Click);
            // 
            // btnDSLockTimeSet
            // 
            this.btnDSLockTimeSet.Location = new System.Drawing.Point(554, 144);
            this.btnDSLockTimeSet.Name = "btnDSLockTimeSet";
            this.btnDSLockTimeSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSLockTimeSet.TabIndex = 106;
            this.btnDSLockTimeSet.Text = "set";
            this.btnDSLockTimeSet.UseVisualStyleBackColor = true;
            this.btnDSLockTimeSet.Click += new System.EventHandler(this.btnDSLockTimeSet_Click);
            // 
            // btnLockTimeGet
            // 
            this.btnLockTimeGet.Location = new System.Drawing.Point(516, 144);
            this.btnLockTimeGet.Name = "btnLockTimeGet";
            this.btnLockTimeGet.Size = new System.Drawing.Size(31, 21);
            this.btnLockTimeGet.TabIndex = 105;
            this.btnLockTimeGet.Text = "get";
            this.btnLockTimeGet.UseVisualStyleBackColor = true;
            this.btnLockTimeGet.Click += new System.EventHandler(this.btnLockTimeGet_Click);
            // 
            // btnDSKeywordUsageCountGet
            // 
            this.btnDSKeywordUsageCountGet.Location = new System.Drawing.Point(516, 122);
            this.btnDSKeywordUsageCountGet.Name = "btnDSKeywordUsageCountGet";
            this.btnDSKeywordUsageCountGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSKeywordUsageCountGet.TabIndex = 103;
            this.btnDSKeywordUsageCountGet.Text = "get";
            this.btnDSKeywordUsageCountGet.UseVisualStyleBackColor = true;
            this.btnDSKeywordUsageCountGet.Click += new System.EventHandler(this.btnDSKeywordUsageCountGet_Click);
            // 
            // btnDSKeywordContentCountGet
            // 
            this.btnDSKeywordContentCountGet.Location = new System.Drawing.Point(516, 100);
            this.btnDSKeywordContentCountGet.Name = "btnDSKeywordContentCountGet";
            this.btnDSKeywordContentCountGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSKeywordContentCountGet.TabIndex = 101;
            this.btnDSKeywordContentCountGet.Text = "get";
            this.btnDSKeywordContentCountGet.UseVisualStyleBackColor = true;
            this.btnDSKeywordContentCountGet.Click += new System.EventHandler(this.btnDSKeywordContentCountGet_Click);
            // 
            // btnDSDownloadFilterSet
            // 
            this.btnDSDownloadFilterSet.Location = new System.Drawing.Point(554, 79);
            this.btnDSDownloadFilterSet.Name = "btnDSDownloadFilterSet";
            this.btnDSDownloadFilterSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDownloadFilterSet.TabIndex = 100;
            this.btnDSDownloadFilterSet.Text = "set";
            this.btnDSDownloadFilterSet.UseVisualStyleBackColor = true;
            this.btnDSDownloadFilterSet.Click += new System.EventHandler(this.btnDSDownloadFilterSet_Click);
            // 
            // btnDSDownloadFilterGet
            // 
            this.btnDSDownloadFilterGet.Location = new System.Drawing.Point(516, 79);
            this.btnDSDownloadFilterGet.Name = "btnDSDownloadFilterGet";
            this.btnDSDownloadFilterGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDownloadFilterGet.TabIndex = 99;
            this.btnDSDownloadFilterGet.Text = "get";
            this.btnDSDownloadFilterGet.UseVisualStyleBackColor = true;
            this.btnDSDownloadFilterGet.Click += new System.EventHandler(this.btnDSDownloadFilterGet_Click);
            // 
            // btnDSDownloadModeSet
            // 
            this.btnDSDownloadModeSet.Location = new System.Drawing.Point(554, 57);
            this.btnDSDownloadModeSet.Name = "btnDSDownloadModeSet";
            this.btnDSDownloadModeSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDownloadModeSet.TabIndex = 98;
            this.btnDSDownloadModeSet.Text = "set";
            this.btnDSDownloadModeSet.UseVisualStyleBackColor = true;
            this.btnDSDownloadModeSet.Click += new System.EventHandler(this.btnDSDownloadModeSet_Click);
            // 
            // btnDSDownloadModeGet
            // 
            this.btnDSDownloadModeGet.Location = new System.Drawing.Point(516, 57);
            this.btnDSDownloadModeGet.Name = "btnDSDownloadModeGet";
            this.btnDSDownloadModeGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDownloadModeGet.TabIndex = 97;
            this.btnDSDownloadModeGet.Text = "get";
            this.btnDSDownloadModeGet.UseVisualStyleBackColor = true;
            this.btnDSDownloadModeGet.Click += new System.EventHandler(this.btnDSDownloadModeGet_Click);
            // 
            // btnDSFileCounterSet
            // 
            this.btnDSFileCounterSet.Location = new System.Drawing.Point(554, 35);
            this.btnDSFileCounterSet.Name = "btnDSFileCounterSet";
            this.btnDSFileCounterSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFileCounterSet.TabIndex = 96;
            this.btnDSFileCounterSet.Text = "set";
            this.btnDSFileCounterSet.UseVisualStyleBackColor = true;
            this.btnDSFileCounterSet.Click += new System.EventHandler(this.btnDSFileCounterSet_Click);
            // 
            // btnDSFileCounterGet
            // 
            this.btnDSFileCounterGet.Location = new System.Drawing.Point(516, 35);
            this.btnDSFileCounterGet.Name = "btnDSFileCounterGet";
            this.btnDSFileCounterGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFileCounterGet.TabIndex = 95;
            this.btnDSFileCounterGet.Text = "get";
            this.btnDSFileCounterGet.UseVisualStyleBackColor = true;
            this.btnDSFileCounterGet.Click += new System.EventHandler(this.btnDSFileCounterGet_Click);
            // 
            // btnDSDisplayKeywordsSet
            // 
            this.btnDSDisplayKeywordsSet.Location = new System.Drawing.Point(554, 13);
            this.btnDSDisplayKeywordsSet.Name = "btnDSDisplayKeywordsSet";
            this.btnDSDisplayKeywordsSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDisplayKeywordsSet.TabIndex = 94;
            this.btnDSDisplayKeywordsSet.Text = "set";
            this.btnDSDisplayKeywordsSet.UseVisualStyleBackColor = true;
            this.btnDSDisplayKeywordsSet.Click += new System.EventHandler(this.btnDSDisplayKeywordsSet_Click);
            // 
            // btnDSDisplayKeywordsGet
            // 
            this.btnDSDisplayKeywordsGet.Location = new System.Drawing.Point(516, 13);
            this.btnDSDisplayKeywordsGet.Name = "btnDSDisplayKeywordsGet";
            this.btnDSDisplayKeywordsGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSDisplayKeywordsGet.TabIndex = 93;
            this.btnDSDisplayKeywordsGet.Text = "get";
            this.btnDSDisplayKeywordsGet.UseVisualStyleBackColor = true;
            this.btnDSDisplayKeywordsGet.Click += new System.EventHandler(this.btnDSDisplayKeywordsGet_Click);
            // 
            // numLockTime
            // 
            this.numLockTime.Location = new System.Drawing.Point(457, 148);
            this.numLockTime.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numLockTime.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numLockTime.Name = "numLockTime";
            this.numLockTime.Size = new System.Drawing.Size(50, 20);
            this.numLockTime.TabIndex = 92;
            this.numLockTime.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numKeywordUsageCount
            // 
            this.numKeywordUsageCount.Location = new System.Drawing.Point(457, 124);
            this.numKeywordUsageCount.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numKeywordUsageCount.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numKeywordUsageCount.Name = "numKeywordUsageCount";
            this.numKeywordUsageCount.Size = new System.Drawing.Size(50, 20);
            this.numKeywordUsageCount.TabIndex = 91;
            this.numKeywordUsageCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numKeywordContentCount
            // 
            this.numKeywordContentCount.Location = new System.Drawing.Point(457, 102);
            this.numKeywordContentCount.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numKeywordContentCount.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numKeywordContentCount.Name = "numKeywordContentCount";
            this.numKeywordContentCount.Size = new System.Drawing.Size(50, 20);
            this.numKeywordContentCount.TabIndex = 90;
            this.numKeywordContentCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numDownloadFilter
            // 
            this.numDownloadFilter.Location = new System.Drawing.Point(457, 79);
            this.numDownloadFilter.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numDownloadFilter.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numDownloadFilter.Name = "numDownloadFilter";
            this.numDownloadFilter.Size = new System.Drawing.Size(50, 20);
            this.numDownloadFilter.TabIndex = 89;
            this.numDownloadFilter.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numDownloadMode
            // 
            this.numDownloadMode.Location = new System.Drawing.Point(457, 57);
            this.numDownloadMode.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numDownloadMode.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numDownloadMode.Name = "numDownloadMode";
            this.numDownloadMode.Size = new System.Drawing.Size(50, 20);
            this.numDownloadMode.TabIndex = 88;
            this.numDownloadMode.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numFileCounter
            // 
            this.numFileCounter.Location = new System.Drawing.Point(457, 35);
            this.numFileCounter.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numFileCounter.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numFileCounter.Name = "numFileCounter";
            this.numFileCounter.Size = new System.Drawing.Size(50, 20);
            this.numFileCounter.TabIndex = 87;
            this.numFileCounter.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // numDisplayKeywords
            // 
            this.numDisplayKeywords.Location = new System.Drawing.Point(457, 13);
            this.numDisplayKeywords.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numDisplayKeywords.Minimum = new decimal(new int[] {
            1000000,
            0,
            0,
            -2147483648});
            this.numDisplayKeywords.Name = "numDisplayKeywords";
            this.numDisplayKeywords.Size = new System.Drawing.Size(50, 20);
            this.numDisplayKeywords.TabIndex = 86;
            this.numDisplayKeywords.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(369, 170);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(84, 13);
            this.label43.TabIndex = 85;
            this.label43.Text = "UserStringCount";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(399, 148);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(54, 13);
            this.label42.TabIndex = 84;
            this.label42.Text = "LockTime";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(346, 126);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(107, 13);
            this.label41.TabIndex = 83;
            this.label41.Text = "KeywordUsageCount";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(340, 104);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(113, 13);
            this.label40.TabIndex = 82;
            this.label40.Text = "KeywordContentCount";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(376, 83);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(77, 13);
            this.label39.TabIndex = 81;
            this.label39.Text = "DownloadFilter";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(371, 61);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(82, 13);
            this.label38.TabIndex = 80;
            this.label38.Text = "DownloadMode";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(393, 39);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 13);
            this.label37.TabIndex = 79;
            this.label37.Text = "FileCounter";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(366, 17);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(87, 13);
            this.label36.TabIndex = 78;
            this.label36.Text = "DisplayKeywords";
            // 
            // btnDSMACAddressGet
            // 
            this.btnDSMACAddressGet.Location = new System.Drawing.Point(264, 79);
            this.btnDSMACAddressGet.Name = "btnDSMACAddressGet";
            this.btnDSMACAddressGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSMACAddressGet.TabIndex = 77;
            this.btnDSMACAddressGet.Text = "get";
            this.btnDSMACAddressGet.UseVisualStyleBackColor = true;
            this.btnDSMACAddressGet.Click += new System.EventHandler(this.btnDSMACAddressGet_Click);
            // 
            // btnDSKeyword1StringSet
            // 
            this.btnDSKeyword1StringSet.Location = new System.Drawing.Point(301, 57);
            this.btnDSKeyword1StringSet.Name = "btnDSKeyword1StringSet";
            this.btnDSKeyword1StringSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSKeyword1StringSet.TabIndex = 76;
            this.btnDSKeyword1StringSet.Text = "set";
            this.btnDSKeyword1StringSet.UseVisualStyleBackColor = true;
            this.btnDSKeyword1StringSet.Click += new System.EventHandler(this.btnDSKeyword1StringSet_Click);
            // 
            // btnDSKeyword1StringGet
            // 
            this.btnDSKeyword1StringGet.Location = new System.Drawing.Point(264, 57);
            this.btnDSKeyword1StringGet.Name = "btnDSKeyword1StringGet";
            this.btnDSKeyword1StringGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSKeyword1StringGet.TabIndex = 75;
            this.btnDSKeyword1StringGet.Text = "get";
            this.btnDSKeyword1StringGet.UseVisualStyleBackColor = true;
            this.btnDSKeyword1StringGet.Click += new System.EventHandler(this.btnDSKeyword1StringGet_Click);
            // 
            // btnDSFirmwareVersionGet
            // 
            this.btnDSFirmwareVersionGet.Location = new System.Drawing.Point(264, 35);
            this.btnDSFirmwareVersionGet.Name = "btnDSFirmwareVersionGet";
            this.btnDSFirmwareVersionGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFirmwareVersionGet.TabIndex = 73;
            this.btnDSFirmwareVersionGet.Text = "get";
            this.btnDSFirmwareVersionGet.UseVisualStyleBackColor = true;
            this.btnDSFirmwareVersionGet.Click += new System.EventHandler(this.btnDSFirmwareVersionGet_Click);
            // 
            // btnDSFileNamePrefixStringSet
            // 
            this.btnDSFileNamePrefixStringSet.Location = new System.Drawing.Point(301, 13);
            this.btnDSFileNamePrefixStringSet.Name = "btnDSFileNamePrefixStringSet";
            this.btnDSFileNamePrefixStringSet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFileNamePrefixStringSet.TabIndex = 72;
            this.btnDSFileNamePrefixStringSet.Text = "set";
            this.btnDSFileNamePrefixStringSet.UseVisualStyleBackColor = true;
            this.btnDSFileNamePrefixStringSet.Click += new System.EventHandler(this.btnDSFileNamePrefixStringSet_Click);
            // 
            // btnDSFileNamePrefixStringGet
            // 
            this.btnDSFileNamePrefixStringGet.Location = new System.Drawing.Point(264, 13);
            this.btnDSFileNamePrefixStringGet.Name = "btnDSFileNamePrefixStringGet";
            this.btnDSFileNamePrefixStringGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSFileNamePrefixStringGet.TabIndex = 71;
            this.btnDSFileNamePrefixStringGet.Text = "get";
            this.btnDSFileNamePrefixStringGet.UseVisualStyleBackColor = true;
            this.btnDSFileNamePrefixStringGet.Click += new System.EventHandler(this.btnDSFileNamePrefixStringGet_Click);
            // 
            // textDSMACAddress
            // 
            this.textDSMACAddress.Location = new System.Drawing.Point(125, 79);
            this.textDSMACAddress.Name = "textDSMACAddress";
            this.textDSMACAddress.ReadOnly = true;
            this.textDSMACAddress.Size = new System.Drawing.Size(133, 20);
            this.textDSMACAddress.TabIndex = 7;
            // 
            // textKeyword1String
            // 
            this.textKeyword1String.Location = new System.Drawing.Point(125, 57);
            this.textKeyword1String.Name = "textKeyword1String";
            this.textKeyword1String.Size = new System.Drawing.Size(133, 20);
            this.textKeyword1String.TabIndex = 6;
            // 
            // textDSFirmwareVersion
            // 
            this.textDSFirmwareVersion.Location = new System.Drawing.Point(125, 35);
            this.textDSFirmwareVersion.Name = "textDSFirmwareVersion";
            this.textDSFirmwareVersion.ReadOnly = true;
            this.textDSFirmwareVersion.Size = new System.Drawing.Size(133, 20);
            this.textDSFirmwareVersion.TabIndex = 5;
            // 
            // textFileNamePrefixString
            // 
            this.textFileNamePrefixString.Location = new System.Drawing.Point(125, 13);
            this.textFileNamePrefixString.Name = "textFileNamePrefixString";
            this.textFileNamePrefixString.Size = new System.Drawing.Size(133, 20);
            this.textFileNamePrefixString.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 83);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 13);
            this.label17.TabIndex = 3;
            this.label17.Text = "MACAddress";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(15, 61);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 13);
            this.label16.TabIndex = 2;
            this.label16.Text = "Keyword1String";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(15, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(84, 13);
            this.label15.TabIndex = 1;
            this.label15.Text = "FirmwareVersion";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 17);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(104, 13);
            this.label14.TabIndex = 0;
            this.label14.Text = "FileNamePrefixString";
            // 
            // deviceSettings4TabPage
            // 
            this.deviceSettings4TabPage.Controls.Add(this.label53);
            this.deviceSettings4TabPage.Controls.Add(this.numKeywordContentStringUsageIndex);
            this.deviceSettings4TabPage.Controls.Add(this.cmbVoiceCommandType);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSVoiceCommandTypeSet);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSVoiceCommandTypeGet);
            this.deviceSettings4TabPage.Controls.Add(this.label52);
            this.deviceSettings4TabPage.Controls.Add(this.numVoiceCommandTypeIndex);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSKeywordUsageStringSet);
            this.deviceSettings4TabPage.Controls.Add(this.btnKeywordUsageStringGet);
            this.deviceSettings4TabPage.Controls.Add(this.label51);
            this.deviceSettings4TabPage.Controls.Add(this.numKeywordUsageStringIndex);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSKeywordContentStringSet);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSKeywordContentStringGet);
            this.deviceSettings4TabPage.Controls.Add(this.label50);
            this.deviceSettings4TabPage.Controls.Add(this.numKeywordContentStringContentIndex);
            this.deviceSettings4TabPage.Controls.Add(this.textKeywordUsageString);
            this.deviceSettings4TabPage.Controls.Add(this.textKeywordContentString);
            this.deviceSettings4TabPage.Controls.Add(this.label49);
            this.deviceSettings4TabPage.Controls.Add(this.label48);
            this.deviceSettings4TabPage.Controls.Add(this.label47);
            this.deviceSettings4TabPage.Controls.Add(this.label46);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSKeywordVoiceCommandSet);
            this.deviceSettings4TabPage.Controls.Add(this.btnDSKeywordVoiceCommandGet);
            this.deviceSettings4TabPage.Controls.Add(this.numKeywordVoiceCommandIndex);
            this.deviceSettings4TabPage.Controls.Add(this.cbKeywordVoiceCommand);
            this.deviceSettings4TabPage.Controls.Add(this.label45);
            this.deviceSettings4TabPage.Controls.Add(this.btnKeywordMandatorySet);
            this.deviceSettings4TabPage.Controls.Add(this.btnKeywordMandatoryGet);
            this.deviceSettings4TabPage.Controls.Add(this.numKeywordMandatoryIndex);
            this.deviceSettings4TabPage.Controls.Add(this.cbKeywordMandatory);
            this.deviceSettings4TabPage.Controls.Add(this.label44);
            this.deviceSettings4TabPage.Controls.Add(this.btnKeywordBarcodeScanSet);
            this.deviceSettings4TabPage.Controls.Add(this.btnKeywordBarcodeScanGet);
            this.deviceSettings4TabPage.Controls.Add(this.numKeywordBarcodeScanIndex);
            this.deviceSettings4TabPage.Controls.Add(this.cbKeywordBarcodeScan);
            this.deviceSettings4TabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettings4TabPage.Name = "deviceSettings4TabPage";
            this.deviceSettings4TabPage.Padding = new System.Windows.Forms.Padding(3);
            this.deviceSettings4TabPage.Size = new System.Drawing.Size(704, 284);
            this.deviceSettings4TabPage.TabIndex = 3;
            this.deviceSettings4TabPage.Text = "Settings 4";
            this.deviceSettings4TabPage.UseVisualStyleBackColor = true;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(265, 122);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(66, 13);
            this.label53.TabIndex = 83;
            this.label53.Text = "indexUsage:";
            // 
            // numKeywordContentStringUsageIndex
            // 
            this.numKeywordContentStringUsageIndex.Location = new System.Drawing.Point(337, 118);
            this.numKeywordContentStringUsageIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numKeywordContentStringUsageIndex.Name = "numKeywordContentStringUsageIndex";
            this.numKeywordContentStringUsageIndex.Size = new System.Drawing.Size(48, 20);
            this.numKeywordContentStringUsageIndex.TabIndex = 82;
            // 
            // cmbVoiceCommandType
            // 
            this.cmbVoiceCommandType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVoiceCommandType.FormattingEnabled = true;
            this.cmbVoiceCommandType.Location = new System.Drawing.Point(45, 211);
            this.cmbVoiceCommandType.Name = "cmbVoiceCommandType";
            this.cmbVoiceCommandType.Size = new System.Drawing.Size(201, 21);
            this.cmbVoiceCommandType.TabIndex = 81;
            this.cmbVoiceCommandType.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSVoiceCommandTypeSet
            // 
            this.btnDSVoiceCommandTypeSet.Enabled = false;
            this.btnDSVoiceCommandTypeSet.Location = new System.Drawing.Point(555, 210);
            this.btnDSVoiceCommandTypeSet.Name = "btnDSVoiceCommandTypeSet";
            this.btnDSVoiceCommandTypeSet.Size = new System.Drawing.Size(143, 22);
            this.btnDSVoiceCommandTypeSet.TabIndex = 31;
            this.btnDSVoiceCommandTypeSet.Text = "set_VoiceCommandType";
            this.btnDSVoiceCommandTypeSet.UseVisualStyleBackColor = true;
            this.btnDSVoiceCommandTypeSet.Click += new System.EventHandler(this.btnDSVoiceCommandTypeSet_Click);
            // 
            // btnDSVoiceCommandTypeGet
            // 
            this.btnDSVoiceCommandTypeGet.Location = new System.Drawing.Point(394, 210);
            this.btnDSVoiceCommandTypeGet.Name = "btnDSVoiceCommandTypeGet";
            this.btnDSVoiceCommandTypeGet.Size = new System.Drawing.Size(155, 22);
            this.btnDSVoiceCommandTypeGet.TabIndex = 30;
            this.btnDSVoiceCommandTypeGet.Text = "get_VoiceCommandType";
            this.btnDSVoiceCommandTypeGet.UseVisualStyleBackColor = true;
            this.btnDSVoiceCommandTypeGet.Click += new System.EventHandler(this.btnDSVoiceCommandTypeGet_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(294, 214);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(35, 13);
            this.label52.TabIndex = 29;
            this.label52.Text = "index:";
            // 
            // numVoiceCommandTypeIndex
            // 
            this.numVoiceCommandTypeIndex.Location = new System.Drawing.Point(335, 211);
            this.numVoiceCommandTypeIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numVoiceCommandTypeIndex.Name = "numVoiceCommandTypeIndex";
            this.numVoiceCommandTypeIndex.Size = new System.Drawing.Size(48, 20);
            this.numVoiceCommandTypeIndex.TabIndex = 28;
            // 
            // btnDSKeywordUsageStringSet
            // 
            this.btnDSKeywordUsageStringSet.Location = new System.Drawing.Point(555, 156);
            this.btnDSKeywordUsageStringSet.Name = "btnDSKeywordUsageStringSet";
            this.btnDSKeywordUsageStringSet.Size = new System.Drawing.Size(143, 22);
            this.btnDSKeywordUsageStringSet.TabIndex = 27;
            this.btnDSKeywordUsageStringSet.Text = "set_KeywordUsageString";
            this.btnDSKeywordUsageStringSet.UseVisualStyleBackColor = true;
            this.btnDSKeywordUsageStringSet.Click += new System.EventHandler(this.btnDSKeywordUsageStringSet_Click);
            // 
            // btnKeywordUsageStringGet
            // 
            this.btnKeywordUsageStringGet.Location = new System.Drawing.Point(394, 156);
            this.btnKeywordUsageStringGet.Name = "btnKeywordUsageStringGet";
            this.btnKeywordUsageStringGet.Size = new System.Drawing.Size(155, 22);
            this.btnKeywordUsageStringGet.TabIndex = 26;
            this.btnKeywordUsageStringGet.Text = "get_KeywordUsageString";
            this.btnKeywordUsageStringGet.UseVisualStyleBackColor = true;
            this.btnKeywordUsageStringGet.Click += new System.EventHandler(this.btnKeywordUsageStringGet_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(296, 161);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(35, 13);
            this.label51.TabIndex = 25;
            this.label51.Text = "index:";
            // 
            // numKeywordUsageStringIndex
            // 
            this.numKeywordUsageStringIndex.Location = new System.Drawing.Point(335, 157);
            this.numKeywordUsageStringIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numKeywordUsageStringIndex.Name = "numKeywordUsageStringIndex";
            this.numKeywordUsageStringIndex.Size = new System.Drawing.Size(48, 20);
            this.numKeywordUsageStringIndex.TabIndex = 24;
            // 
            // btnDSKeywordContentStringSet
            // 
            this.btnDSKeywordContentStringSet.Location = new System.Drawing.Point(555, 106);
            this.btnDSKeywordContentStringSet.Name = "btnDSKeywordContentStringSet";
            this.btnDSKeywordContentStringSet.Size = new System.Drawing.Size(143, 22);
            this.btnDSKeywordContentStringSet.TabIndex = 23;
            this.btnDSKeywordContentStringSet.Text = "set_KeywordContentString";
            this.btnDSKeywordContentStringSet.UseVisualStyleBackColor = true;
            this.btnDSKeywordContentStringSet.Click += new System.EventHandler(this.btnDSKeywordContentStringSet_Click);
            // 
            // btnDSKeywordContentStringGet
            // 
            this.btnDSKeywordContentStringGet.Location = new System.Drawing.Point(394, 106);
            this.btnDSKeywordContentStringGet.Name = "btnDSKeywordContentStringGet";
            this.btnDSKeywordContentStringGet.Size = new System.Drawing.Size(155, 22);
            this.btnDSKeywordContentStringGet.TabIndex = 22;
            this.btnDSKeywordContentStringGet.Text = "get_KeywordContentString";
            this.btnDSKeywordContentStringGet.UseVisualStyleBackColor = true;
            this.btnDSKeywordContentStringGet.Click += new System.EventHandler(this.btnDSKeywordContentStringGet_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(259, 102);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(72, 13);
            this.label50.TabIndex = 21;
            this.label50.Text = "indexContent:";
            // 
            // numKeywordContentStringContentIndex
            // 
            this.numKeywordContentStringContentIndex.Location = new System.Drawing.Point(337, 98);
            this.numKeywordContentStringContentIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numKeywordContentStringContentIndex.Name = "numKeywordContentStringContentIndex";
            this.numKeywordContentStringContentIndex.Size = new System.Drawing.Size(48, 20);
            this.numKeywordContentStringContentIndex.TabIndex = 20;
            // 
            // textKeywordUsageString
            // 
            this.textKeywordUsageString.Location = new System.Drawing.Point(40, 157);
            this.textKeywordUsageString.Name = "textKeywordUsageString";
            this.textKeywordUsageString.Size = new System.Drawing.Size(206, 20);
            this.textKeywordUsageString.TabIndex = 19;
            // 
            // textKeywordContentString
            // 
            this.textKeywordContentString.Location = new System.Drawing.Point(45, 107);
            this.textKeywordContentString.Name = "textKeywordContentString";
            this.textKeywordContentString.Size = new System.Drawing.Size(201, 20);
            this.textKeywordContentString.TabIndex = 18;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 215);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(34, 13);
            this.label49.TabIndex = 17;
            this.label49.Text = "Value";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 161);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(34, 13);
            this.label48.TabIndex = 16;
            this.label48.Text = "Value";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(5, 111);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(34, 13);
            this.label47.TabIndex = 15;
            this.label47.Text = "Value";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(296, 65);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 13);
            this.label46.TabIndex = 14;
            this.label46.Text = "index:";
            // 
            // btnDSKeywordVoiceCommandSet
            // 
            this.btnDSKeywordVoiceCommandSet.Enabled = false;
            this.btnDSKeywordVoiceCommandSet.Location = new System.Drawing.Point(555, 60);
            this.btnDSKeywordVoiceCommandSet.Name = "btnDSKeywordVoiceCommandSet";
            this.btnDSKeywordVoiceCommandSet.Size = new System.Drawing.Size(143, 22);
            this.btnDSKeywordVoiceCommandSet.TabIndex = 13;
            this.btnDSKeywordVoiceCommandSet.Text = "set_KeywordVoiceCommand";
            this.btnDSKeywordVoiceCommandSet.UseVisualStyleBackColor = true;
            this.btnDSKeywordVoiceCommandSet.Click += new System.EventHandler(this.btnDSKeywordVoiceCommandSet_Click);
            // 
            // btnDSKeywordVoiceCommandGet
            // 
            this.btnDSKeywordVoiceCommandGet.Location = new System.Drawing.Point(394, 60);
            this.btnDSKeywordVoiceCommandGet.Name = "btnDSKeywordVoiceCommandGet";
            this.btnDSKeywordVoiceCommandGet.Size = new System.Drawing.Size(155, 22);
            this.btnDSKeywordVoiceCommandGet.TabIndex = 12;
            this.btnDSKeywordVoiceCommandGet.Text = "get_KeywordVoiceCommand";
            this.btnDSKeywordVoiceCommandGet.UseVisualStyleBackColor = true;
            this.btnDSKeywordVoiceCommandGet.Click += new System.EventHandler(this.btnDSKeywordVoiceCommandGet_Click);
            // 
            // numKeywordVoiceCommandIndex
            // 
            this.numKeywordVoiceCommandIndex.Location = new System.Drawing.Point(335, 61);
            this.numKeywordVoiceCommandIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numKeywordVoiceCommandIndex.Name = "numKeywordVoiceCommandIndex";
            this.numKeywordVoiceCommandIndex.Size = new System.Drawing.Size(48, 20);
            this.numKeywordVoiceCommandIndex.TabIndex = 11;
            // 
            // cbKeywordVoiceCommand
            // 
            this.cbKeywordVoiceCommand.AutoSize = true;
            this.cbKeywordVoiceCommand.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbKeywordVoiceCommand.Checked = true;
            this.cbKeywordVoiceCommand.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbKeywordVoiceCommand.Location = new System.Drawing.Point(149, 63);
            this.cbKeywordVoiceCommand.Name = "cbKeywordVoiceCommand";
            this.cbKeywordVoiceCommand.Size = new System.Drawing.Size(141, 17);
            this.cbKeywordVoiceCommand.TabIndex = 10;
            this.cbKeywordVoiceCommand.Text = "KeywordVoiceCommand";
            this.cbKeywordVoiceCommand.UseVisualStyleBackColor = true;
            this.cbKeywordVoiceCommand.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(296, 43);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 13);
            this.label45.TabIndex = 9;
            this.label45.Text = "index:";
            // 
            // btnKeywordMandatorySet
            // 
            this.btnKeywordMandatorySet.Enabled = false;
            this.btnKeywordMandatorySet.Location = new System.Drawing.Point(555, 38);
            this.btnKeywordMandatorySet.Name = "btnKeywordMandatorySet";
            this.btnKeywordMandatorySet.Size = new System.Drawing.Size(143, 22);
            this.btnKeywordMandatorySet.TabIndex = 8;
            this.btnKeywordMandatorySet.Text = "set_KeywordMandatory";
            this.btnKeywordMandatorySet.UseVisualStyleBackColor = true;
            this.btnKeywordMandatorySet.Click += new System.EventHandler(this.btnKeywordMandatorySet_Click);
            // 
            // btnKeywordMandatoryGet
            // 
            this.btnKeywordMandatoryGet.Location = new System.Drawing.Point(394, 38);
            this.btnKeywordMandatoryGet.Name = "btnKeywordMandatoryGet";
            this.btnKeywordMandatoryGet.Size = new System.Drawing.Size(155, 22);
            this.btnKeywordMandatoryGet.TabIndex = 7;
            this.btnKeywordMandatoryGet.Text = "get_KeywordMandatory";
            this.btnKeywordMandatoryGet.UseVisualStyleBackColor = true;
            this.btnKeywordMandatoryGet.Click += new System.EventHandler(this.btnKeywordMandatoryGet_Click);
            // 
            // numKeywordMandatoryIndex
            // 
            this.numKeywordMandatoryIndex.Location = new System.Drawing.Point(335, 39);
            this.numKeywordMandatoryIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numKeywordMandatoryIndex.Name = "numKeywordMandatoryIndex";
            this.numKeywordMandatoryIndex.Size = new System.Drawing.Size(48, 20);
            this.numKeywordMandatoryIndex.TabIndex = 6;
            // 
            // cbKeywordMandatory
            // 
            this.cbKeywordMandatory.AutoSize = true;
            this.cbKeywordMandatory.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbKeywordMandatory.Checked = true;
            this.cbKeywordMandatory.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbKeywordMandatory.Location = new System.Drawing.Point(173, 41);
            this.cbKeywordMandatory.Name = "cbKeywordMandatory";
            this.cbKeywordMandatory.Size = new System.Drawing.Size(117, 17);
            this.cbKeywordMandatory.TabIndex = 5;
            this.cbKeywordMandatory.Text = "KeywordMandatory";
            this.cbKeywordMandatory.UseVisualStyleBackColor = true;
            this.cbKeywordMandatory.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(296, 21);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 13);
            this.label44.TabIndex = 4;
            this.label44.Text = "index:";
            // 
            // btnKeywordBarcodeScanSet
            // 
            this.btnKeywordBarcodeScanSet.Enabled = false;
            this.btnKeywordBarcodeScanSet.Location = new System.Drawing.Point(555, 16);
            this.btnKeywordBarcodeScanSet.Name = "btnKeywordBarcodeScanSet";
            this.btnKeywordBarcodeScanSet.Size = new System.Drawing.Size(143, 22);
            this.btnKeywordBarcodeScanSet.TabIndex = 3;
            this.btnKeywordBarcodeScanSet.Text = "set_KeywordBarcodeScan";
            this.btnKeywordBarcodeScanSet.UseVisualStyleBackColor = true;
            this.btnKeywordBarcodeScanSet.Click += new System.EventHandler(this.btnKeywordBarcodeScanSet_Click);
            // 
            // btnKeywordBarcodeScanGet
            // 
            this.btnKeywordBarcodeScanGet.Location = new System.Drawing.Point(394, 16);
            this.btnKeywordBarcodeScanGet.Name = "btnKeywordBarcodeScanGet";
            this.btnKeywordBarcodeScanGet.Size = new System.Drawing.Size(155, 22);
            this.btnKeywordBarcodeScanGet.TabIndex = 2;
            this.btnKeywordBarcodeScanGet.Text = "get_KeywordBarcodeScan";
            this.btnKeywordBarcodeScanGet.UseVisualStyleBackColor = true;
            this.btnKeywordBarcodeScanGet.Click += new System.EventHandler(this.btnKeywordBarcodeScanGet_Click);
            // 
            // numKeywordBarcodeScanIndex
            // 
            this.numKeywordBarcodeScanIndex.Location = new System.Drawing.Point(335, 17);
            this.numKeywordBarcodeScanIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numKeywordBarcodeScanIndex.Name = "numKeywordBarcodeScanIndex";
            this.numKeywordBarcodeScanIndex.Size = new System.Drawing.Size(48, 20);
            this.numKeywordBarcodeScanIndex.TabIndex = 1;
            // 
            // cbKeywordBarcodeScan
            // 
            this.cbKeywordBarcodeScan.AutoSize = true;
            this.cbKeywordBarcodeScan.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbKeywordBarcodeScan.Checked = true;
            this.cbKeywordBarcodeScan.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbKeywordBarcodeScan.Location = new System.Drawing.Point(158, 19);
            this.cbKeywordBarcodeScan.Name = "cbKeywordBarcodeScan";
            this.cbKeywordBarcodeScan.Size = new System.Drawing.Size(132, 17);
            this.cbKeywordBarcodeScan.TabIndex = 0;
            this.cbKeywordBarcodeScan.Text = "KeywordBarcodeScan";
            this.cbKeywordBarcodeScan.UseVisualStyleBackColor = true;
            this.cbKeywordBarcodeScan.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // deviceSettings5TabPage
            // 
            this.deviceSettings5TabPage.Controls.Add(this.IsAuthorPinListUsed_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.MinusButtonEnabled_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.PlusButtonEnabled_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.IsAuthorPinListUsed_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.MinusButtonEnabled_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.PlusButtonEnabled_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.IsAuthorPinListUsedCheck);
            this.deviceSettings5TabPage.Controls.Add(this.MinusButtonEnabledCheck);
            this.deviceSettings5TabPage.Controls.Add(this.PlusButtonEnabledCheck);
            this.deviceSettings5TabPage.Controls.Add(this.Backlight_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.Backlight_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.label90);
            this.deviceSettings5TabPage.Controls.Add(this.BacklightCombo);
            this.deviceSettings5TabPage.Controls.Add(this.label85);
            this.deviceSettings5TabPage.Controls.Add(this.KeywordDisplayAreaStringsIndexNum);
            this.deviceSettings5TabPage.Controls.Add(this.SmartButtonConfiguration_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.FootpedalMode_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.SmartButtonConfiguration_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.FootpedalMode_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.label89);
            this.deviceSettings5TabPage.Controls.Add(this.label88);
            this.deviceSettings5TabPage.Controls.Add(this.label87);
            this.deviceSettings5TabPage.Controls.Add(this.label84);
            this.deviceSettings5TabPage.Controls.Add(this.SmartButtonConfiguration_RecordingStateCombo);
            this.deviceSettings5TabPage.Controls.Add(this.SmartButtonConfiguration_ButtonIndexCombo);
            this.deviceSettings5TabPage.Controls.Add(this.SmartButtonConfigurationCombo);
            this.deviceSettings5TabPage.Controls.Add(this.FootpedalModeCombo);
            this.deviceSettings5TabPage.Controls.Add(this.KeywordDisplayAreaStrings_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.KeywordDisplayAreaStrings_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.EditMode_SetButton);
            this.deviceSettings5TabPage.Controls.Add(this.EditMode_GetButton);
            this.deviceSettings5TabPage.Controls.Add(this.label86);
            this.deviceSettings5TabPage.Controls.Add(this.label83);
            this.deviceSettings5TabPage.Controls.Add(this.KeywordDisplayAreaStringsCombo);
            this.deviceSettings5TabPage.Controls.Add(this.EditModeCombo);
            this.deviceSettings5TabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettings5TabPage.Name = "deviceSettings5TabPage";
            this.deviceSettings5TabPage.Size = new System.Drawing.Size(704, 284);
            this.deviceSettings5TabPage.TabIndex = 4;
            this.deviceSettings5TabPage.Text = "Settings 5";
            this.deviceSettings5TabPage.UseVisualStyleBackColor = true;
            // 
            // IsAuthorPinListUsed_SetButton
            // 
            this.IsAuthorPinListUsed_SetButton.Enabled = false;
            this.IsAuthorPinListUsed_SetButton.Location = new System.Drawing.Point(662, 226);
            this.IsAuthorPinListUsed_SetButton.Name = "IsAuthorPinListUsed_SetButton";
            this.IsAuthorPinListUsed_SetButton.Size = new System.Drawing.Size(35, 21);
            this.IsAuthorPinListUsed_SetButton.TabIndex = 34;
            this.IsAuthorPinListUsed_SetButton.Text = "set";
            this.IsAuthorPinListUsed_SetButton.UseVisualStyleBackColor = true;
            this.IsAuthorPinListUsed_SetButton.Click += new System.EventHandler(this.IsAuthorPinListUsed_SetButton_Click);
            // 
            // MinusButtonEnabled_SetButton
            // 
            this.MinusButtonEnabled_SetButton.Enabled = false;
            this.MinusButtonEnabled_SetButton.Location = new System.Drawing.Point(662, 199);
            this.MinusButtonEnabled_SetButton.Name = "MinusButtonEnabled_SetButton";
            this.MinusButtonEnabled_SetButton.Size = new System.Drawing.Size(35, 21);
            this.MinusButtonEnabled_SetButton.TabIndex = 31;
            this.MinusButtonEnabled_SetButton.Text = "set";
            this.MinusButtonEnabled_SetButton.UseVisualStyleBackColor = true;
            this.MinusButtonEnabled_SetButton.Click += new System.EventHandler(this.MinusButtonEnabled_SetButton_Click);
            // 
            // PlusButtonEnabled_SetButton
            // 
            this.PlusButtonEnabled_SetButton.Enabled = false;
            this.PlusButtonEnabled_SetButton.Location = new System.Drawing.Point(662, 172);
            this.PlusButtonEnabled_SetButton.Name = "PlusButtonEnabled_SetButton";
            this.PlusButtonEnabled_SetButton.Size = new System.Drawing.Size(35, 21);
            this.PlusButtonEnabled_SetButton.TabIndex = 28;
            this.PlusButtonEnabled_SetButton.Text = "set";
            this.PlusButtonEnabled_SetButton.UseVisualStyleBackColor = true;
            this.PlusButtonEnabled_SetButton.Click += new System.EventHandler(this.PlusButtonEnabled_SetButton_Click);
            // 
            // IsAuthorPinListUsed_GetButton
            // 
            this.IsAuthorPinListUsed_GetButton.Location = new System.Drawing.Point(625, 226);
            this.IsAuthorPinListUsed_GetButton.Name = "IsAuthorPinListUsed_GetButton";
            this.IsAuthorPinListUsed_GetButton.Size = new System.Drawing.Size(31, 21);
            this.IsAuthorPinListUsed_GetButton.TabIndex = 33;
            this.IsAuthorPinListUsed_GetButton.Text = "get";
            this.IsAuthorPinListUsed_GetButton.UseVisualStyleBackColor = true;
            this.IsAuthorPinListUsed_GetButton.Click += new System.EventHandler(this.IsAuthorPinListUsed_GetButton_Click);
            // 
            // MinusButtonEnabled_GetButton
            // 
            this.MinusButtonEnabled_GetButton.Location = new System.Drawing.Point(625, 199);
            this.MinusButtonEnabled_GetButton.Name = "MinusButtonEnabled_GetButton";
            this.MinusButtonEnabled_GetButton.Size = new System.Drawing.Size(31, 21);
            this.MinusButtonEnabled_GetButton.TabIndex = 30;
            this.MinusButtonEnabled_GetButton.Text = "get";
            this.MinusButtonEnabled_GetButton.UseVisualStyleBackColor = true;
            this.MinusButtonEnabled_GetButton.Click += new System.EventHandler(this.MinusButtonEnabled_GetButton_Click);
            // 
            // PlusButtonEnabled_GetButton
            // 
            this.PlusButtonEnabled_GetButton.Location = new System.Drawing.Point(625, 172);
            this.PlusButtonEnabled_GetButton.Name = "PlusButtonEnabled_GetButton";
            this.PlusButtonEnabled_GetButton.Size = new System.Drawing.Size(31, 21);
            this.PlusButtonEnabled_GetButton.TabIndex = 27;
            this.PlusButtonEnabled_GetButton.Text = "get";
            this.PlusButtonEnabled_GetButton.UseVisualStyleBackColor = true;
            this.PlusButtonEnabled_GetButton.Click += new System.EventHandler(this.PlusButtonEnabled_GetButton_Click);
            // 
            // IsAuthorPinListUsedCheck
            // 
            this.IsAuthorPinListUsedCheck.AutoSize = true;
            this.IsAuthorPinListUsedCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.IsAuthorPinListUsedCheck.Checked = true;
            this.IsAuthorPinListUsedCheck.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.IsAuthorPinListUsedCheck.Location = new System.Drawing.Point(495, 229);
            this.IsAuthorPinListUsedCheck.Name = "IsAuthorPinListUsedCheck";
            this.IsAuthorPinListUsedCheck.Size = new System.Drawing.Size(121, 17);
            this.IsAuthorPinListUsedCheck.TabIndex = 32;
            this.IsAuthorPinListUsedCheck.Text = "IsAuthorPinListUsed";
            this.IsAuthorPinListUsedCheck.UseVisualStyleBackColor = true;
            this.IsAuthorPinListUsedCheck.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // MinusButtonEnabledCheck
            // 
            this.MinusButtonEnabledCheck.AutoSize = true;
            this.MinusButtonEnabledCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.MinusButtonEnabledCheck.Checked = true;
            this.MinusButtonEnabledCheck.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.MinusButtonEnabledCheck.Location = new System.Drawing.Point(492, 202);
            this.MinusButtonEnabledCheck.Name = "MinusButtonEnabledCheck";
            this.MinusButtonEnabledCheck.Size = new System.Drawing.Size(124, 17);
            this.MinusButtonEnabledCheck.TabIndex = 29;
            this.MinusButtonEnabledCheck.Text = "MinusButtonEnabled";
            this.MinusButtonEnabledCheck.UseVisualStyleBackColor = true;
            this.MinusButtonEnabledCheck.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // PlusButtonEnabledCheck
            // 
            this.PlusButtonEnabledCheck.AutoSize = true;
            this.PlusButtonEnabledCheck.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PlusButtonEnabledCheck.Checked = true;
            this.PlusButtonEnabledCheck.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.PlusButtonEnabledCheck.Location = new System.Drawing.Point(500, 175);
            this.PlusButtonEnabledCheck.Name = "PlusButtonEnabledCheck";
            this.PlusButtonEnabledCheck.Size = new System.Drawing.Size(116, 17);
            this.PlusButtonEnabledCheck.TabIndex = 26;
            this.PlusButtonEnabledCheck.Text = "PlusButtonEnabled";
            this.PlusButtonEnabledCheck.UseVisualStyleBackColor = true;
            this.PlusButtonEnabledCheck.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // Backlight_SetButton
            // 
            this.Backlight_SetButton.Enabled = false;
            this.Backlight_SetButton.Location = new System.Drawing.Point(662, 145);
            this.Backlight_SetButton.Name = "Backlight_SetButton";
            this.Backlight_SetButton.Size = new System.Drawing.Size(35, 21);
            this.Backlight_SetButton.TabIndex = 25;
            this.Backlight_SetButton.Text = "set";
            this.Backlight_SetButton.UseVisualStyleBackColor = true;
            this.Backlight_SetButton.Click += new System.EventHandler(this.Backlight_SetButton_Click);
            // 
            // Backlight_GetButton
            // 
            this.Backlight_GetButton.Location = new System.Drawing.Point(625, 144);
            this.Backlight_GetButton.Name = "Backlight_GetButton";
            this.Backlight_GetButton.Size = new System.Drawing.Size(31, 21);
            this.Backlight_GetButton.TabIndex = 24;
            this.Backlight_GetButton.Text = "get";
            this.Backlight_GetButton.UseVisualStyleBackColor = true;
            this.Backlight_GetButton.Click += new System.EventHandler(this.Backlight_GetButton_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(4, 148);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(51, 13);
            this.label90.TabIndex = 22;
            this.label90.Text = "Backlight";
            // 
            // BacklightCombo
            // 
            this.BacklightCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.BacklightCombo.FormattingEnabled = true;
            this.BacklightCombo.Location = new System.Drawing.Point(244, 145);
            this.BacklightCombo.Name = "BacklightCombo";
            this.BacklightCombo.Size = new System.Drawing.Size(375, 21);
            this.BacklightCombo.TabIndex = 23;
            this.BacklightCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(149, 14);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(35, 13);
            this.label85.TabIndex = 1;
            this.label85.Text = "index:";
            // 
            // KeywordDisplayAreaStringsIndexNum
            // 
            this.KeywordDisplayAreaStringsIndexNum.Location = new System.Drawing.Point(190, 12);
            this.KeywordDisplayAreaStringsIndexNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.KeywordDisplayAreaStringsIndexNum.Name = "KeywordDisplayAreaStringsIndexNum";
            this.KeywordDisplayAreaStringsIndexNum.Size = new System.Drawing.Size(48, 20);
            this.KeywordDisplayAreaStringsIndexNum.TabIndex = 2;
            // 
            // SmartButtonConfiguration_SetButton
            // 
            this.SmartButtonConfiguration_SetButton.Enabled = false;
            this.SmartButtonConfiguration_SetButton.Location = new System.Drawing.Point(663, 104);
            this.SmartButtonConfiguration_SetButton.Name = "SmartButtonConfiguration_SetButton";
            this.SmartButtonConfiguration_SetButton.Size = new System.Drawing.Size(35, 21);
            this.SmartButtonConfiguration_SetButton.TabIndex = 21;
            this.SmartButtonConfiguration_SetButton.Text = "set";
            this.SmartButtonConfiguration_SetButton.UseVisualStyleBackColor = true;
            this.SmartButtonConfiguration_SetButton.Click += new System.EventHandler(this.SmartButtonConfiguration_SetButton_Click);
            // 
            // FootpedalMode_SetButton
            // 
            this.FootpedalMode_SetButton.Enabled = false;
            this.FootpedalMode_SetButton.Location = new System.Drawing.Point(662, 64);
            this.FootpedalMode_SetButton.Name = "FootpedalMode_SetButton";
            this.FootpedalMode_SetButton.Size = new System.Drawing.Size(35, 21);
            this.FootpedalMode_SetButton.TabIndex = 13;
            this.FootpedalMode_SetButton.Text = "set";
            this.FootpedalMode_SetButton.UseVisualStyleBackColor = true;
            this.FootpedalMode_SetButton.Click += new System.EventHandler(this.FootpedalMode_SetButton_Click);
            // 
            // SmartButtonConfiguration_GetButton
            // 
            this.SmartButtonConfiguration_GetButton.Location = new System.Drawing.Point(625, 104);
            this.SmartButtonConfiguration_GetButton.Name = "SmartButtonConfiguration_GetButton";
            this.SmartButtonConfiguration_GetButton.Size = new System.Drawing.Size(31, 21);
            this.SmartButtonConfiguration_GetButton.TabIndex = 20;
            this.SmartButtonConfiguration_GetButton.Text = "get";
            this.SmartButtonConfiguration_GetButton.UseVisualStyleBackColor = true;
            this.SmartButtonConfiguration_GetButton.Click += new System.EventHandler(this.SmartButtonConfiguration_GetButton_Click);
            // 
            // FootpedalMode_GetButton
            // 
            this.FootpedalMode_GetButton.Location = new System.Drawing.Point(625, 63);
            this.FootpedalMode_GetButton.Name = "FootpedalMode_GetButton";
            this.FootpedalMode_GetButton.Size = new System.Drawing.Size(31, 21);
            this.FootpedalMode_GetButton.TabIndex = 12;
            this.FootpedalMode_GetButton.Text = "get";
            this.FootpedalMode_GetButton.UseVisualStyleBackColor = true;
            this.FootpedalMode_GetButton.Click += new System.EventHandler(this.FootpedalMode_GetButton_Click);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(149, 121);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(79, 13);
            this.label89.TabIndex = 17;
            this.label89.Text = "recordingState:";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(149, 95);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(66, 13);
            this.label88.TabIndex = 15;
            this.label88.Text = "buttonIndex:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(4, 107);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(127, 13);
            this.label87.TabIndex = 14;
            this.label87.Text = "SmartButtonConfiguration";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(4, 66);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(81, 13);
            this.label84.TabIndex = 10;
            this.label84.Text = "FootpedalMode";
            // 
            // SmartButtonConfiguration_RecordingStateCombo
            // 
            this.SmartButtonConfiguration_RecordingStateCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SmartButtonConfiguration_RecordingStateCombo.FormattingEnabled = true;
            this.SmartButtonConfiguration_RecordingStateCombo.Location = new System.Drawing.Point(244, 118);
            this.SmartButtonConfiguration_RecordingStateCombo.Name = "SmartButtonConfiguration_RecordingStateCombo";
            this.SmartButtonConfiguration_RecordingStateCombo.Size = new System.Drawing.Size(190, 21);
            this.SmartButtonConfiguration_RecordingStateCombo.TabIndex = 18;
            this.SmartButtonConfiguration_RecordingStateCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // SmartButtonConfiguration_ButtonIndexCombo
            // 
            this.SmartButtonConfiguration_ButtonIndexCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SmartButtonConfiguration_ButtonIndexCombo.FormattingEnabled = true;
            this.SmartButtonConfiguration_ButtonIndexCombo.Location = new System.Drawing.Point(244, 91);
            this.SmartButtonConfiguration_ButtonIndexCombo.Name = "SmartButtonConfiguration_ButtonIndexCombo";
            this.SmartButtonConfiguration_ButtonIndexCombo.Size = new System.Drawing.Size(190, 21);
            this.SmartButtonConfiguration_ButtonIndexCombo.TabIndex = 16;
            this.SmartButtonConfiguration_ButtonIndexCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // SmartButtonConfigurationCombo
            // 
            this.SmartButtonConfigurationCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SmartButtonConfigurationCombo.FormattingEnabled = true;
            this.SmartButtonConfigurationCombo.Location = new System.Drawing.Point(440, 104);
            this.SmartButtonConfigurationCombo.Name = "SmartButtonConfigurationCombo";
            this.SmartButtonConfigurationCombo.Size = new System.Drawing.Size(179, 21);
            this.SmartButtonConfigurationCombo.TabIndex = 19;
            this.SmartButtonConfigurationCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // FootpedalModeCombo
            // 
            this.FootpedalModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FootpedalModeCombo.FormattingEnabled = true;
            this.FootpedalModeCombo.Location = new System.Drawing.Point(244, 63);
            this.FootpedalModeCombo.Name = "FootpedalModeCombo";
            this.FootpedalModeCombo.Size = new System.Drawing.Size(375, 21);
            this.FootpedalModeCombo.TabIndex = 11;
            this.FootpedalModeCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // KeywordDisplayAreaStrings_SetButton
            // 
            this.KeywordDisplayAreaStrings_SetButton.Enabled = false;
            this.KeywordDisplayAreaStrings_SetButton.Location = new System.Drawing.Point(662, 9);
            this.KeywordDisplayAreaStrings_SetButton.Name = "KeywordDisplayAreaStrings_SetButton";
            this.KeywordDisplayAreaStrings_SetButton.Size = new System.Drawing.Size(35, 21);
            this.KeywordDisplayAreaStrings_SetButton.TabIndex = 5;
            this.KeywordDisplayAreaStrings_SetButton.Text = "set";
            this.KeywordDisplayAreaStrings_SetButton.UseVisualStyleBackColor = true;
            this.KeywordDisplayAreaStrings_SetButton.Click += new System.EventHandler(this.KeywordDisplayAreaStrings_SetButton_Click);
            // 
            // KeywordDisplayAreaStrings_GetButton
            // 
            this.KeywordDisplayAreaStrings_GetButton.Location = new System.Drawing.Point(625, 9);
            this.KeywordDisplayAreaStrings_GetButton.Name = "KeywordDisplayAreaStrings_GetButton";
            this.KeywordDisplayAreaStrings_GetButton.Size = new System.Drawing.Size(31, 21);
            this.KeywordDisplayAreaStrings_GetButton.TabIndex = 4;
            this.KeywordDisplayAreaStrings_GetButton.Text = "get";
            this.KeywordDisplayAreaStrings_GetButton.UseVisualStyleBackColor = true;
            this.KeywordDisplayAreaStrings_GetButton.Click += new System.EventHandler(this.KeywordDisplayAreaStrings_GetButton_Click);
            // 
            // EditMode_SetButton
            // 
            this.EditMode_SetButton.Enabled = false;
            this.EditMode_SetButton.Location = new System.Drawing.Point(662, 37);
            this.EditMode_SetButton.Name = "EditMode_SetButton";
            this.EditMode_SetButton.Size = new System.Drawing.Size(35, 21);
            this.EditMode_SetButton.TabIndex = 9;
            this.EditMode_SetButton.Text = "set";
            this.EditMode_SetButton.UseVisualStyleBackColor = true;
            this.EditMode_SetButton.Click += new System.EventHandler(this.EditMode_SetButton_Click);
            // 
            // EditMode_GetButton
            // 
            this.EditMode_GetButton.Location = new System.Drawing.Point(625, 36);
            this.EditMode_GetButton.Name = "EditMode_GetButton";
            this.EditMode_GetButton.Size = new System.Drawing.Size(31, 21);
            this.EditMode_GetButton.TabIndex = 8;
            this.EditMode_GetButton.Text = "get";
            this.EditMode_GetButton.UseVisualStyleBackColor = true;
            this.EditMode_GetButton.Click += new System.EventHandler(this.EditMode_GetButton_Click);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(4, 14);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(136, 13);
            this.label86.TabIndex = 0;
            this.label86.Text = "KeywordDisplayAreaStrings";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(4, 39);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(52, 13);
            this.label83.TabIndex = 6;
            this.label83.Text = "EditMode";
            // 
            // KeywordDisplayAreaStringsCombo
            // 
            this.KeywordDisplayAreaStringsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.KeywordDisplayAreaStringsCombo.FormattingEnabled = true;
            this.KeywordDisplayAreaStringsCombo.Location = new System.Drawing.Point(244, 10);
            this.KeywordDisplayAreaStringsCombo.Name = "KeywordDisplayAreaStringsCombo";
            this.KeywordDisplayAreaStringsCombo.Size = new System.Drawing.Size(375, 21);
            this.KeywordDisplayAreaStringsCombo.TabIndex = 3;
            this.KeywordDisplayAreaStringsCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // EditModeCombo
            // 
            this.EditModeCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.EditModeCombo.FormattingEnabled = true;
            this.EditModeCombo.Location = new System.Drawing.Point(244, 36);
            this.EditModeCombo.Name = "EditModeCombo";
            this.EditModeCombo.Size = new System.Drawing.Size(375, 21);
            this.EditModeCombo.TabIndex = 7;
            this.EditModeCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // deviceSettings6TabPage
            // 
            this.deviceSettings6TabPage.Controls.Add(this.RecordingProfileGroup);
            this.deviceSettings6TabPage.Controls.Add(this.RecordingProfile_GetButton);
            this.deviceSettings6TabPage.Controls.Add(this.label92);
            this.deviceSettings6TabPage.Controls.Add(this.RecordingProfileCombo);
            this.deviceSettings6TabPage.Controls.Add(this.ActiveRecordingProfile_SetButton);
            this.deviceSettings6TabPage.Controls.Add(this.ActiveRecordingProfile_GetButton);
            this.deviceSettings6TabPage.Controls.Add(this.label91);
            this.deviceSettings6TabPage.Controls.Add(this.ActiveRecordingProfileCombo);
            this.deviceSettings6TabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceSettings6TabPage.Name = "deviceSettings6TabPage";
            this.deviceSettings6TabPage.Size = new System.Drawing.Size(704, 284);
            this.deviceSettings6TabPage.TabIndex = 5;
            this.deviceSettings6TabPage.Text = "Settings 6";
            this.deviceSettings6TabPage.UseVisualStyleBackColor = true;
            // 
            // RecordingProfileGroup
            // 
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneDirectivityOnRecordingProfile_SetButton);
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneSensitivityOnRecordingProfile_SetButton);
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneDirectivityOnRecordingProfile_GetButton);
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneSensitivityOnRecordingProfile_GetButton);
            this.RecordingProfileGroup.Controls.Add(this.label94);
            this.RecordingProfileGroup.Controls.Add(this.label95);
            this.RecordingProfileGroup.Controls.Add(this.label96);
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo);
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneDirectivityOnRecordingProfileCombo);
            this.RecordingProfileGroup.Controls.Add(this.MicrophoneSensitivityOnRecordingProfileCombo);
            this.RecordingProfileGroup.Controls.Add(this.RecordingModeOnRecordingProfile_SetButton);
            this.RecordingProfileGroup.Controls.Add(this.RecordingModeOnRecordingProfile_GetButton);
            this.RecordingProfileGroup.Controls.Add(this.label97);
            this.RecordingProfileGroup.Controls.Add(this.RecordingModeOnRecordingProfileCombo);
            this.RecordingProfileGroup.Location = new System.Drawing.Point(6, 99);
            this.RecordingProfileGroup.Name = "RecordingProfileGroup";
            this.RecordingProfileGroup.Size = new System.Drawing.Size(691, 110);
            this.RecordingProfileGroup.TabIndex = 17;
            this.RecordingProfileGroup.TabStop = false;
            // 
            // MicrophoneDirectivityOnRecordingProfile_SetButton
            // 
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.Enabled = false;
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.Location = new System.Drawing.Point(650, 73);
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.Name = "MicrophoneDirectivityOnRecordingProfile_SetButton";
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.Size = new System.Drawing.Size(35, 21);
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.TabIndex = 37;
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.Text = "set";
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.UseVisualStyleBackColor = true;
            this.MicrophoneDirectivityOnRecordingProfile_SetButton.Click += new System.EventHandler(this.MicrophoneDirectivityOnRecordingProfile_SetButton_Click);
            // 
            // MicrophoneSensitivityOnRecordingProfile_SetButton
            // 
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.Enabled = false;
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.Location = new System.Drawing.Point(650, 46);
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.Name = "MicrophoneSensitivityOnRecordingProfile_SetButton";
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.Size = new System.Drawing.Size(35, 21);
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.TabIndex = 29;
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.Text = "set";
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.UseVisualStyleBackColor = true;
            this.MicrophoneSensitivityOnRecordingProfile_SetButton.Click += new System.EventHandler(this.MicrophoneSensitivityOnRecordingProfile_SetButton_Click);
            // 
            // MicrophoneDirectivityOnRecordingProfile_GetButton
            // 
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.Location = new System.Drawing.Point(613, 73);
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.Name = "MicrophoneDirectivityOnRecordingProfile_GetButton";
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.Size = new System.Drawing.Size(31, 21);
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.TabIndex = 36;
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.Text = "get";
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.UseVisualStyleBackColor = true;
            this.MicrophoneDirectivityOnRecordingProfile_GetButton.Click += new System.EventHandler(this.MicrophoneDirectivityOnRecordingProfile_GetButton_Click);
            // 
            // MicrophoneSensitivityOnRecordingProfile_GetButton
            // 
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.Location = new System.Drawing.Point(613, 46);
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.Name = "MicrophoneSensitivityOnRecordingProfile_GetButton";
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.Size = new System.Drawing.Size(31, 21);
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.TabIndex = 28;
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.Text = "get";
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.UseVisualStyleBackColor = true;
            this.MicrophoneSensitivityOnRecordingProfile_GetButton.Click += new System.EventHandler(this.MicrophoneSensitivityOnRecordingProfile_GetButton_Click);
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(127, 77);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(35, 13);
            this.label94.TabIndex = 31;
            this.label94.Text = "index:";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(6, 77);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(109, 13);
            this.label95.TabIndex = 30;
            this.label95.Text = "MicrophoneDirectivity";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(6, 49);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(110, 13);
            this.label96.TabIndex = 26;
            this.label96.Text = "MicrophoneSensitivity";
            // 
            // MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo
            // 
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.FormattingEnabled = true;
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.Location = new System.Drawing.Point(167, 73);
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.Name = "MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo";
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.Size = new System.Drawing.Size(222, 21);
            this.MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo.TabIndex = 32;
            // 
            // MicrophoneDirectivityOnRecordingProfileCombo
            // 
            this.MicrophoneDirectivityOnRecordingProfileCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MicrophoneDirectivityOnRecordingProfileCombo.FormattingEnabled = true;
            this.MicrophoneDirectivityOnRecordingProfileCombo.Location = new System.Drawing.Point(395, 73);
            this.MicrophoneDirectivityOnRecordingProfileCombo.Name = "MicrophoneDirectivityOnRecordingProfileCombo";
            this.MicrophoneDirectivityOnRecordingProfileCombo.Size = new System.Drawing.Size(212, 21);
            this.MicrophoneDirectivityOnRecordingProfileCombo.TabIndex = 35;
            this.MicrophoneDirectivityOnRecordingProfileCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // MicrophoneSensitivityOnRecordingProfileCombo
            // 
            this.MicrophoneSensitivityOnRecordingProfileCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MicrophoneSensitivityOnRecordingProfileCombo.FormattingEnabled = true;
            this.MicrophoneSensitivityOnRecordingProfileCombo.Location = new System.Drawing.Point(130, 46);
            this.MicrophoneSensitivityOnRecordingProfileCombo.Name = "MicrophoneSensitivityOnRecordingProfileCombo";
            this.MicrophoneSensitivityOnRecordingProfileCombo.Size = new System.Drawing.Size(477, 21);
            this.MicrophoneSensitivityOnRecordingProfileCombo.TabIndex = 27;
            this.MicrophoneSensitivityOnRecordingProfileCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // RecordingModeOnRecordingProfile_SetButton
            // 
            this.RecordingModeOnRecordingProfile_SetButton.Enabled = false;
            this.RecordingModeOnRecordingProfile_SetButton.Location = new System.Drawing.Point(650, 19);
            this.RecordingModeOnRecordingProfile_SetButton.Name = "RecordingModeOnRecordingProfile_SetButton";
            this.RecordingModeOnRecordingProfile_SetButton.Size = new System.Drawing.Size(35, 21);
            this.RecordingModeOnRecordingProfile_SetButton.TabIndex = 25;
            this.RecordingModeOnRecordingProfile_SetButton.Text = "set";
            this.RecordingModeOnRecordingProfile_SetButton.UseVisualStyleBackColor = true;
            this.RecordingModeOnRecordingProfile_SetButton.Click += new System.EventHandler(this.RecordingModeOnRecordingProfile_SetButton_Click);
            // 
            // RecordingModeOnRecordingProfile_GetButton
            // 
            this.RecordingModeOnRecordingProfile_GetButton.Location = new System.Drawing.Point(613, 19);
            this.RecordingModeOnRecordingProfile_GetButton.Name = "RecordingModeOnRecordingProfile_GetButton";
            this.RecordingModeOnRecordingProfile_GetButton.Size = new System.Drawing.Size(31, 21);
            this.RecordingModeOnRecordingProfile_GetButton.TabIndex = 24;
            this.RecordingModeOnRecordingProfile_GetButton.Text = "get";
            this.RecordingModeOnRecordingProfile_GetButton.UseVisualStyleBackColor = true;
            this.RecordingModeOnRecordingProfile_GetButton.Click += new System.EventHandler(this.RecordingModeOnRecordingProfile_GetButton_Click);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(6, 22);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(83, 13);
            this.label97.TabIndex = 22;
            this.label97.Text = "RecordingMode";
            // 
            // RecordingModeOnRecordingProfileCombo
            // 
            this.RecordingModeOnRecordingProfileCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RecordingModeOnRecordingProfileCombo.FormattingEnabled = true;
            this.RecordingModeOnRecordingProfileCombo.Location = new System.Drawing.Point(130, 19);
            this.RecordingModeOnRecordingProfileCombo.Name = "RecordingModeOnRecordingProfileCombo";
            this.RecordingModeOnRecordingProfileCombo.Size = new System.Drawing.Size(477, 21);
            this.RecordingModeOnRecordingProfileCombo.TabIndex = 23;
            this.RecordingModeOnRecordingProfileCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // RecordingProfile_GetButton
            // 
            this.RecordingProfile_GetButton.Location = new System.Drawing.Point(619, 72);
            this.RecordingProfile_GetButton.Name = "RecordingProfile_GetButton";
            this.RecordingProfile_GetButton.Size = new System.Drawing.Size(31, 21);
            this.RecordingProfile_GetButton.TabIndex = 16;
            this.RecordingProfile_GetButton.Text = "get";
            this.RecordingProfile_GetButton.UseVisualStyleBackColor = true;
            this.RecordingProfile_GetButton.Click += new System.EventHandler(this.RecordingProfile_GetButton_Click);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(3, 75);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(85, 13);
            this.label92.TabIndex = 14;
            this.label92.Text = "RecordingProfile";
            // 
            // RecordingProfileCombo
            // 
            this.RecordingProfileCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RecordingProfileCombo.FormattingEnabled = true;
            this.RecordingProfileCombo.Location = new System.Drawing.Point(136, 72);
            this.RecordingProfileCombo.Name = "RecordingProfileCombo";
            this.RecordingProfileCombo.Size = new System.Drawing.Size(477, 21);
            this.RecordingProfileCombo.TabIndex = 15;
            // 
            // ActiveRecordingProfile_SetButton
            // 
            this.ActiveRecordingProfile_SetButton.Enabled = false;
            this.ActiveRecordingProfile_SetButton.Location = new System.Drawing.Point(656, 12);
            this.ActiveRecordingProfile_SetButton.Name = "ActiveRecordingProfile_SetButton";
            this.ActiveRecordingProfile_SetButton.Size = new System.Drawing.Size(35, 21);
            this.ActiveRecordingProfile_SetButton.TabIndex = 13;
            this.ActiveRecordingProfile_SetButton.Text = "set";
            this.ActiveRecordingProfile_SetButton.UseVisualStyleBackColor = true;
            this.ActiveRecordingProfile_SetButton.Click += new System.EventHandler(this.ActiveRecordingProfile_SetButton_Click);
            // 
            // ActiveRecordingProfile_GetButton
            // 
            this.ActiveRecordingProfile_GetButton.Location = new System.Drawing.Point(619, 12);
            this.ActiveRecordingProfile_GetButton.Name = "ActiveRecordingProfile_GetButton";
            this.ActiveRecordingProfile_GetButton.Size = new System.Drawing.Size(31, 21);
            this.ActiveRecordingProfile_GetButton.TabIndex = 12;
            this.ActiveRecordingProfile_GetButton.Text = "get";
            this.ActiveRecordingProfile_GetButton.UseVisualStyleBackColor = true;
            this.ActiveRecordingProfile_GetButton.Click += new System.EventHandler(this.ActiveRecordingProfile_GetButton_Click);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(3, 15);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(118, 13);
            this.label91.TabIndex = 10;
            this.label91.Text = "ActiveRecordingProfile ";
            // 
            // ActiveRecordingProfileCombo
            // 
            this.ActiveRecordingProfileCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ActiveRecordingProfileCombo.FormattingEnabled = true;
            this.ActiveRecordingProfileCombo.Location = new System.Drawing.Point(136, 12);
            this.ActiveRecordingProfileCombo.Name = "ActiveRecordingProfileCombo";
            this.ActiveRecordingProfileCombo.Size = new System.Drawing.Size(477, 21);
            this.ActiveRecordingProfileCombo.TabIndex = 11;
            this.ActiveRecordingProfileCombo.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnImportConfig
            // 
            this.btnImportConfig.Location = new System.Drawing.Point(520, 421);
            this.btnImportConfig.Name = "btnImportConfig";
            this.btnImportConfig.Size = new System.Drawing.Size(91, 23);
            this.btnImportConfig.TabIndex = 0;
            this.btnImportConfig.Text = "Import Config";
            this.btnImportConfig.UseVisualStyleBackColor = true;
            this.btnImportConfig.Click += new System.EventHandler(this.btnImportConfig_Click);
            // 
            // capabilitiesTabPage
            // 
            this.capabilitiesTabPage.Controls.Add(this.btnDCGetFromIDPMDevice);
            this.capabilitiesTabPage.Controls.Add(this.cmbDeviceCapabilitesDeviceType);
            this.capabilitiesTabPage.Controls.Add(this.btnGetDeviceCapabilities);
            this.capabilitiesTabPage.Controls.Add(this.deviceCapabilitesPanel);
            this.capabilitiesTabPage.Location = new System.Drawing.Point(4, 22);
            this.capabilitiesTabPage.Name = "capabilitiesTabPage";
            this.capabilitiesTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.capabilitiesTabPage.Size = new System.Drawing.Size(722, 510);
            this.capabilitiesTabPage.TabIndex = 3;
            this.capabilitiesTabPage.Text = "IDPMDeviceCapabilities";
            this.capabilitiesTabPage.UseVisualStyleBackColor = true;
            // 
            // btnDCGetFromIDPMDevice
            // 
            this.btnDCGetFromIDPMDevice.Enabled = false;
            this.btnDCGetFromIDPMDevice.Location = new System.Drawing.Point(6, 36);
            this.btnDCGetFromIDPMDevice.Name = "btnDCGetFromIDPMDevice";
            this.btnDCGetFromIDPMDevice.Size = new System.Drawing.Size(251, 23);
            this.btnDCGetFromIDPMDevice.TabIndex = 3;
            this.btnDCGetFromIDPMDevice.Text = "IDPMDevice.DeviceCapacilities";
            this.btnDCGetFromIDPMDevice.UseVisualStyleBackColor = true;
            this.btnDCGetFromIDPMDevice.Click += new System.EventHandler(this.btnDCGetFromIDPMDevice_Click);
            // 
            // cmbDeviceCapabilitesDeviceType
            // 
            this.cmbDeviceCapabilitesDeviceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDeviceCapabilitesDeviceType.FormattingEnabled = true;
            this.cmbDeviceCapabilitesDeviceType.Location = new System.Drawing.Point(6, 10);
            this.cmbDeviceCapabilitesDeviceType.Name = "cmbDeviceCapabilitesDeviceType";
            this.cmbDeviceCapabilitesDeviceType.Size = new System.Drawing.Size(121, 21);
            this.cmbDeviceCapabilitesDeviceType.TabIndex = 1;
            // 
            // btnGetDeviceCapabilities
            // 
            this.btnGetDeviceCapabilities.Location = new System.Drawing.Point(133, 9);
            this.btnGetDeviceCapabilities.Name = "btnGetDeviceCapabilities";
            this.btnGetDeviceCapabilities.Size = new System.Drawing.Size(124, 23);
            this.btnGetDeviceCapabilities.TabIndex = 0;
            this.btnGetDeviceCapabilities.Text = "get_DPMCapabilities";
            this.btnGetDeviceCapabilities.UseVisualStyleBackColor = true;
            this.btnGetDeviceCapabilities.Click += new System.EventHandler(this.btnGetDeviceCapabilities_Click);
            // 
            // deviceCapabilitesPanel
            // 
            this.deviceCapabilitesPanel.Controls.Add(this.textDcKeywordVoiceCommandMax);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCVendorId);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCUserStringMax);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCProductId);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCKeywordUsageMax);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCMaxKeywordLength);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCKeywordContentMax);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCDisplayModeCount);
            this.deviceCapabilitesPanel.Controls.Add(this.textDCDeviceName);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordVoiceCommandMaxGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cmbDCKeywordVoiceCommandMaxCommanfType);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCDeviceNameGet);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCBarcodeScanButtonGet);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCVendorIdGet);
            this.deviceCapabilitesPanel.Controls.Add(this.label67);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCUserStringMaxGet);
            this.deviceCapabilitesPanel.Controls.Add(this.label65);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDcSecurityGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCSecurity);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCScanKeywordsFromBarcodeGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCScanKeywordsFromBarcode);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCRequiredInputTypeGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCRequiredInputType);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCQualityPlayGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCQualityPlay);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCProhibitFileAlterationGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCProhibitFileAlteration);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCProductIdGet);
            this.deviceCapabilitesPanel.Controls.Add(this.label63);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCPriorityGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCPriority);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCLinkKeywordsGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCLinkKeywords);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordVoiceCommandGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCKeywordVoiceCommand);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordUsageMaxGet);
            this.deviceCapabilitesPanel.Controls.Add(this.label61);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordsReadOnlyGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCKeywordsReadOnly);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordMandatoryGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCKeywordMandatory);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCMaxKeywordLengthGet);
            this.deviceCapabilitesPanel.Controls.Add(this.label93);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordContentMaxGet);
            this.deviceCapabilitesPanel.Controls.Add(this.label59);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCDisplayModeCountGet);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCKeywordBarcodeScanGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCKeywordBarcodeScan);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCInstructionGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCInstruction);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCFunctionKey);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCFunctionKey);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCFourPosSwitchGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCFourPosSwitch);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCEncryptionGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCEncryption);
            this.deviceCapabilitesPanel.Controls.Add(this.label56);
            this.deviceCapabilitesPanel.Controls.Add(this.label54);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCBarcodeScanButton);
            this.deviceCapabilitesPanel.Controls.Add(this.btnDCBarcodeEventGet);
            this.deviceCapabilitesPanel.Controls.Add(this.cbDCBarcodeEvent);
            this.deviceCapabilitesPanel.Location = new System.Drawing.Point(6, 76);
            this.deviceCapabilitesPanel.Name = "deviceCapabilitesPanel";
            this.deviceCapabilitesPanel.Size = new System.Drawing.Size(710, 353);
            this.deviceCapabilitesPanel.TabIndex = 1;
            this.deviceCapabilitesPanel.Visible = false;
            // 
            // textDcKeywordVoiceCommandMax
            // 
            this.textDcKeywordVoiceCommandMax.Location = new System.Drawing.Point(321, 308);
            this.textDcKeywordVoiceCommandMax.Name = "textDcKeywordVoiceCommandMax";
            this.textDcKeywordVoiceCommandMax.ReadOnly = true;
            this.textDcKeywordVoiceCommandMax.Size = new System.Drawing.Size(190, 20);
            this.textDcKeywordVoiceCommandMax.TabIndex = 59;
            // 
            // textDCVendorId
            // 
            this.textDCVendorId.Location = new System.Drawing.Point(539, 285);
            this.textDCVendorId.Name = "textDCVendorId";
            this.textDCVendorId.ReadOnly = true;
            this.textDCVendorId.Size = new System.Drawing.Size(92, 20);
            this.textDCVendorId.TabIndex = 56;
            // 
            // textDCUserStringMax
            // 
            this.textDCUserStringMax.Location = new System.Drawing.Point(539, 262);
            this.textDCUserStringMax.Name = "textDCUserStringMax";
            this.textDCUserStringMax.ReadOnly = true;
            this.textDCUserStringMax.Size = new System.Drawing.Size(92, 20);
            this.textDCUserStringMax.TabIndex = 53;
            // 
            // textDCProductId
            // 
            this.textDCProductId.Location = new System.Drawing.Point(541, 124);
            this.textDCProductId.Name = "textDCProductId";
            this.textDCProductId.ReadOnly = true;
            this.textDCProductId.Size = new System.Drawing.Size(90, 20);
            this.textDCProductId.TabIndex = 40;
            // 
            // textDCKeywordUsageMax
            // 
            this.textDCKeywordUsageMax.Location = new System.Drawing.Point(565, 32);
            this.textDCKeywordUsageMax.Name = "textDCKeywordUsageMax";
            this.textDCKeywordUsageMax.ReadOnly = true;
            this.textDCKeywordUsageMax.Size = new System.Drawing.Size(66, 20);
            this.textDCKeywordUsageMax.TabIndex = 31;
            // 
            // textDCMaxKeywordLength
            // 
            this.textDCMaxKeywordLength.Location = new System.Drawing.Point(115, 267);
            this.textDCMaxKeywordLength.Name = "textDCMaxKeywordLength";
            this.textDCMaxKeywordLength.ReadOnly = true;
            this.textDCMaxKeywordLength.Size = new System.Drawing.Size(66, 20);
            this.textDCMaxKeywordLength.TabIndex = 26;
            // 
            // textDCKeywordContentMax
            // 
            this.textDCKeywordContentMax.Location = new System.Drawing.Point(115, 220);
            this.textDCKeywordContentMax.Name = "textDCKeywordContentMax";
            this.textDCKeywordContentMax.ReadOnly = true;
            this.textDCKeywordContentMax.Size = new System.Drawing.Size(66, 20);
            this.textDCKeywordContentMax.TabIndex = 21;
            // 
            // textDCDisplayModeCount
            // 
            this.textDCDisplayModeCount.Location = new System.Drawing.Point(115, 79);
            this.textDCDisplayModeCount.Name = "textDCDisplayModeCount";
            this.textDCDisplayModeCount.ReadOnly = true;
            this.textDCDisplayModeCount.Size = new System.Drawing.Size(66, 20);
            this.textDCDisplayModeCount.TabIndex = 8;
            // 
            // textDCDeviceName
            // 
            this.textDCDeviceName.Location = new System.Drawing.Point(94, 56);
            this.textDCDeviceName.Name = "textDCDeviceName";
            this.textDCDeviceName.ReadOnly = true;
            this.textDCDeviceName.Size = new System.Drawing.Size(87, 20);
            this.textDCDeviceName.TabIndex = 5;
            // 
            // btnDCKeywordVoiceCommandMaxGet
            // 
            this.btnDCKeywordVoiceCommandMaxGet.Location = new System.Drawing.Point(518, 308);
            this.btnDCKeywordVoiceCommandMaxGet.Name = "btnDCKeywordVoiceCommandMaxGet";
            this.btnDCKeywordVoiceCommandMaxGet.Size = new System.Drawing.Size(175, 21);
            this.btnDCKeywordVoiceCommandMaxGet.TabIndex = 60;
            this.btnDCKeywordVoiceCommandMaxGet.Text = "get_KeywordVoiceCommandMax";
            this.btnDCKeywordVoiceCommandMaxGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordVoiceCommandMaxGet.Click += new System.EventHandler(this.btnDCKeywordVoiceCommandMaxGet_Click);
            // 
            // cmbDCKeywordVoiceCommandMaxCommanfType
            // 
            this.cmbDCKeywordVoiceCommandMaxCommanfType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDCKeywordVoiceCommandMaxCommanfType.FormattingEnabled = true;
            this.cmbDCKeywordVoiceCommandMaxCommanfType.Location = new System.Drawing.Point(141, 307);
            this.cmbDCKeywordVoiceCommandMaxCommanfType.Name = "cmbDCKeywordVoiceCommandMaxCommanfType";
            this.cmbDCKeywordVoiceCommandMaxCommanfType.Size = new System.Drawing.Size(174, 21);
            this.cmbDCKeywordVoiceCommandMaxCommanfType.TabIndex = 58;
            // 
            // btnDCDeviceNameGet
            // 
            this.btnDCDeviceNameGet.Location = new System.Drawing.Point(187, 55);
            this.btnDCDeviceNameGet.Name = "btnDCDeviceNameGet";
            this.btnDCDeviceNameGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCDeviceNameGet.TabIndex = 6;
            this.btnDCDeviceNameGet.Text = "get";
            this.btnDCDeviceNameGet.UseVisualStyleBackColor = true;
            this.btnDCDeviceNameGet.Click += new System.EventHandler(this.btnDCDeviceNameGet_Click);
            // 
            // btnDCBarcodeScanButtonGet
            // 
            this.btnDCBarcodeScanButtonGet.Location = new System.Drawing.Point(187, 31);
            this.btnDCBarcodeScanButtonGet.Name = "btnDCBarcodeScanButtonGet";
            this.btnDCBarcodeScanButtonGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCBarcodeScanButtonGet.TabIndex = 3;
            this.btnDCBarcodeScanButtonGet.Text = "get";
            this.btnDCBarcodeScanButtonGet.UseVisualStyleBackColor = true;
            this.btnDCBarcodeScanButtonGet.Click += new System.EventHandler(this.btnDCBarcodeScanButtonGet_Click);
            // 
            // btnDCVendorIdGet
            // 
            this.btnDCVendorIdGet.Location = new System.Drawing.Point(637, 284);
            this.btnDCVendorIdGet.Name = "btnDCVendorIdGet";
            this.btnDCVendorIdGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCVendorIdGet.TabIndex = 57;
            this.btnDCVendorIdGet.Text = "get";
            this.btnDCVendorIdGet.UseVisualStyleBackColor = true;
            this.btnDCVendorIdGet.Click += new System.EventHandler(this.btnDCVendorIdGet_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(461, 288);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(50, 13);
            this.label67.TabIndex = 55;
            this.label67.Text = "VendorId";
            // 
            // btnDCUserStringMaxGet
            // 
            this.btnDCUserStringMaxGet.Location = new System.Drawing.Point(637, 261);
            this.btnDCUserStringMaxGet.Name = "btnDCUserStringMaxGet";
            this.btnDCUserStringMaxGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCUserStringMaxGet.TabIndex = 54;
            this.btnDCUserStringMaxGet.Text = "get";
            this.btnDCUserStringMaxGet.UseVisualStyleBackColor = true;
            this.btnDCUserStringMaxGet.Click += new System.EventHandler(this.btnDCUserStringMaxGet_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(461, 265);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(76, 13);
            this.label65.TabIndex = 52;
            this.label65.Text = "UserStringMax";
            // 
            // btnDcSecurityGet
            // 
            this.btnDcSecurityGet.Location = new System.Drawing.Point(637, 238);
            this.btnDcSecurityGet.Name = "btnDcSecurityGet";
            this.btnDcSecurityGet.Size = new System.Drawing.Size(60, 21);
            this.btnDcSecurityGet.TabIndex = 51;
            this.btnDcSecurityGet.Text = "get";
            this.btnDcSecurityGet.UseVisualStyleBackColor = true;
            this.btnDcSecurityGet.Click += new System.EventHandler(this.btnDcSecurityGet_Click);
            // 
            // cbDCSecurity
            // 
            this.cbDCSecurity.AutoSize = true;
            this.cbDCSecurity.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCSecurity.Location = new System.Drawing.Point(567, 235);
            this.cbDCSecurity.Name = "cbDCSecurity";
            this.cbDCSecurity.Size = new System.Drawing.Size(64, 17);
            this.cbDCSecurity.TabIndex = 50;
            this.cbDCSecurity.Text = "Security";
            this.cbDCSecurity.UseVisualStyleBackColor = true;
            // 
            // btnDCScanKeywordsFromBarcodeGet
            // 
            this.btnDCScanKeywordsFromBarcodeGet.Location = new System.Drawing.Point(637, 215);
            this.btnDCScanKeywordsFromBarcodeGet.Name = "btnDCScanKeywordsFromBarcodeGet";
            this.btnDCScanKeywordsFromBarcodeGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCScanKeywordsFromBarcodeGet.TabIndex = 49;
            this.btnDCScanKeywordsFromBarcodeGet.Text = "get";
            this.btnDCScanKeywordsFromBarcodeGet.UseVisualStyleBackColor = true;
            this.btnDCScanKeywordsFromBarcodeGet.Click += new System.EventHandler(this.btnDCScanKeywordsFromBarcodeGet_Click);
            // 
            // cbDCScanKeywordsFromBarcode
            // 
            this.cbDCScanKeywordsFromBarcode.AutoSize = true;
            this.cbDCScanKeywordsFromBarcode.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCScanKeywordsFromBarcode.Location = new System.Drawing.Point(471, 218);
            this.cbDCScanKeywordsFromBarcode.Name = "cbDCScanKeywordsFromBarcode";
            this.cbDCScanKeywordsFromBarcode.Size = new System.Drawing.Size(160, 17);
            this.cbDCScanKeywordsFromBarcode.TabIndex = 48;
            this.cbDCScanKeywordsFromBarcode.Text = "ScanKeywordsFromBarcode";
            this.cbDCScanKeywordsFromBarcode.UseVisualStyleBackColor = true;
            // 
            // btnDCRequiredInputTypeGet
            // 
            this.btnDCRequiredInputTypeGet.Location = new System.Drawing.Point(637, 192);
            this.btnDCRequiredInputTypeGet.Name = "btnDCRequiredInputTypeGet";
            this.btnDCRequiredInputTypeGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCRequiredInputTypeGet.TabIndex = 47;
            this.btnDCRequiredInputTypeGet.Text = "get";
            this.btnDCRequiredInputTypeGet.UseVisualStyleBackColor = true;
            this.btnDCRequiredInputTypeGet.Click += new System.EventHandler(this.btnDCRequiredInputTypeGet_Click);
            // 
            // cbDCRequiredInputType
            // 
            this.cbDCRequiredInputType.AutoSize = true;
            this.cbDCRequiredInputType.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCRequiredInputType.Location = new System.Drawing.Point(514, 195);
            this.cbDCRequiredInputType.Name = "cbDCRequiredInputType";
            this.cbDCRequiredInputType.Size = new System.Drawing.Size(117, 17);
            this.cbDCRequiredInputType.TabIndex = 46;
            this.cbDCRequiredInputType.Text = "RequiredInputType";
            this.cbDCRequiredInputType.UseVisualStyleBackColor = true;
            // 
            // btnDCQualityPlayGet
            // 
            this.btnDCQualityPlayGet.Location = new System.Drawing.Point(637, 169);
            this.btnDCQualityPlayGet.Name = "btnDCQualityPlayGet";
            this.btnDCQualityPlayGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCQualityPlayGet.TabIndex = 45;
            this.btnDCQualityPlayGet.Text = "get";
            this.btnDCQualityPlayGet.UseVisualStyleBackColor = true;
            this.btnDCQualityPlayGet.Click += new System.EventHandler(this.btnDCQualityPlayGet_Click);
            // 
            // cbDCQualityPlay
            // 
            this.cbDCQualityPlay.AutoSize = true;
            this.cbDCQualityPlay.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCQualityPlay.Location = new System.Drawing.Point(553, 172);
            this.cbDCQualityPlay.Name = "cbDCQualityPlay";
            this.cbDCQualityPlay.Size = new System.Drawing.Size(78, 17);
            this.cbDCQualityPlay.TabIndex = 44;
            this.cbDCQualityPlay.Text = "QualityPlay";
            this.cbDCQualityPlay.UseVisualStyleBackColor = true;
            // 
            // btnDCProhibitFileAlterationGet
            // 
            this.btnDCProhibitFileAlterationGet.Location = new System.Drawing.Point(637, 146);
            this.btnDCProhibitFileAlterationGet.Name = "btnDCProhibitFileAlterationGet";
            this.btnDCProhibitFileAlterationGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCProhibitFileAlterationGet.TabIndex = 43;
            this.btnDCProhibitFileAlterationGet.Text = "get";
            this.btnDCProhibitFileAlterationGet.UseVisualStyleBackColor = true;
            this.btnDCProhibitFileAlterationGet.Click += new System.EventHandler(this.btnDCProhibitFileAlterationGet_Click);
            // 
            // cbDCProhibitFileAlteration
            // 
            this.cbDCProhibitFileAlteration.AutoSize = true;
            this.cbDCProhibitFileAlteration.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCProhibitFileAlteration.Location = new System.Drawing.Point(510, 149);
            this.cbDCProhibitFileAlteration.Name = "cbDCProhibitFileAlteration";
            this.cbDCProhibitFileAlteration.Size = new System.Drawing.Size(121, 17);
            this.cbDCProhibitFileAlteration.TabIndex = 42;
            this.cbDCProhibitFileAlteration.Text = "ProhibitFileAlteration";
            this.cbDCProhibitFileAlteration.UseVisualStyleBackColor = true;
            // 
            // btnDCProductIdGet
            // 
            this.btnDCProductIdGet.Location = new System.Drawing.Point(637, 123);
            this.btnDCProductIdGet.Name = "btnDCProductIdGet";
            this.btnDCProductIdGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCProductIdGet.TabIndex = 41;
            this.btnDCProductIdGet.Text = "get";
            this.btnDCProductIdGet.UseVisualStyleBackColor = true;
            this.btnDCProductIdGet.Click += new System.EventHandler(this.btnDCProductIdGet_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(482, 127);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(53, 13);
            this.label63.TabIndex = 39;
            this.label63.Text = "ProductId";
            // 
            // btnDCPriorityGet
            // 
            this.btnDCPriorityGet.Location = new System.Drawing.Point(637, 100);
            this.btnDCPriorityGet.Name = "btnDCPriorityGet";
            this.btnDCPriorityGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCPriorityGet.TabIndex = 38;
            this.btnDCPriorityGet.Text = "get";
            this.btnDCPriorityGet.UseVisualStyleBackColor = true;
            this.btnDCPriorityGet.Click += new System.EventHandler(this.btnDCPriorityGet_Click);
            // 
            // cbDCPriority
            // 
            this.cbDCPriority.AutoSize = true;
            this.cbDCPriority.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCPriority.Location = new System.Drawing.Point(574, 103);
            this.cbDCPriority.Name = "cbDCPriority";
            this.cbDCPriority.Size = new System.Drawing.Size(57, 17);
            this.cbDCPriority.TabIndex = 37;
            this.cbDCPriority.Text = "Priority";
            this.cbDCPriority.UseVisualStyleBackColor = true;
            // 
            // btnDCLinkKeywordsGet
            // 
            this.btnDCLinkKeywordsGet.Location = new System.Drawing.Point(637, 77);
            this.btnDCLinkKeywordsGet.Name = "btnDCLinkKeywordsGet";
            this.btnDCLinkKeywordsGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCLinkKeywordsGet.TabIndex = 36;
            this.btnDCLinkKeywordsGet.Text = "get";
            this.btnDCLinkKeywordsGet.UseVisualStyleBackColor = true;
            this.btnDCLinkKeywordsGet.Click += new System.EventHandler(this.btnDCLinkKeywordsGet_Click);
            // 
            // cbDCLinkKeywords
            // 
            this.cbDCLinkKeywords.AutoSize = true;
            this.cbDCLinkKeywords.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCLinkKeywords.Location = new System.Drawing.Point(539, 80);
            this.cbDCLinkKeywords.Name = "cbDCLinkKeywords";
            this.cbDCLinkKeywords.Size = new System.Drawing.Size(92, 17);
            this.cbDCLinkKeywords.TabIndex = 35;
            this.cbDCLinkKeywords.Text = "LinkKeywords";
            this.cbDCLinkKeywords.UseVisualStyleBackColor = true;
            // 
            // btnDCKeywordVoiceCommandGet
            // 
            this.btnDCKeywordVoiceCommandGet.Location = new System.Drawing.Point(637, 54);
            this.btnDCKeywordVoiceCommandGet.Name = "btnDCKeywordVoiceCommandGet";
            this.btnDCKeywordVoiceCommandGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCKeywordVoiceCommandGet.TabIndex = 34;
            this.btnDCKeywordVoiceCommandGet.Text = "get";
            this.btnDCKeywordVoiceCommandGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordVoiceCommandGet.Click += new System.EventHandler(this.btnDCKeywordVoiceCommandGet_Click);
            // 
            // cbDCKeywordVoiceCommand
            // 
            this.cbDCKeywordVoiceCommand.AutoSize = true;
            this.cbDCKeywordVoiceCommand.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCKeywordVoiceCommand.Location = new System.Drawing.Point(490, 57);
            this.cbDCKeywordVoiceCommand.Name = "cbDCKeywordVoiceCommand";
            this.cbDCKeywordVoiceCommand.Size = new System.Drawing.Size(141, 17);
            this.cbDCKeywordVoiceCommand.TabIndex = 33;
            this.cbDCKeywordVoiceCommand.Text = "KeywordVoiceCommand";
            this.cbDCKeywordVoiceCommand.UseVisualStyleBackColor = true;
            // 
            // btnDCKeywordUsageMaxGet
            // 
            this.btnDCKeywordUsageMaxGet.Location = new System.Drawing.Point(637, 31);
            this.btnDCKeywordUsageMaxGet.Name = "btnDCKeywordUsageMaxGet";
            this.btnDCKeywordUsageMaxGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCKeywordUsageMaxGet.TabIndex = 32;
            this.btnDCKeywordUsageMaxGet.Text = "get";
            this.btnDCKeywordUsageMaxGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordUsageMaxGet.Click += new System.EventHandler(this.btnDCKeywordUsageMaxGet_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(465, 35);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(99, 13);
            this.label61.TabIndex = 30;
            this.label61.Text = "KeywordUsageMax";
            // 
            // btnDCKeywordsReadOnlyGet
            // 
            this.btnDCKeywordsReadOnlyGet.Location = new System.Drawing.Point(637, 9);
            this.btnDCKeywordsReadOnlyGet.Name = "btnDCKeywordsReadOnlyGet";
            this.btnDCKeywordsReadOnlyGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCKeywordsReadOnlyGet.TabIndex = 29;
            this.btnDCKeywordsReadOnlyGet.Text = "get";
            this.btnDCKeywordsReadOnlyGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordsReadOnlyGet.Click += new System.EventHandler(this.btnDCKeywordsReadOnlyGet_Click);
            // 
            // cbDCKeywordsReadOnly
            // 
            this.cbDCKeywordsReadOnly.AutoSize = true;
            this.cbDCKeywordsReadOnly.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCKeywordsReadOnly.Location = new System.Drawing.Point(512, 12);
            this.cbDCKeywordsReadOnly.Name = "cbDCKeywordsReadOnly";
            this.cbDCKeywordsReadOnly.Size = new System.Drawing.Size(119, 17);
            this.cbDCKeywordsReadOnly.TabIndex = 28;
            this.cbDCKeywordsReadOnly.Text = "KeywordsReadOnly";
            this.cbDCKeywordsReadOnly.UseVisualStyleBackColor = true;
            // 
            // btnDCKeywordMandatoryGet
            // 
            this.btnDCKeywordMandatoryGet.Location = new System.Drawing.Point(187, 243);
            this.btnDCKeywordMandatoryGet.Name = "btnDCKeywordMandatoryGet";
            this.btnDCKeywordMandatoryGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCKeywordMandatoryGet.TabIndex = 24;
            this.btnDCKeywordMandatoryGet.Text = "get";
            this.btnDCKeywordMandatoryGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordMandatoryGet.Click += new System.EventHandler(this.btnDCKeywordMandatoryGet_Click);
            // 
            // cbDCKeywordMandatory
            // 
            this.cbDCKeywordMandatory.AutoSize = true;
            this.cbDCKeywordMandatory.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCKeywordMandatory.Location = new System.Drawing.Point(64, 246);
            this.cbDCKeywordMandatory.Name = "cbDCKeywordMandatory";
            this.cbDCKeywordMandatory.Size = new System.Drawing.Size(117, 17);
            this.cbDCKeywordMandatory.TabIndex = 23;
            this.cbDCKeywordMandatory.Text = "KeywordMandatory";
            this.cbDCKeywordMandatory.UseVisualStyleBackColor = true;
            // 
            // btnDCMaxKeywordLengthGet
            // 
            this.btnDCMaxKeywordLengthGet.Location = new System.Drawing.Point(187, 266);
            this.btnDCMaxKeywordLengthGet.Name = "btnDCMaxKeywordLengthGet";
            this.btnDCMaxKeywordLengthGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCMaxKeywordLengthGet.TabIndex = 27;
            this.btnDCMaxKeywordLengthGet.Text = "get";
            this.btnDCMaxKeywordLengthGet.UseVisualStyleBackColor = true;
            this.btnDCMaxKeywordLengthGet.Click += new System.EventHandler(this.btnDCMaxKeywordLengthGet_Click);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(6, 270);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(101, 13);
            this.label93.TabIndex = 25;
            this.label93.Text = "MaxKeywordLength";
            // 
            // btnDCKeywordContentMaxGet
            // 
            this.btnDCKeywordContentMaxGet.Location = new System.Drawing.Point(187, 219);
            this.btnDCKeywordContentMaxGet.Name = "btnDCKeywordContentMaxGet";
            this.btnDCKeywordContentMaxGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCKeywordContentMaxGet.TabIndex = 22;
            this.btnDCKeywordContentMaxGet.Text = "get";
            this.btnDCKeywordContentMaxGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordContentMaxGet.Click += new System.EventHandler(this.btnDCKeywordContentMaxGet_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(6, 223);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(105, 13);
            this.label59.TabIndex = 20;
            this.label59.Text = "KeywordContentMax";
            // 
            // btnDCDisplayModeCountGet
            // 
            this.btnDCDisplayModeCountGet.Location = new System.Drawing.Point(187, 79);
            this.btnDCDisplayModeCountGet.Name = "btnDCDisplayModeCountGet";
            this.btnDCDisplayModeCountGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCDisplayModeCountGet.TabIndex = 9;
            this.btnDCDisplayModeCountGet.Text = "get";
            this.btnDCDisplayModeCountGet.UseVisualStyleBackColor = true;
            this.btnDCDisplayModeCountGet.Click += new System.EventHandler(this.btnDCDisplayModeCountGet_Click);
            // 
            // btnDCKeywordBarcodeScanGet
            // 
            this.btnDCKeywordBarcodeScanGet.Location = new System.Drawing.Point(187, 196);
            this.btnDCKeywordBarcodeScanGet.Name = "btnDCKeywordBarcodeScanGet";
            this.btnDCKeywordBarcodeScanGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCKeywordBarcodeScanGet.TabIndex = 19;
            this.btnDCKeywordBarcodeScanGet.Text = "get";
            this.btnDCKeywordBarcodeScanGet.UseVisualStyleBackColor = true;
            this.btnDCKeywordBarcodeScanGet.Click += new System.EventHandler(this.btnDCKeywordBarcodeScanGet_Click);
            // 
            // cbDCKeywordBarcodeScan
            // 
            this.cbDCKeywordBarcodeScan.AutoSize = true;
            this.cbDCKeywordBarcodeScan.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCKeywordBarcodeScan.Location = new System.Drawing.Point(49, 199);
            this.cbDCKeywordBarcodeScan.Name = "cbDCKeywordBarcodeScan";
            this.cbDCKeywordBarcodeScan.Size = new System.Drawing.Size(132, 17);
            this.cbDCKeywordBarcodeScan.TabIndex = 18;
            this.cbDCKeywordBarcodeScan.Text = "KeywordBarcodeScan";
            this.cbDCKeywordBarcodeScan.UseVisualStyleBackColor = true;
            // 
            // btnDCInstructionGet
            // 
            this.btnDCInstructionGet.Location = new System.Drawing.Point(187, 173);
            this.btnDCInstructionGet.Name = "btnDCInstructionGet";
            this.btnDCInstructionGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCInstructionGet.TabIndex = 17;
            this.btnDCInstructionGet.Text = "get";
            this.btnDCInstructionGet.UseVisualStyleBackColor = true;
            this.btnDCInstructionGet.Click += new System.EventHandler(this.btnDCInstructionGet_Click);
            // 
            // cbDCInstruction
            // 
            this.cbDCInstruction.AutoSize = true;
            this.cbDCInstruction.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCInstruction.Location = new System.Drawing.Point(106, 176);
            this.cbDCInstruction.Name = "cbDCInstruction";
            this.cbDCInstruction.Size = new System.Drawing.Size(75, 17);
            this.cbDCInstruction.TabIndex = 16;
            this.cbDCInstruction.Text = "Instruction";
            this.cbDCInstruction.UseVisualStyleBackColor = true;
            // 
            // btnDCFunctionKey
            // 
            this.btnDCFunctionKey.Location = new System.Drawing.Point(187, 150);
            this.btnDCFunctionKey.Name = "btnDCFunctionKey";
            this.btnDCFunctionKey.Size = new System.Drawing.Size(60, 21);
            this.btnDCFunctionKey.TabIndex = 15;
            this.btnDCFunctionKey.Text = "get";
            this.btnDCFunctionKey.UseVisualStyleBackColor = true;
            this.btnDCFunctionKey.Click += new System.EventHandler(this.btnDCFunctionKey_Click);
            // 
            // cbDCFunctionKey
            // 
            this.cbDCFunctionKey.AutoSize = true;
            this.cbDCFunctionKey.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCFunctionKey.Location = new System.Drawing.Point(96, 154);
            this.cbDCFunctionKey.Name = "cbDCFunctionKey";
            this.cbDCFunctionKey.Size = new System.Drawing.Size(85, 17);
            this.cbDCFunctionKey.TabIndex = 14;
            this.cbDCFunctionKey.Text = "FunctionKey";
            this.cbDCFunctionKey.UseVisualStyleBackColor = true;
            // 
            // btnDCFourPosSwitchGet
            // 
            this.btnDCFourPosSwitchGet.Location = new System.Drawing.Point(187, 127);
            this.btnDCFourPosSwitchGet.Name = "btnDCFourPosSwitchGet";
            this.btnDCFourPosSwitchGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCFourPosSwitchGet.TabIndex = 13;
            this.btnDCFourPosSwitchGet.Text = "get";
            this.btnDCFourPosSwitchGet.UseVisualStyleBackColor = true;
            this.btnDCFourPosSwitchGet.Click += new System.EventHandler(this.btnDCFourPosSwitchGet_Click);
            // 
            // cbDCFourPosSwitch
            // 
            this.cbDCFourPosSwitch.AutoSize = true;
            this.cbDCFourPosSwitch.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCFourPosSwitch.Location = new System.Drawing.Point(84, 130);
            this.cbDCFourPosSwitch.Name = "cbDCFourPosSwitch";
            this.cbDCFourPosSwitch.Size = new System.Drawing.Size(97, 17);
            this.cbDCFourPosSwitch.TabIndex = 12;
            this.cbDCFourPosSwitch.Text = "FourPosSwitch";
            this.cbDCFourPosSwitch.UseVisualStyleBackColor = true;
            // 
            // btnDCEncryptionGet
            // 
            this.btnDCEncryptionGet.Location = new System.Drawing.Point(187, 104);
            this.btnDCEncryptionGet.Name = "btnDCEncryptionGet";
            this.btnDCEncryptionGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCEncryptionGet.TabIndex = 11;
            this.btnDCEncryptionGet.Text = "get";
            this.btnDCEncryptionGet.UseVisualStyleBackColor = true;
            this.btnDCEncryptionGet.Click += new System.EventHandler(this.btnDCEncryptionGet_Click);
            // 
            // cbDCEncryption
            // 
            this.cbDCEncryption.AutoSize = true;
            this.cbDCEncryption.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCEncryption.Location = new System.Drawing.Point(105, 107);
            this.cbDCEncryption.Name = "cbDCEncryption";
            this.cbDCEncryption.Size = new System.Drawing.Size(76, 17);
            this.cbDCEncryption.TabIndex = 10;
            this.cbDCEncryption.Text = "Encryption";
            this.cbDCEncryption.UseVisualStyleBackColor = true;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(15, 83);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(96, 13);
            this.label56.TabIndex = 7;
            this.label56.Text = "DisplayModeCount";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(15, 59);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(69, 13);
            this.label54.TabIndex = 4;
            this.label54.Text = "DeviceName";
            // 
            // cbDCBarcodeScanButton
            // 
            this.cbDCBarcodeScanButton.AutoSize = true;
            this.cbDCBarcodeScanButton.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCBarcodeScanButton.Location = new System.Drawing.Point(59, 34);
            this.cbDCBarcodeScanButton.Name = "cbDCBarcodeScanButton";
            this.cbDCBarcodeScanButton.Size = new System.Drawing.Size(122, 17);
            this.cbDCBarcodeScanButton.TabIndex = 2;
            this.cbDCBarcodeScanButton.Text = "BarcodeScanButton";
            this.cbDCBarcodeScanButton.UseVisualStyleBackColor = true;
            // 
            // btnDCBarcodeEventGet
            // 
            this.btnDCBarcodeEventGet.Location = new System.Drawing.Point(187, 8);
            this.btnDCBarcodeEventGet.Name = "btnDCBarcodeEventGet";
            this.btnDCBarcodeEventGet.Size = new System.Drawing.Size(60, 21);
            this.btnDCBarcodeEventGet.TabIndex = 1;
            this.btnDCBarcodeEventGet.Text = "get";
            this.btnDCBarcodeEventGet.UseVisualStyleBackColor = true;
            this.btnDCBarcodeEventGet.Click += new System.EventHandler(this.btnDCBarcodeEventGet_Click);
            // 
            // cbDCBarcodeEvent
            // 
            this.cbDCBarcodeEvent.AutoSize = true;
            this.cbDCBarcodeEvent.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDCBarcodeEvent.Location = new System.Drawing.Point(87, 12);
            this.cbDCBarcodeEvent.Name = "cbDCBarcodeEvent";
            this.cbDCBarcodeEvent.Size = new System.Drawing.Size(94, 17);
            this.cbDCBarcodeEvent.TabIndex = 0;
            this.cbDCBarcodeEvent.Text = "BarcodeEvent";
            this.cbDCBarcodeEvent.UseVisualStyleBackColor = true;
            // 
            // deviceTabPage
            // 
            this.deviceTabPage.Controls.Add(this.btnGetDevice);
            this.deviceTabPage.Controls.Add(this.DeviceInfoPanel);
            this.deviceTabPage.Location = new System.Drawing.Point(4, 22);
            this.deviceTabPage.Name = "deviceTabPage";
            this.deviceTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.deviceTabPage.Size = new System.Drawing.Size(722, 510);
            this.deviceTabPage.TabIndex = 1;
            this.deviceTabPage.Text = "IDPMDevice";
            this.deviceTabPage.UseVisualStyleBackColor = true;
            // 
            // btnGetDevice
            // 
            this.btnGetDevice.Location = new System.Drawing.Point(5, 6);
            this.btnGetDevice.Name = "btnGetDevice";
            this.btnGetDevice.Size = new System.Drawing.Size(113, 25);
            this.btnGetDevice.TabIndex = 1;
            this.btnGetDevice.Text = "Get_IDPMDevice";
            this.btnGetDevice.UseVisualStyleBackColor = true;
            this.btnGetDevice.Click += new System.EventHandler(this.btnGetDevice_Click);
            // 
            // DeviceInfoPanel
            // 
            this.DeviceInfoPanel.Controls.Add(this.label57);
            this.DeviceInfoPanel.Controls.Add(this.btnDDPUKSetGet);
            this.DeviceInfoPanel.Controls.Add(this.cbDDPUKSet);
            this.DeviceInfoPanel.Controls.Add(this.label70);
            this.DeviceInfoPanel.Controls.Add(this.textDDPUK);
            this.DeviceInfoPanel.Controls.Add(this.btnDDPukSet);
            this.DeviceInfoPanel.Controls.Add(this.label64);
            this.DeviceInfoPanel.Controls.Add(this.label62);
            this.DeviceInfoPanel.Controls.Add(this.textDDSetPIN_PUK);
            this.DeviceInfoPanel.Controls.Add(this.label60);
            this.DeviceInfoPanel.Controls.Add(this.label58);
            this.DeviceInfoPanel.Controls.Add(this.textDDSetPIN_p2);
            this.DeviceInfoPanel.Controls.Add(this.textDDSetEncriptionPasswordoldKey);
            this.DeviceInfoPanel.Controls.Add(this.btnDDSetPIN);
            this.DeviceInfoPanel.Controls.Add(this.textDDSetEncriptionPasswordp2);
            this.DeviceInfoPanel.Controls.Add(this.WelcomeScreenHashGetButton);
            this.DeviceInfoPanel.Controls.Add(this.ResetToFactoryDefaultsButton);
            this.DeviceInfoPanel.Controls.Add(this.btnDDSynchronizeDateTime);
            this.DeviceInfoPanel.Controls.Add(this.btnDDSetEncryptionPassword);
            this.DeviceInfoPanel.Controls.Add(this.btnDDFormatCard);
            this.DeviceInfoPanel.Controls.Add(this.numDDenableLedIndex);
            this.DeviceInfoPanel.Controls.Add(this.cmbDDenableLed);
            this.DeviceInfoPanel.Controls.Add(this.btnDDenableLed);
            this.DeviceInfoPanel.Controls.Add(this.cmbDDDisplaySymbol);
            this.DeviceInfoPanel.Controls.Add(this.btnDDDisplaySymbol);
            this.DeviceInfoPanel.Controls.Add(this.btnDDDisplayScreen);
            this.DeviceInfoPanel.Controls.Add(this.btnDDDisplayScreenBrowse);
            this.DeviceInfoPanel.Controls.Add(this.textDDDisplayScreen);
            this.DeviceInfoPanel.Controls.Add(this.btnDDDeleteFile);
            this.DeviceInfoPanel.Controls.Add(this.btnDDDeleteFileBrowse);
            this.DeviceInfoPanel.Controls.Add(this.textDDDeleteFile);
            this.DeviceInfoPanel.Controls.Add(this.WelcomeScreenHashTxt);
            this.DeviceInfoPanel.Controls.Add(this.textFileCount);
            this.DeviceInfoPanel.Controls.Add(this.btnFileCount);
            this.DeviceInfoPanel.Controls.Add(this.textFreeDiskSpace);
            this.DeviceInfoPanel.Controls.Add(this.textMacAddress);
            this.DeviceInfoPanel.Controls.Add(this.textDriveLetter);
            this.DeviceInfoPanel.Controls.Add(this.btnGetFreeDiskSpace);
            this.DeviceInfoPanel.Controls.Add(this.btnGetMacAddress);
            this.DeviceInfoPanel.Controls.Add(this.textFirmwareVersion);
            this.DeviceInfoPanel.Controls.Add(this.btmGetFirmwareVersion);
            this.DeviceInfoPanel.Controls.Add(this.btnGetDriveLetter);
            this.DeviceInfoPanel.Controls.Add(this.textBuildNumber);
            this.DeviceInfoPanel.Controls.Add(this.textDeviceType);
            this.DeviceInfoPanel.Controls.Add(this.btnGetBuildNumber);
            this.DeviceInfoPanel.Controls.Add(this.btnGetDeviceType);
            this.DeviceInfoPanel.Location = new System.Drawing.Point(8, 43);
            this.DeviceInfoPanel.Name = "DeviceInfoPanel";
            this.DeviceInfoPanel.Size = new System.Drawing.Size(708, 444);
            this.DeviceInfoPanel.TabIndex = 0;
            this.DeviceInfoPanel.Visible = false;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(282, 108);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(357, 13);
            this.label57.TabIndex = 42;
            this.label57.Text = "PUK is a permament setting. It can be set only once. Not possible to undo!";
            // 
            // btnDDPUKSetGet
            // 
            this.btnDDPUKSetGet.Location = new System.Drawing.Point(82, 124);
            this.btnDDPUKSetGet.Name = "btnDDPUKSetGet";
            this.btnDDPUKSetGet.Size = new System.Drawing.Size(69, 22);
            this.btnDDPUKSetGet.TabIndex = 18;
            this.btnDDPUKSetGet.Text = "get";
            this.btnDDPUKSetGet.UseVisualStyleBackColor = true;
            this.btnDDPUKSetGet.Click += new System.EventHandler(this.btnDDPUKSetGet_Click);
            // 
            // cbDDPUKSet
            // 
            this.cbDDPUKSet.AutoSize = true;
            this.cbDDPUKSet.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDDPUKSet.Checked = true;
            this.cbDDPUKSet.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDDPUKSet.Enabled = false;
            this.cbDDPUKSet.Location = new System.Drawing.Point(12, 127);
            this.cbDDPUKSet.Name = "cbDDPUKSet";
            this.cbDDPUKSet.Size = new System.Drawing.Size(64, 17);
            this.cbDDPUKSet.TabIndex = 17;
            this.cbDDPUKSet.Text = "PUKSet";
            this.cbDDPUKSet.UseVisualStyleBackColor = true;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(282, 129);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(29, 13);
            this.label70.TabIndex = 14;
            this.label70.Text = "PUK";
            // 
            // textDDPUK
            // 
            this.textDDPUK.Location = new System.Drawing.Point(320, 125);
            this.textDDPUK.Name = "textDDPUK";
            this.textDDPUK.Size = new System.Drawing.Size(119, 20);
            this.textDDPUK.TabIndex = 15;
            // 
            // btnDDPukSet
            // 
            this.btnDDPukSet.Location = new System.Drawing.Point(444, 124);
            this.btnDDPukSet.Name = "btnDDPukSet";
            this.btnDDPukSet.Size = new System.Drawing.Size(69, 22);
            this.btnDDPukSet.TabIndex = 16;
            this.btnDDPukSet.Text = "set";
            this.btnDDPukSet.UseVisualStyleBackColor = true;
            this.btnDDPukSet.Click += new System.EventHandler(this.btnDDPukSet_Click);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(215, 325);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(29, 13);
            this.label64.TabIndex = 36;
            this.label64.Text = "PUK";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(380, 322);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(77, 13);
            this.label62.TabIndex = 38;
            this.label62.Text = "__p2 (new pin)";
            // 
            // textDDSetPIN_PUK
            // 
            this.textDDSetPIN_PUK.Location = new System.Drawing.Point(252, 322);
            this.textDDSetPIN_PUK.Name = "textDDSetPIN_PUK";
            this.textDDSetPIN_PUK.Size = new System.Drawing.Size(86, 20);
            this.textDDSetPIN_PUK.TabIndex = 37;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(349, 292);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(108, 13);
            this.label60.TabIndex = 33;
            this.label60.Text = "__p2 (new password)";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(139, 295);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(110, 13);
            this.label58.TabIndex = 31;
            this.label58.Text = "oldKey (old password)";
            // 
            // textDDSetPIN_p2
            // 
            this.textDDSetPIN_p2.Location = new System.Drawing.Point(465, 322);
            this.textDDSetPIN_p2.Name = "textDDSetPIN_p2";
            this.textDDSetPIN_p2.Size = new System.Drawing.Size(86, 20);
            this.textDDSetPIN_p2.TabIndex = 39;
            // 
            // textDDSetEncriptionPasswordoldKey
            // 
            this.textDDSetEncriptionPasswordoldKey.Location = new System.Drawing.Point(255, 292);
            this.textDDSetEncriptionPasswordoldKey.Name = "textDDSetEncriptionPasswordoldKey";
            this.textDDSetEncriptionPasswordoldKey.Size = new System.Drawing.Size(86, 20);
            this.textDDSetEncriptionPasswordoldKey.TabIndex = 32;
            // 
            // btnDDSetPIN
            // 
            this.btnDDSetPIN.Location = new System.Drawing.Point(559, 320);
            this.btnDDSetPIN.Name = "btnDDSetPIN";
            this.btnDDSetPIN.Size = new System.Drawing.Size(140, 22);
            this.btnDDSetPIN.TabIndex = 40;
            this.btnDDSetPIN.Text = "set_PIN";
            this.btnDDSetPIN.UseVisualStyleBackColor = true;
            this.btnDDSetPIN.Click += new System.EventHandler(this.btnDDSetPIN_Click);
            // 
            // textDDSetEncriptionPasswordp2
            // 
            this.textDDSetEncriptionPasswordp2.Location = new System.Drawing.Point(465, 292);
            this.textDDSetEncriptionPasswordp2.Name = "textDDSetEncriptionPasswordp2";
            this.textDDSetEncriptionPasswordp2.Size = new System.Drawing.Size(86, 20);
            this.textDDSetEncriptionPasswordp2.TabIndex = 34;
            // 
            // WelcomeScreenHashGetButton
            // 
            this.WelcomeScreenHashGetButton.Location = new System.Drawing.Point(557, 406);
            this.WelcomeScreenHashGetButton.Name = "WelcomeScreenHashGetButton";
            this.WelcomeScreenHashGetButton.Size = new System.Drawing.Size(140, 22);
            this.WelcomeScreenHashGetButton.TabIndex = 44;
            this.WelcomeScreenHashGetButton.Text = "WelcomeScreenHash";
            this.WelcomeScreenHashGetButton.UseVisualStyleBackColor = true;
            this.WelcomeScreenHashGetButton.Click += new System.EventHandler(this.WelcomeScreenHashGetButton_Click);
            // 
            // ResetToFactoryDefaultsButton
            // 
            this.ResetToFactoryDefaultsButton.Location = new System.Drawing.Point(557, 378);
            this.ResetToFactoryDefaultsButton.Name = "ResetToFactoryDefaultsButton";
            this.ResetToFactoryDefaultsButton.Size = new System.Drawing.Size(140, 22);
            this.ResetToFactoryDefaultsButton.TabIndex = 42;
            this.ResetToFactoryDefaultsButton.Text = "ResetToFactoryDefaults";
            this.ResetToFactoryDefaultsButton.UseVisualStyleBackColor = true;
            this.ResetToFactoryDefaultsButton.Click += new System.EventHandler(this.ResetToFactoryDefaultsButton_Click);
            // 
            // btnDDSynchronizeDateTime
            // 
            this.btnDDSynchronizeDateTime.Location = new System.Drawing.Point(558, 350);
            this.btnDDSynchronizeDateTime.Name = "btnDDSynchronizeDateTime";
            this.btnDDSynchronizeDateTime.Size = new System.Drawing.Size(140, 22);
            this.btnDDSynchronizeDateTime.TabIndex = 41;
            this.btnDDSynchronizeDateTime.Text = "SynchronizeDateTime";
            this.btnDDSynchronizeDateTime.UseVisualStyleBackColor = true;
            this.btnDDSynchronizeDateTime.Click += new System.EventHandler(this.btnDDSynchronizeDateTime_Click);
            // 
            // btnDDSetEncryptionPassword
            // 
            this.btnDDSetEncryptionPassword.Location = new System.Drawing.Point(559, 290);
            this.btnDDSetEncryptionPassword.Name = "btnDDSetEncryptionPassword";
            this.btnDDSetEncryptionPassword.Size = new System.Drawing.Size(140, 22);
            this.btnDDSetEncryptionPassword.TabIndex = 35;
            this.btnDDSetEncryptionPassword.Text = "set_EncryptionPassword";
            this.btnDDSetEncryptionPassword.UseVisualStyleBackColor = true;
            this.btnDDSetEncryptionPassword.Click += new System.EventHandler(this.btnDDSetEncryptionPassword_Click);
            // 
            // btnDDFormatCard
            // 
            this.btnDDFormatCard.Location = new System.Drawing.Point(558, 262);
            this.btnDDFormatCard.Name = "btnDDFormatCard";
            this.btnDDFormatCard.Size = new System.Drawing.Size(140, 22);
            this.btnDDFormatCard.TabIndex = 30;
            this.btnDDFormatCard.Text = "FormatCard";
            this.btnDDFormatCard.UseVisualStyleBackColor = true;
            this.btnDDFormatCard.Click += new System.EventHandler(this.btnDDFormatCard_Click);
            // 
            // numDDenableLedIndex
            // 
            this.numDDenableLedIndex.Location = new System.Drawing.Point(321, 234);
            this.numDDenableLedIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numDDenableLedIndex.Name = "numDDenableLedIndex";
            this.numDDenableLedIndex.Size = new System.Drawing.Size(65, 20);
            this.numDDenableLedIndex.TabIndex = 27;
            // 
            // cmbDDenableLed
            // 
            this.cmbDDenableLed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDDenableLed.FormattingEnabled = true;
            this.cmbDDenableLed.Location = new System.Drawing.Point(392, 235);
            this.cmbDDenableLed.Name = "cmbDDenableLed";
            this.cmbDDenableLed.Size = new System.Drawing.Size(161, 21);
            this.cmbDDenableLed.TabIndex = 28;
            this.cmbDDenableLed.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDDenableLed
            // 
            this.btnDDenableLed.Enabled = false;
            this.btnDDenableLed.Location = new System.Drawing.Point(558, 234);
            this.btnDDenableLed.Name = "btnDDenableLed";
            this.btnDDenableLed.Size = new System.Drawing.Size(140, 22);
            this.btnDDenableLed.TabIndex = 29;
            this.btnDDenableLed.Text = "EnableLED";
            this.btnDDenableLed.UseVisualStyleBackColor = true;
            this.btnDDenableLed.Click += new System.EventHandler(this.btnDDenableLed_Click);
            // 
            // cmbDDDisplaySymbol
            // 
            this.cmbDDDisplaySymbol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDDDisplaySymbol.FormattingEnabled = true;
            this.cmbDDDisplaySymbol.Location = new System.Drawing.Point(392, 209);
            this.cmbDDDisplaySymbol.Name = "cmbDDDisplaySymbol";
            this.cmbDDDisplaySymbol.Size = new System.Drawing.Size(161, 21);
            this.cmbDDDisplaySymbol.TabIndex = 25;
            this.cmbDDDisplaySymbol.SelectedIndexChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDDDisplaySymbol
            // 
            this.btnDDDisplaySymbol.Enabled = false;
            this.btnDDDisplaySymbol.Location = new System.Drawing.Point(558, 207);
            this.btnDDDisplaySymbol.Name = "btnDDDisplaySymbol";
            this.btnDDDisplaySymbol.Size = new System.Drawing.Size(140, 22);
            this.btnDDDisplaySymbol.TabIndex = 26;
            this.btnDDDisplaySymbol.Text = "DisplaySymbol";
            this.btnDDDisplaySymbol.UseVisualStyleBackColor = true;
            this.btnDDDisplaySymbol.Click += new System.EventHandler(this.btnDDDisplaySymbol_Click);
            // 
            // btnDDDisplayScreen
            // 
            this.btnDDDisplayScreen.Location = new System.Drawing.Point(559, 179);
            this.btnDDDisplayScreen.Name = "btnDDDisplayScreen";
            this.btnDDDisplayScreen.Size = new System.Drawing.Size(138, 22);
            this.btnDDDisplayScreen.TabIndex = 24;
            this.btnDDDisplayScreen.Text = "DisplayScreen";
            this.btnDDDisplayScreen.UseVisualStyleBackColor = true;
            this.btnDDDisplayScreen.Click += new System.EventHandler(this.btnDDDisplayScreen_Click);
            // 
            // btnDDDisplayScreenBrowse
            // 
            this.btnDDDisplayScreenBrowse.Location = new System.Drawing.Point(493, 179);
            this.btnDDDisplayScreenBrowse.Name = "btnDDDisplayScreenBrowse";
            this.btnDDDisplayScreenBrowse.Size = new System.Drawing.Size(58, 22);
            this.btnDDDisplayScreenBrowse.TabIndex = 23;
            this.btnDDDisplayScreenBrowse.Text = "browse";
            this.btnDDDisplayScreenBrowse.UseVisualStyleBackColor = true;
            this.btnDDDisplayScreenBrowse.Click += new System.EventHandler(this.btnDDDisplayScreenBrowse_Click);
            // 
            // textDDDisplayScreen
            // 
            this.textDDDisplayScreen.Location = new System.Drawing.Point(12, 181);
            this.textDDDisplayScreen.Name = "textDDDisplayScreen";
            this.textDDDisplayScreen.Size = new System.Drawing.Size(476, 20);
            this.textDDDisplayScreen.TabIndex = 22;
            // 
            // btnDDDeleteFile
            // 
            this.btnDDDeleteFile.Location = new System.Drawing.Point(558, 155);
            this.btnDDDeleteFile.Name = "btnDDDeleteFile";
            this.btnDDDeleteFile.Size = new System.Drawing.Size(140, 22);
            this.btnDDDeleteFile.TabIndex = 21;
            this.btnDDDeleteFile.Text = "DeleteFile";
            this.btnDDDeleteFile.UseVisualStyleBackColor = true;
            this.btnDDDeleteFile.Click += new System.EventHandler(this.btnDDDeleteFile_Click);
            // 
            // btnDDDeleteFileBrowse
            // 
            this.btnDDDeleteFileBrowse.Location = new System.Drawing.Point(494, 153);
            this.btnDDDeleteFileBrowse.Name = "btnDDDeleteFileBrowse";
            this.btnDDDeleteFileBrowse.Size = new System.Drawing.Size(58, 22);
            this.btnDDDeleteFileBrowse.TabIndex = 20;
            this.btnDDDeleteFileBrowse.Text = "browse";
            this.btnDDDeleteFileBrowse.UseVisualStyleBackColor = true;
            this.btnDDDeleteFileBrowse.Click += new System.EventHandler(this.btnDDDeleteFileBrowse_Click);
            // 
            // textDDDeleteFile
            // 
            this.textDDDeleteFile.Location = new System.Drawing.Point(12, 155);
            this.textDDDeleteFile.Name = "textDDDeleteFile";
            this.textDDDeleteFile.Size = new System.Drawing.Size(476, 20);
            this.textDDDeleteFile.TabIndex = 19;
            // 
            // WelcomeScreenHashTxt
            // 
            this.WelcomeScreenHashTxt.Location = new System.Drawing.Point(12, 407);
            this.WelcomeScreenHashTxt.Name = "WelcomeScreenHashTxt";
            this.WelcomeScreenHashTxt.ReadOnly = true;
            this.WelcomeScreenHashTxt.Size = new System.Drawing.Size(541, 20);
            this.WelcomeScreenHashTxt.TabIndex = 43;
            // 
            // textFileCount
            // 
            this.textFileCount.Location = new System.Drawing.Point(275, 67);
            this.textFileCount.Name = "textFileCount";
            this.textFileCount.ReadOnly = true;
            this.textFileCount.Size = new System.Drawing.Size(97, 20);
            this.textFileCount.TabIndex = 12;
            // 
            // btnFileCount
            // 
            this.btnFileCount.Location = new System.Drawing.Point(377, 66);
            this.btnFileCount.Name = "btnFileCount";
            this.btnFileCount.Size = new System.Drawing.Size(140, 22);
            this.btnFileCount.TabIndex = 13;
            this.btnFileCount.Text = "File Count";
            this.btnFileCount.UseVisualStyleBackColor = true;
            this.btnFileCount.Click += new System.EventHandler(this.btnFileCount_Click);
            // 
            // textFreeDiskSpace
            // 
            this.textFreeDiskSpace.Location = new System.Drawing.Point(275, 39);
            this.textFreeDiskSpace.Name = "textFreeDiskSpace";
            this.textFreeDiskSpace.ReadOnly = true;
            this.textFreeDiskSpace.Size = new System.Drawing.Size(97, 20);
            this.textFreeDiskSpace.TabIndex = 10;
            // 
            // textMacAddress
            // 
            this.textMacAddress.Location = new System.Drawing.Point(12, 92);
            this.textMacAddress.Name = "textMacAddress";
            this.textMacAddress.ReadOnly = true;
            this.textMacAddress.Size = new System.Drawing.Size(97, 20);
            this.textMacAddress.TabIndex = 6;
            // 
            // textDriveLetter
            // 
            this.textDriveLetter.Location = new System.Drawing.Point(275, 11);
            this.textDriveLetter.Name = "textDriveLetter";
            this.textDriveLetter.ReadOnly = true;
            this.textDriveLetter.Size = new System.Drawing.Size(97, 20);
            this.textDriveLetter.TabIndex = 8;
            // 
            // btnGetFreeDiskSpace
            // 
            this.btnGetFreeDiskSpace.Location = new System.Drawing.Point(377, 38);
            this.btnGetFreeDiskSpace.Name = "btnGetFreeDiskSpace";
            this.btnGetFreeDiskSpace.Size = new System.Drawing.Size(140, 22);
            this.btnGetFreeDiskSpace.TabIndex = 11;
            this.btnGetFreeDiskSpace.Text = "Free Disk Space";
            this.btnGetFreeDiskSpace.UseVisualStyleBackColor = true;
            this.btnGetFreeDiskSpace.Click += new System.EventHandler(this.btnGetFreeDiskSpace_Click);
            // 
            // btnGetMacAddress
            // 
            this.btnGetMacAddress.Location = new System.Drawing.Point(114, 92);
            this.btnGetMacAddress.Name = "btnGetMacAddress";
            this.btnGetMacAddress.Size = new System.Drawing.Size(140, 22);
            this.btnGetMacAddress.TabIndex = 7;
            this.btnGetMacAddress.Text = "MAC Address";
            this.btnGetMacAddress.UseVisualStyleBackColor = true;
            this.btnGetMacAddress.Click += new System.EventHandler(this.btnGetMacAddress_Click);
            // 
            // textFirmwareVersion
            // 
            this.textFirmwareVersion.Location = new System.Drawing.Point(12, 67);
            this.textFirmwareVersion.Name = "textFirmwareVersion";
            this.textFirmwareVersion.ReadOnly = true;
            this.textFirmwareVersion.Size = new System.Drawing.Size(97, 20);
            this.textFirmwareVersion.TabIndex = 4;
            // 
            // btmGetFirmwareVersion
            // 
            this.btmGetFirmwareVersion.Location = new System.Drawing.Point(114, 66);
            this.btmGetFirmwareVersion.Name = "btmGetFirmwareVersion";
            this.btmGetFirmwareVersion.Size = new System.Drawing.Size(140, 22);
            this.btmGetFirmwareVersion.TabIndex = 5;
            this.btmGetFirmwareVersion.Text = "Firmware Version";
            this.btmGetFirmwareVersion.UseVisualStyleBackColor = true;
            this.btmGetFirmwareVersion.Click += new System.EventHandler(this.btmGetFirmwareVersion_Click);
            // 
            // btnGetDriveLetter
            // 
            this.btnGetDriveLetter.Location = new System.Drawing.Point(377, 10);
            this.btnGetDriveLetter.Name = "btnGetDriveLetter";
            this.btnGetDriveLetter.Size = new System.Drawing.Size(140, 22);
            this.btnGetDriveLetter.TabIndex = 9;
            this.btnGetDriveLetter.Text = "Drive Letter";
            this.btnGetDriveLetter.UseVisualStyleBackColor = true;
            this.btnGetDriveLetter.Click += new System.EventHandler(this.btnGetDriveLetter_Click);
            // 
            // textBuildNumber
            // 
            this.textBuildNumber.Location = new System.Drawing.Point(12, 39);
            this.textBuildNumber.Name = "textBuildNumber";
            this.textBuildNumber.ReadOnly = true;
            this.textBuildNumber.Size = new System.Drawing.Size(97, 20);
            this.textBuildNumber.TabIndex = 2;
            // 
            // textDeviceType
            // 
            this.textDeviceType.Location = new System.Drawing.Point(12, 11);
            this.textDeviceType.Name = "textDeviceType";
            this.textDeviceType.ReadOnly = true;
            this.textDeviceType.Size = new System.Drawing.Size(97, 20);
            this.textDeviceType.TabIndex = 0;
            // 
            // btnGetBuildNumber
            // 
            this.btnGetBuildNumber.Location = new System.Drawing.Point(114, 38);
            this.btnGetBuildNumber.Name = "btnGetBuildNumber";
            this.btnGetBuildNumber.Size = new System.Drawing.Size(140, 22);
            this.btnGetBuildNumber.TabIndex = 3;
            this.btnGetBuildNumber.Text = "Build Number";
            this.btnGetBuildNumber.UseVisualStyleBackColor = true;
            this.btnGetBuildNumber.Click += new System.EventHandler(this.btnGetBuildNumber_Click);
            // 
            // btnGetDeviceType
            // 
            this.btnGetDeviceType.Location = new System.Drawing.Point(114, 10);
            this.btnGetDeviceType.Name = "btnGetDeviceType";
            this.btnGetDeviceType.Size = new System.Drawing.Size(140, 22);
            this.btnGetDeviceType.TabIndex = 1;
            this.btnGetDeviceType.Text = "DeviceType";
            this.btnGetDeviceType.UseVisualStyleBackColor = true;
            this.btnGetDeviceType.Click += new System.EventHandler(this.btnGetDeviceType_Click);
            // 
            // initializationTabPage
            // 
            this.initializationTabPage.Controls.Add(this.btnDisplaySymbolsEnabledSet);
            this.initializationTabPage.Controls.Add(this.btnDisplaySymbolsEnabledGet);
            this.initializationTabPage.Controls.Add(this.cbDisplaySymbolsEnabled);
            this.initializationTabPage.Controls.Add(this.btnDSSPro256EnabledSet);
            this.initializationTabPage.Controls.Add(this.groupBox6);
            this.initializationTabPage.Controls.Add(this.btnDSSPro256EnabledGet);
            this.initializationTabPage.Controls.Add(this.groupBox5);
            this.initializationTabPage.Controls.Add(this.cbDSSPro256Enabled);
            this.initializationTabPage.Controls.Add(this.textDeviceStatus);
            this.initializationTabPage.Controls.Add(this.btnDeviceStatus);
            this.initializationTabPage.Controls.Add(this.textBarcodeModuleStatus);
            this.initializationTabPage.Controls.Add(this.btnBarcodeModuleStatusGet);
            this.initializationTabPage.Controls.Add(this.InitializationGroupBox);
            this.initializationTabPage.Location = new System.Drawing.Point(4, 22);
            this.initializationTabPage.Name = "initializationTabPage";
            this.initializationTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.initializationTabPage.Size = new System.Drawing.Size(722, 510);
            this.initializationTabPage.TabIndex = 0;
            this.initializationTabPage.Text = "DPMCtrl";
            this.initializationTabPage.UseVisualStyleBackColor = true;
            // 
            // btnDisplaySymbolsEnabledSet
            // 
            this.btnDisplaySymbolsEnabledSet.Enabled = false;
            this.btnDisplaySymbolsEnabledSet.Location = new System.Drawing.Point(465, 412);
            this.btnDisplaySymbolsEnabledSet.Name = "btnDisplaySymbolsEnabledSet";
            this.btnDisplaySymbolsEnabledSet.Size = new System.Drawing.Size(35, 21);
            this.btnDisplaySymbolsEnabledSet.TabIndex = 12;
            this.btnDisplaySymbolsEnabledSet.Text = "set";
            this.btnDisplaySymbolsEnabledSet.UseVisualStyleBackColor = true;
            this.btnDisplaySymbolsEnabledSet.Click += new System.EventHandler(this.btnDisplaySymbolsEnabledSet_Click);
            // 
            // btnDisplaySymbolsEnabledGet
            // 
            this.btnDisplaySymbolsEnabledGet.Location = new System.Drawing.Point(428, 412);
            this.btnDisplaySymbolsEnabledGet.Name = "btnDisplaySymbolsEnabledGet";
            this.btnDisplaySymbolsEnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDisplaySymbolsEnabledGet.TabIndex = 11;
            this.btnDisplaySymbolsEnabledGet.Text = "get";
            this.btnDisplaySymbolsEnabledGet.UseVisualStyleBackColor = true;
            this.btnDisplaySymbolsEnabledGet.Click += new System.EventHandler(this.btnDisplaySymbolsEnabledGet_Click);
            // 
            // cbDisplaySymbolsEnabled
            // 
            this.cbDisplaySymbolsEnabled.AutoSize = true;
            this.cbDisplaySymbolsEnabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDisplaySymbolsEnabled.Checked = true;
            this.cbDisplaySymbolsEnabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDisplaySymbolsEnabled.Location = new System.Drawing.Point(284, 414);
            this.cbDisplaySymbolsEnabled.Name = "cbDisplaySymbolsEnabled";
            this.cbDisplaySymbolsEnabled.Size = new System.Drawing.Size(138, 17);
            this.cbDisplaySymbolsEnabled.TabIndex = 10;
            this.cbDisplaySymbolsEnabled.Text = "DisplaySymbolsEnabled";
            this.cbDisplaySymbolsEnabled.UseVisualStyleBackColor = true;
            this.cbDisplaySymbolsEnabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnDSSPro256EnabledSet
            // 
            this.btnDSSPro256EnabledSet.Enabled = false;
            this.btnDSSPro256EnabledSet.Location = new System.Drawing.Point(184, 412);
            this.btnDSSPro256EnabledSet.Name = "btnDSSPro256EnabledSet";
            this.btnDSSPro256EnabledSet.Size = new System.Drawing.Size(35, 21);
            this.btnDSSPro256EnabledSet.TabIndex = 8;
            this.btnDSSPro256EnabledSet.Text = "set";
            this.btnDSSPro256EnabledSet.UseVisualStyleBackColor = true;
            this.btnDSSPro256EnabledSet.Click += new System.EventHandler(this.btnDSSPro256EnabledSet_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.groupBox3);
            this.groupBox6.Controls.Add(this.groupBox2);
            this.groupBox6.Controls.Add(this.groupBox1);
            this.groupBox6.Controls.Add(this.label74);
            this.groupBox6.Controls.Add(this.btnStartDelayedTasks);
            this.groupBox6.Controls.Add(this.textbstrFileName);
            this.groupBox6.Controls.Add(this.btnbstrFileNameBrowse);
            this.groupBox6.Controls.Add(this.label75);
            this.groupBox6.Controls.Add(this.textbstrDestPath);
            this.groupBox6.Controls.Add(this.btnbstrDestPathBrowse);
            this.groupBox6.Controls.Add(this.btnMove);
            this.groupBox6.Controls.Add(this.btnDelete);
            this.groupBox6.Controls.Add(this.cbDelayTasks);
            this.groupBox6.Controls.Add(this.btnCopy);
            this.groupBox6.Location = new System.Drawing.Point(10, 89);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(703, 317);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbSeparateSpokenInstructionsbCreateInstruction);
            this.groupBox3.Controls.Add(this.cbSeparateSpokenInstructionsbCreateDictation);
            this.groupBox3.Controls.Add(this.btnSeparateSpokenInstructions);
            this.groupBox3.Location = new System.Drawing.Point(6, 246);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(693, 40);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            // 
            // cbSeparateSpokenInstructionsbCreateInstruction
            // 
            this.cbSeparateSpokenInstructionsbCreateInstruction.AutoSize = true;
            this.cbSeparateSpokenInstructionsbCreateInstruction.Location = new System.Drawing.Point(407, 15);
            this.cbSeparateSpokenInstructionsbCreateInstruction.Name = "cbSeparateSpokenInstructionsbCreateInstruction";
            this.cbSeparateSpokenInstructionsbCreateInstruction.Size = new System.Drawing.Size(106, 17);
            this.cbSeparateSpokenInstructionsbCreateInstruction.TabIndex = 1;
            this.cbSeparateSpokenInstructionsbCreateInstruction.Text = "CreateInstruction";
            this.cbSeparateSpokenInstructionsbCreateInstruction.UseVisualStyleBackColor = true;
            // 
            // cbSeparateSpokenInstructionsbCreateDictation
            // 
            this.cbSeparateSpokenInstructionsbCreateDictation.AutoSize = true;
            this.cbSeparateSpokenInstructionsbCreateDictation.Location = new System.Drawing.Point(301, 15);
            this.cbSeparateSpokenInstructionsbCreateDictation.Name = "cbSeparateSpokenInstructionsbCreateDictation";
            this.cbSeparateSpokenInstructionsbCreateDictation.Size = new System.Drawing.Size(105, 17);
            this.cbSeparateSpokenInstructionsbCreateDictation.TabIndex = 0;
            this.cbSeparateSpokenInstructionsbCreateDictation.Text = "bCreateDictation";
            this.cbSeparateSpokenInstructionsbCreateDictation.UseVisualStyleBackColor = true;
            // 
            // btnSeparateSpokenInstructions
            // 
            this.btnSeparateSpokenInstructions.Location = new System.Drawing.Point(527, 11);
            this.btnSeparateSpokenInstructions.Name = "btnSeparateSpokenInstructions";
            this.btnSeparateSpokenInstructions.Size = new System.Drawing.Size(163, 23);
            this.btnSeparateSpokenInstructions.TabIndex = 2;
            this.btnSeparateSpokenInstructions.Text = "SeparateSpokenInstructions";
            this.btnSeparateSpokenInstructions.UseVisualStyleBackColor = true;
            this.btnSeparateSpokenInstructions.Click += new System.EventHandler(this.btnSeparateSpokenInstructions_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label79);
            this.groupBox2.Controls.Add(this.textDecryptbstrPassword);
            this.groupBox2.Controls.Add(this.label76);
            this.groupBox2.Controls.Add(this.btnDecrypt);
            this.groupBox2.Controls.Add(this.cmbDecryptAudioFormat);
            this.groupBox2.Location = new System.Drawing.Point(6, 204);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(693, 40);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(4, 14);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(66, 13);
            this.label79.TabIndex = 0;
            this.label79.Text = "AudioFormat";
            // 
            // textDecryptbstrPassword
            // 
            this.textDecryptbstrPassword.Location = new System.Drawing.Point(431, 13);
            this.textDecryptbstrPassword.Name = "textDecryptbstrPassword";
            this.textDecryptbstrPassword.Size = new System.Drawing.Size(87, 20);
            this.textDecryptbstrPassword.TabIndex = 3;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(353, 16);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(72, 13);
            this.label76.TabIndex = 2;
            this.label76.Text = "bStrPassword";
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(527, 11);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(163, 23);
            this.btnDecrypt.TabIndex = 4;
            this.btnDecrypt.Text = "Decrypt";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // cmbDecryptAudioFormat
            // 
            this.cmbDecryptAudioFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDecryptAudioFormat.FormattingEnabled = true;
            this.cmbDecryptAudioFormat.Location = new System.Drawing.Point(71, 13);
            this.cmbDecryptAudioFormat.Name = "cmbDecryptAudioFormat";
            this.cmbDecryptAudioFormat.Size = new System.Drawing.Size(272, 21);
            this.cmbDecryptAudioFormat.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnDCEditCustomAudioFormat);
            this.groupBox1.Controls.Add(this.label78);
            this.groupBox1.Controls.Add(this.btnConvert);
            this.groupBox1.Controls.Add(this.cmbConvertAudioFormat);
            this.groupBox1.Location = new System.Drawing.Point(6, 163);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(693, 40);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // btnDCEditCustomAudioFormat
            // 
            this.btnDCEditCustomAudioFormat.Location = new System.Drawing.Point(356, 11);
            this.btnDCEditCustomAudioFormat.Name = "btnDCEditCustomAudioFormat";
            this.btnDCEditCustomAudioFormat.Size = new System.Drawing.Size(163, 23);
            this.btnDCEditCustomAudioFormat.TabIndex = 2;
            this.btnDCEditCustomAudioFormat.Text = "Edit WAVEFORMATEX";
            this.btnDCEditCustomAudioFormat.UseVisualStyleBackColor = true;
            this.btnDCEditCustomAudioFormat.Click += new System.EventHandler(this.btnDCEditCustomAudioFormat_Click);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(5, 16);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(66, 13);
            this.label78.TabIndex = 0;
            this.label78.Text = "AudioFormat";
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(527, 11);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(163, 23);
            this.btnConvert.TabIndex = 3;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // cmbConvertAudioFormat
            // 
            this.cmbConvertAudioFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbConvertAudioFormat.FormattingEnabled = true;
            this.cmbConvertAudioFormat.Location = new System.Drawing.Point(71, 13);
            this.cmbConvertAudioFormat.Name = "cmbConvertAudioFormat";
            this.cmbConvertAudioFormat.Size = new System.Drawing.Size(272, 21);
            this.cmbConvertAudioFormat.TabIndex = 1;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(15, 16);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(71, 13);
            this.label74.TabIndex = 0;
            this.label74.Text = "bstrFileName:";
            // 
            // btnStartDelayedTasks
            // 
            this.btnStartDelayedTasks.Location = new System.Drawing.Point(533, 288);
            this.btnStartDelayedTasks.Name = "btnStartDelayedTasks";
            this.btnStartDelayedTasks.Size = new System.Drawing.Size(163, 23);
            this.btnStartDelayedTasks.TabIndex = 13;
            this.btnStartDelayedTasks.Text = "StartDelayedTasks";
            this.btnStartDelayedTasks.UseVisualStyleBackColor = true;
            this.btnStartDelayedTasks.Click += new System.EventHandler(this.btnStartDelayedTasks_Click);
            // 
            // textbstrFileName
            // 
            this.textbstrFileName.Location = new System.Drawing.Point(92, 12);
            this.textbstrFileName.Name = "textbstrFileName";
            this.textbstrFileName.Size = new System.Drawing.Size(513, 20);
            this.textbstrFileName.TabIndex = 1;
            // 
            // btnbstrFileNameBrowse
            // 
            this.btnbstrFileNameBrowse.Location = new System.Drawing.Point(611, 11);
            this.btnbstrFileNameBrowse.Name = "btnbstrFileNameBrowse";
            this.btnbstrFileNameBrowse.Size = new System.Drawing.Size(86, 23);
            this.btnbstrFileNameBrowse.TabIndex = 2;
            this.btnbstrFileNameBrowse.Text = "Browse";
            this.btnbstrFileNameBrowse.UseVisualStyleBackColor = true;
            this.btnbstrFileNameBrowse.Click += new System.EventHandler(this.btnbstrFileNameBrowse_Click);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(15, 43);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(68, 13);
            this.label75.TabIndex = 3;
            this.label75.Text = "bstrDestPath";
            // 
            // textbstrDestPath
            // 
            this.textbstrDestPath.Location = new System.Drawing.Point(92, 39);
            this.textbstrDestPath.Name = "textbstrDestPath";
            this.textbstrDestPath.Size = new System.Drawing.Size(513, 20);
            this.textbstrDestPath.TabIndex = 4;
            // 
            // btnbstrDestPathBrowse
            // 
            this.btnbstrDestPathBrowse.Location = new System.Drawing.Point(611, 38);
            this.btnbstrDestPathBrowse.Name = "btnbstrDestPathBrowse";
            this.btnbstrDestPathBrowse.Size = new System.Drawing.Size(86, 23);
            this.btnbstrDestPathBrowse.TabIndex = 5;
            this.btnbstrDestPathBrowse.Text = "Browse";
            this.btnbstrDestPathBrowse.UseVisualStyleBackColor = true;
            this.btnbstrDestPathBrowse.Click += new System.EventHandler(this.btnbstrDestPathBrowse_Click);
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(533, 88);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(163, 23);
            this.btnMove.TabIndex = 7;
            this.btnMove.Text = "Move";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(533, 134);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(163, 23);
            this.btnDelete.TabIndex = 9;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // cbDelayTasks
            // 
            this.cbDelayTasks.AutoSize = true;
            this.cbDelayTasks.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDelayTasks.Location = new System.Drawing.Point(572, 69);
            this.cbDelayTasks.Name = "cbDelayTasks";
            this.cbDelayTasks.Size = new System.Drawing.Size(83, 17);
            this.cbDelayTasks.TabIndex = 6;
            this.cbDelayTasks.Text = "bDelayTask";
            this.cbDelayTasks.UseVisualStyleBackColor = true;
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(533, 111);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(163, 23);
            this.btnCopy.TabIndex = 8;
            this.btnCopy.Text = "Copy";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnDSSPro256EnabledGet
            // 
            this.btnDSSPro256EnabledGet.Location = new System.Drawing.Point(147, 412);
            this.btnDSSPro256EnabledGet.Name = "btnDSSPro256EnabledGet";
            this.btnDSSPro256EnabledGet.Size = new System.Drawing.Size(31, 21);
            this.btnDSSPro256EnabledGet.TabIndex = 7;
            this.btnDSSPro256EnabledGet.Text = "get";
            this.btnDSSPro256EnabledGet.UseVisualStyleBackColor = true;
            this.btnDSSPro256EnabledGet.Click += new System.EventHandler(this.btnDSSPro256EnabledGet_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnbstrFileNameBrowseNewFile);
            this.groupBox5.Controls.Add(this.textbstrFileNameNewFile);
            this.groupBox5.Controls.Add(this.label69);
            this.groupBox5.Controls.Add(this.label77);
            this.groupBox5.Controls.Add(this.textNewFilePassword);
            this.groupBox5.Controls.Add(this.cmbNewFileCompressionMode);
            this.groupBox5.Controls.Add(this.btnNewFile);
            this.groupBox5.Location = new System.Drawing.Point(9, 432);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(707, 69);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            // 
            // btnbstrFileNameBrowseNewFile
            // 
            this.btnbstrFileNameBrowseNewFile.Location = new System.Drawing.Point(611, 11);
            this.btnbstrFileNameBrowseNewFile.Name = "btnbstrFileNameBrowseNewFile";
            this.btnbstrFileNameBrowseNewFile.Size = new System.Drawing.Size(86, 23);
            this.btnbstrFileNameBrowseNewFile.TabIndex = 2;
            this.btnbstrFileNameBrowseNewFile.Text = "Browse";
            this.btnbstrFileNameBrowseNewFile.UseVisualStyleBackColor = true;
            this.btnbstrFileNameBrowseNewFile.Click += new System.EventHandler(this.btnbstrFileNameBrowseNewFile_Click);
            // 
            // textbstrFileNameNewFile
            // 
            this.textbstrFileNameNewFile.Location = new System.Drawing.Point(88, 12);
            this.textbstrFileNameNewFile.Name = "textbstrFileNameNewFile";
            this.textbstrFileNameNewFile.Size = new System.Drawing.Size(517, 20);
            this.textbstrFileNameNewFile.TabIndex = 1;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(9, 16);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(71, 13);
            this.label69.TabIndex = 0;
            this.label69.Text = "bstrFileName:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(362, 45);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(72, 13);
            this.label77.TabIndex = 4;
            this.label77.Text = "bStrPassword";
            // 
            // textNewFilePassword
            // 
            this.textNewFilePassword.Location = new System.Drawing.Point(440, 38);
            this.textNewFilePassword.Name = "textNewFilePassword";
            this.textNewFilePassword.Size = new System.Drawing.Size(87, 20);
            this.textNewFilePassword.TabIndex = 5;
            // 
            // cmbNewFileCompressionMode
            // 
            this.cmbNewFileCompressionMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNewFileCompressionMode.FormattingEnabled = true;
            this.cmbNewFileCompressionMode.Location = new System.Drawing.Point(11, 38);
            this.cmbNewFileCompressionMode.Name = "cmbNewFileCompressionMode";
            this.cmbNewFileCompressionMode.Size = new System.Drawing.Size(275, 21);
            this.cmbNewFileCompressionMode.TabIndex = 3;
            // 
            // btnNewFile
            // 
            this.btnNewFile.Location = new System.Drawing.Point(534, 37);
            this.btnNewFile.Name = "btnNewFile";
            this.btnNewFile.Size = new System.Drawing.Size(163, 23);
            this.btnNewFile.TabIndex = 6;
            this.btnNewFile.Text = "NewFile";
            this.btnNewFile.UseVisualStyleBackColor = true;
            this.btnNewFile.Click += new System.EventHandler(this.btnNewFile_Click);
            // 
            // cbDSSPro256Enabled
            // 
            this.cbDSSPro256Enabled.AutoSize = true;
            this.cbDSSPro256Enabled.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbDSSPro256Enabled.Checked = true;
            this.cbDSSPro256Enabled.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbDSSPro256Enabled.Location = new System.Drawing.Point(20, 414);
            this.cbDSSPro256Enabled.Name = "cbDSSPro256Enabled";
            this.cbDSSPro256Enabled.Size = new System.Drawing.Size(121, 17);
            this.cbDSSPro256Enabled.TabIndex = 6;
            this.cbDSSPro256Enabled.Text = "DSSPro256Enabled";
            this.cbDSSPro256Enabled.UseVisualStyleBackColor = true;
            this.cbDSSPro256Enabled.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // textDeviceStatus
            // 
            this.textDeviceStatus.Location = new System.Drawing.Point(412, 51);
            this.textDeviceStatus.Name = "textDeviceStatus";
            this.textDeviceStatus.ReadOnly = true;
            this.textDeviceStatus.Size = new System.Drawing.Size(294, 20);
            this.textDeviceStatus.TabIndex = 4;
            // 
            // btnDeviceStatus
            // 
            this.btnDeviceStatus.Location = new System.Drawing.Point(276, 51);
            this.btnDeviceStatus.Name = "btnDeviceStatus";
            this.btnDeviceStatus.Size = new System.Drawing.Size(129, 23);
            this.btnDeviceStatus.TabIndex = 3;
            this.btnDeviceStatus.Text = "DeviceStatus";
            this.btnDeviceStatus.UseVisualStyleBackColor = true;
            this.btnDeviceStatus.Click += new System.EventHandler(this.btnDeviceStatus_Click);
            // 
            // textBarcodeModuleStatus
            // 
            this.textBarcodeModuleStatus.Location = new System.Drawing.Point(411, 28);
            this.textBarcodeModuleStatus.Name = "textBarcodeModuleStatus";
            this.textBarcodeModuleStatus.ReadOnly = true;
            this.textBarcodeModuleStatus.Size = new System.Drawing.Size(295, 20);
            this.textBarcodeModuleStatus.TabIndex = 2;
            // 
            // btnBarcodeModuleStatusGet
            // 
            this.btnBarcodeModuleStatusGet.Location = new System.Drawing.Point(276, 27);
            this.btnBarcodeModuleStatusGet.Name = "btnBarcodeModuleStatusGet";
            this.btnBarcodeModuleStatusGet.Size = new System.Drawing.Size(129, 23);
            this.btnBarcodeModuleStatusGet.TabIndex = 1;
            this.btnBarcodeModuleStatusGet.Text = "BarcodeModuleStatus";
            this.btnBarcodeModuleStatusGet.UseVisualStyleBackColor = true;
            this.btnBarcodeModuleStatusGet.Click += new System.EventHandler(this.btnBarcodeModuleStatusGet_Click);
            // 
            // InitializationGroupBox
            // 
            this.InitializationGroupBox.Controls.Add(this.btnDeinitialize);
            this.InitializationGroupBox.Controls.Add(this.btnInitialize);
            this.InitializationGroupBox.Location = new System.Drawing.Point(10, 12);
            this.InitializationGroupBox.Name = "InitializationGroupBox";
            this.InitializationGroupBox.Size = new System.Drawing.Size(194, 71);
            this.InitializationGroupBox.TabIndex = 0;
            this.InitializationGroupBox.TabStop = false;
            this.InitializationGroupBox.Text = "Initialization";
            // 
            // btnDeinitialize
            // 
            this.btnDeinitialize.Location = new System.Drawing.Point(16, 39);
            this.btnDeinitialize.Name = "btnDeinitialize";
            this.btnDeinitialize.Size = new System.Drawing.Size(155, 23);
            this.btnDeinitialize.TabIndex = 1;
            this.btnDeinitialize.Text = "DeInitialize";
            this.btnDeinitialize.UseVisualStyleBackColor = true;
            this.btnDeinitialize.Click += new System.EventHandler(this.btnDeinitialize_Click);
            // 
            // btnInitialize
            // 
            this.btnInitialize.Location = new System.Drawing.Point(16, 15);
            this.btnInitialize.Name = "btnInitialize";
            this.btnInitialize.Size = new System.Drawing.Size(155, 23);
            this.btnInitialize.TabIndex = 0;
            this.btnInitialize.Text = "Initialize";
            this.btnInitialize.UseVisualStyleBackColor = true;
            this.btnInitialize.Click += new System.EventHandler(this.btnInitialize_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.initializationTabPage);
            this.tabControl1.Controls.Add(this.deviceTabPage);
            this.tabControl1.Controls.Add(this._tbBarcodeConfiguration);
            this.tabControl1.Controls.Add(this.deviceSettingsTabPage);
            this.tabControl1.Controls.Add(this.capabilitiesTabPage);
            this.tabControl1.Controls.Add(this.dpmFilesTabPage);
            this.tabControl1.Controls.Add(this.dpmFileInfoPage);
            this.tabControl1.Location = new System.Drawing.Point(8, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(730, 536);
            this.tabControl1.TabIndex = 0;
            // 
            // _tbBarcodeConfiguration
            // 
            this._tbBarcodeConfiguration.Controls.Add(this.btnGetDeviceBarcode);
            this._tbBarcodeConfiguration.Controls.Add(this.barcodeSettingsPanel);
            this._tbBarcodeConfiguration.Location = new System.Drawing.Point(4, 22);
            this._tbBarcodeConfiguration.Name = "_tbBarcodeConfiguration";
            this._tbBarcodeConfiguration.Padding = new System.Windows.Forms.Padding(3);
            this._tbBarcodeConfiguration.Size = new System.Drawing.Size(722, 510);
            this._tbBarcodeConfiguration.TabIndex = 9;
            this._tbBarcodeConfiguration.Text = "BarcodeConfiguration";
            this._tbBarcodeConfiguration.UseVisualStyleBackColor = true;
            // 
            // btnGetDeviceBarcode
            // 
            this.btnGetDeviceBarcode.Location = new System.Drawing.Point(6, 6);
            this.btnGetDeviceBarcode.Name = "btnGetDeviceBarcode";
            this.btnGetDeviceBarcode.Size = new System.Drawing.Size(113, 25);
            this.btnGetDeviceBarcode.TabIndex = 2;
            this.btnGetDeviceBarcode.Text = "Get_IDPMDevice";
            this.btnGetDeviceBarcode.UseVisualStyleBackColor = true;
            this.btnGetDeviceBarcode.Click += new System.EventHandler(this.btnGetDevice_Click);
            // 
            // barcodeSettingsPanel
            // 
            this.barcodeSettingsPanel.Controls.Add(this._dgBarcodePostfix);
            this.barcodeSettingsPanel.Controls.Add(this._dgBarcodePrefix);
            this.barcodeSettingsPanel.Controls.Add(this._lblKeyboardLayout);
            this.barcodeSettingsPanel.Controls.Add(this._txtInfo);
            this.barcodeSettingsPanel.Controls.Add(this._btnSetBarcodeConfiguration);
            this.barcodeSettingsPanel.Controls.Add(this._btnGetBarcodeConfiguration);
            this.barcodeSettingsPanel.Controls.Add(this._lblBarcodePostfix);
            this.barcodeSettingsPanel.Controls.Add(this._lblPrefixCaption);
            this.barcodeSettingsPanel.Controls.Add(this._lblKeyboardLayoutCaption);
            this.barcodeSettingsPanel.Controls.Add(this._txtLayoutID);
            this.barcodeSettingsPanel.Controls.Add(this._cbKeyboardLayout);
            this.barcodeSettingsPanel.Location = new System.Drawing.Point(20, 54);
            this.barcodeSettingsPanel.Name = "barcodeSettingsPanel";
            this.barcodeSettingsPanel.Size = new System.Drawing.Size(595, 249);
            this.barcodeSettingsPanel.TabIndex = 57;
            this.barcodeSettingsPanel.Visible = false;
            // 
            // _dgBarcodePostfix
            // 
            this._dgBarcodePostfix.AllowUserToAddRows = false;
            this._dgBarcodePostfix.AllowUserToDeleteRows = false;
            this._dgBarcodePostfix.AllowUserToResizeColumns = false;
            this._dgBarcodePostfix.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this._dgBarcodePostfix.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this._dgBarcodePostfix.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dgBarcodePostfix.ColumnHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this._dgBarcodePostfix.DefaultCellStyle = dataGridViewCellStyle2;
            this._dgBarcodePostfix.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this._dgBarcodePostfix.Location = new System.Drawing.Point(22, 187);
            this._dgBarcodePostfix.MultiSelect = false;
            this._dgBarcodePostfix.Name = "_dgBarcodePostfix";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this._dgBarcodePostfix.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this._dgBarcodePostfix.RowHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this._dgBarcodePostfix.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this._dgBarcodePostfix.Size = new System.Drawing.Size(523, 23);
            this._dgBarcodePostfix.TabIndex = 25;
            // 
            // _dgBarcodePrefix
            // 
            this._dgBarcodePrefix.AllowUserToAddRows = false;
            this._dgBarcodePrefix.AllowUserToDeleteRows = false;
            this._dgBarcodePrefix.AllowUserToResizeColumns = false;
            this._dgBarcodePrefix.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this._dgBarcodePrefix.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this._dgBarcodePrefix.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dgBarcodePrefix.ColumnHeadersVisible = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this._dgBarcodePrefix.DefaultCellStyle = dataGridViewCellStyle6;
            this._dgBarcodePrefix.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this._dgBarcodePrefix.Location = new System.Drawing.Point(22, 131);
            this._dgBarcodePrefix.MultiSelect = false;
            this._dgBarcodePrefix.Name = "_dgBarcodePrefix";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this._dgBarcodePrefix.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this._dgBarcodePrefix.RowHeadersVisible = false;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this._dgBarcodePrefix.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this._dgBarcodePrefix.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this._dgBarcodePrefix.Size = new System.Drawing.Size(523, 23);
            this._dgBarcodePrefix.TabIndex = 24;
            // 
            // _lblKeyboardLayout
            // 
            this._lblKeyboardLayout.AutoSize = true;
            this._lblKeyboardLayout.Location = new System.Drawing.Point(19, 56);
            this._lblKeyboardLayout.Name = "_lblKeyboardLayout";
            this._lblKeyboardLayout.Size = new System.Drawing.Size(87, 13);
            this._lblKeyboardLayout.TabIndex = 23;
            this._lblKeyboardLayout.Text = "KeyboardLayout:";
            // 
            // _txtInfo
            // 
            this._txtInfo.Location = new System.Drawing.Point(19, 78);
            this._txtInfo.Name = "_txtInfo";
            this._txtInfo.Size = new System.Drawing.Size(543, 27);
            this._txtInfo.TabIndex = 22;
            this._txtInfo.Text = "For prefix and postfix keycode and modifier should be provided. Please, refer to " +
    "SDK documentation for the actual values.";
            // 
            // _btnSetBarcodeConfiguration
            // 
            this._btnSetBarcodeConfiguration.Location = new System.Drawing.Point(194, 223);
            this._btnSetBarcodeConfiguration.Name = "_btnSetBarcodeConfiguration";
            this._btnSetBarcodeConfiguration.Size = new System.Drawing.Size(166, 23);
            this._btnSetBarcodeConfiguration.TabIndex = 21;
            this._btnSetBarcodeConfiguration.Text = "PutBarcodeKeyboardSettings";
            this._btnSetBarcodeConfiguration.UseVisualStyleBackColor = true;
            this._btnSetBarcodeConfiguration.Click += new System.EventHandler(this._btnSetBarcodeConfiguration_Click);
            // 
            // _btnGetBarcodeConfiguration
            // 
            this._btnGetBarcodeConfiguration.Location = new System.Drawing.Point(22, 223);
            this._btnGetBarcodeConfiguration.Name = "_btnGetBarcodeConfiguration";
            this._btnGetBarcodeConfiguration.Size = new System.Drawing.Size(166, 23);
            this._btnGetBarcodeConfiguration.TabIndex = 20;
            this._btnGetBarcodeConfiguration.Text = "GetBarcodeKeyboardSettings";
            this._btnGetBarcodeConfiguration.UseVisualStyleBackColor = true;
            this._btnGetBarcodeConfiguration.Click += new System.EventHandler(this._btnGetBarcodeConfiguration_Click);
            // 
            // _lblBarcodePostfix
            // 
            this._lblBarcodePostfix.AutoSize = true;
            this._lblBarcodePostfix.Location = new System.Drawing.Point(19, 167);
            this._lblBarcodePostfix.Name = "_lblBarcodePostfix";
            this._lblBarcodePostfix.Size = new System.Drawing.Size(81, 13);
            this._lblBarcodePostfix.TabIndex = 19;
            this._lblBarcodePostfix.Text = "BarcodePostfix:";
            // 
            // _lblPrefixCaption
            // 
            this._lblPrefixCaption.AutoSize = true;
            this._lblPrefixCaption.Location = new System.Drawing.Point(19, 111);
            this._lblPrefixCaption.Name = "_lblPrefixCaption";
            this._lblPrefixCaption.Size = new System.Drawing.Size(76, 13);
            this._lblPrefixCaption.TabIndex = 18;
            this._lblPrefixCaption.Text = "BarcodePrefix:";
            // 
            // _lblKeyboardLayoutCaption
            // 
            this._lblKeyboardLayoutCaption.AutoSize = true;
            this._lblKeyboardLayoutCaption.Location = new System.Drawing.Point(19, 29);
            this._lblKeyboardLayoutCaption.Name = "_lblKeyboardLayoutCaption";
            this._lblKeyboardLayoutCaption.Size = new System.Drawing.Size(138, 13);
            this._lblKeyboardLayoutCaption.TabIndex = 13;
            this._lblKeyboardLayoutCaption.Text = "Keyboard layout long name:";
            // 
            // _txtLayoutID
            // 
            this._txtLayoutID.Location = new System.Drawing.Point(164, 53);
            this._txtLayoutID.Name = "_txtLayoutID";
            this._txtLayoutID.Size = new System.Drawing.Size(266, 20);
            this._txtLayoutID.TabIndex = 12;
            // 
            // _cbKeyboardLayout
            // 
            this._cbKeyboardLayout.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._cbKeyboardLayout.FormattingEnabled = true;
            this._cbKeyboardLayout.Location = new System.Drawing.Point(164, 26);
            this._cbKeyboardLayout.Name = "_cbKeyboardLayout";
            this._cbKeyboardLayout.Size = new System.Drawing.Size(266, 21);
            this._cbKeyboardLayout.TabIndex = 11;
            this._cbKeyboardLayout.SelectedIndexChanged += new System.EventHandler(this._cbKeyboardLayout_SelectedIndexChanged);
            // 
            // dpmFilesTabPage
            // 
            this.dpmFilesTabPage.Controls.Add(this.btnGetIFileList);
            this.dpmFilesTabPage.Controls.Add(this.fileListPanel);
            this.dpmFilesTabPage.Location = new System.Drawing.Point(4, 22);
            this.dpmFilesTabPage.Name = "dpmFilesTabPage";
            this.dpmFilesTabPage.Size = new System.Drawing.Size(722, 510);
            this.dpmFilesTabPage.TabIndex = 8;
            this.dpmFilesTabPage.Text = "IDPMFileList";
            this.dpmFilesTabPage.UseVisualStyleBackColor = true;
            // 
            // btnGetIFileList
            // 
            this.btnGetIFileList.Location = new System.Drawing.Point(14, 15);
            this.btnGetIFileList.Name = "btnGetIFileList";
            this.btnGetIFileList.Size = new System.Drawing.Size(192, 26);
            this.btnGetIFileList.TabIndex = 13;
            this.btnGetIFileList.Text = "get _DPMControl.FileList";
            this.btnGetIFileList.UseVisualStyleBackColor = true;
            this.btnGetIFileList.Click += new System.EventHandler(this.btnGetIFileList_Click);
            // 
            // fileListPanel
            // 
            this.fileListPanel.Controls.Add(this.btnFLIDPMDeviceDriveLetterSet);
            this.fileListPanel.Controls.Add(this.btnFLSelectFile);
            this.fileListPanel.Controls.Add(this.btnFLFilesGet);
            this.fileListPanel.Controls.Add(this.cmbFLFileList);
            this.fileListPanel.Controls.Add(this.btnDSCountGet);
            this.fileListPanel.Controls.Add(this.textFLCount);
            this.fileListPanel.Controls.Add(this.btnFLPathBrowse);
            this.fileListPanel.Controls.Add(this.btnFLPathSet);
            this.fileListPanel.Controls.Add(this.btnFLPathGet);
            this.fileListPanel.Controls.Add(this.label55);
            this.fileListPanel.Controls.Add(this.textFLPath);
            this.fileListPanel.Location = new System.Drawing.Point(12, 63);
            this.fileListPanel.Name = "fileListPanel";
            this.fileListPanel.Size = new System.Drawing.Size(611, 357);
            this.fileListPanel.TabIndex = 12;
            this.fileListPanel.Visible = false;
            // 
            // btnFLIDPMDeviceDriveLetterSet
            // 
            this.btnFLIDPMDeviceDriveLetterSet.Enabled = false;
            this.btnFLIDPMDeviceDriveLetterSet.Location = new System.Drawing.Point(382, 17);
            this.btnFLIDPMDeviceDriveLetterSet.Name = "btnFLIDPMDeviceDriveLetterSet";
            this.btnFLIDPMDeviceDriveLetterSet.Size = new System.Drawing.Size(174, 22);
            this.btnFLIDPMDeviceDriveLetterSet.TabIndex = 11;
            this.btnFLIDPMDeviceDriveLetterSet.Text = "set _IDPMDevice.DriveLetter\r\n";
            this.btnFLIDPMDeviceDriveLetterSet.UseVisualStyleBackColor = true;
            this.btnFLIDPMDeviceDriveLetterSet.Click += new System.EventHandler(this.btnFLIDPMDeviceDriveLetterSet_Click);
            // 
            // btnFLSelectFile
            // 
            this.btnFLSelectFile.Location = new System.Drawing.Point(187, 98);
            this.btnFLSelectFile.Name = "btnFLSelectFile";
            this.btnFLSelectFile.Size = new System.Drawing.Size(96, 25);
            this.btnFLSelectFile.TabIndex = 10;
            this.btnFLSelectFile.Text = "GetFileInfo";
            this.btnFLSelectFile.UseVisualStyleBackColor = true;
            this.btnFLSelectFile.Click += new System.EventHandler(this.btnFLSelectFile_Click);
            // 
            // btnFLFilesGet
            // 
            this.btnFLFilesGet.Location = new System.Drawing.Point(10, 73);
            this.btnFLFilesGet.Name = "btnFLFilesGet";
            this.btnFLFilesGet.Size = new System.Drawing.Size(161, 22);
            this.btnFLFilesGet.TabIndex = 9;
            this.btnFLFilesGet.Text = "Show Files";
            this.btnFLFilesGet.UseVisualStyleBackColor = true;
            this.btnFLFilesGet.Click += new System.EventHandler(this.btnFLFilesGet_Click);
            // 
            // cmbFLFileList
            // 
            this.cmbFLFileList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cmbFLFileList.FormattingEnabled = true;
            this.cmbFLFileList.IntegralHeight = false;
            this.cmbFLFileList.Location = new System.Drawing.Point(10, 101);
            this.cmbFLFileList.Name = "cmbFLFileList";
            this.cmbFLFileList.Size = new System.Drawing.Size(161, 243);
            this.cmbFLFileList.TabIndex = 8;
            // 
            // btnDSCountGet
            // 
            this.btnDSCountGet.Location = new System.Drawing.Point(187, 73);
            this.btnDSCountGet.Name = "btnDSCountGet";
            this.btnDSCountGet.Size = new System.Drawing.Size(96, 22);
            this.btnDSCountGet.TabIndex = 7;
            this.btnDSCountGet.Text = "Count";
            this.btnDSCountGet.UseVisualStyleBackColor = true;
            this.btnDSCountGet.Click += new System.EventHandler(this.btnDSCountGet_Click);
            // 
            // textFLCount
            // 
            this.textFLCount.Location = new System.Drawing.Point(289, 75);
            this.textFLCount.Name = "textFLCount";
            this.textFLCount.ReadOnly = true;
            this.textFLCount.Size = new System.Drawing.Size(101, 20);
            this.textFLCount.TabIndex = 6;
            // 
            // btnFLPathBrowse
            // 
            this.btnFLPathBrowse.Location = new System.Drawing.Point(190, 17);
            this.btnFLPathBrowse.Name = "btnFLPathBrowse";
            this.btnFLPathBrowse.Size = new System.Drawing.Size(58, 22);
            this.btnFLPathBrowse.TabIndex = 4;
            this.btnFLPathBrowse.Text = "browse";
            this.btnFLPathBrowse.UseVisualStyleBackColor = true;
            this.btnFLPathBrowse.Click += new System.EventHandler(this.btnFLPathBrowse_Click);
            // 
            // btnFLPathSet
            // 
            this.btnFLPathSet.Location = new System.Drawing.Point(318, 17);
            this.btnFLPathSet.Name = "btnFLPathSet";
            this.btnFLPathSet.Size = new System.Drawing.Size(58, 22);
            this.btnFLPathSet.TabIndex = 3;
            this.btnFLPathSet.Text = "set";
            this.btnFLPathSet.UseVisualStyleBackColor = true;
            this.btnFLPathSet.Click += new System.EventHandler(this.btnFLPathSet_Click);
            // 
            // btnFLPathGet
            // 
            this.btnFLPathGet.Location = new System.Drawing.Point(254, 17);
            this.btnFLPathGet.Name = "btnFLPathGet";
            this.btnFLPathGet.Size = new System.Drawing.Size(58, 22);
            this.btnFLPathGet.TabIndex = 2;
            this.btnFLPathGet.Text = "get";
            this.btnFLPathGet.UseVisualStyleBackColor = true;
            this.btnFLPathGet.Click += new System.EventHandler(this.btnFLPathGet_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(10, 22);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(32, 13);
            this.label55.TabIndex = 1;
            this.label55.Text = "Path:";
            // 
            // textFLPath
            // 
            this.textFLPath.Location = new System.Drawing.Point(83, 18);
            this.textFLPath.Name = "textFLPath";
            this.textFLPath.Size = new System.Drawing.Size(101, 20);
            this.textFLPath.TabIndex = 0;
            // 
            // dpmFileInfoPage
            // 
            this.dpmFileInfoPage.Controls.Add(this.btnFIBrowse);
            this.dpmFileInfoPage.Controls.Add(this.btnFISetFile);
            this.dpmFileInfoPage.Controls.Add(this.label66);
            this.dpmFileInfoPage.Controls.Add(this.textFISourceFileNameAndPath);
            this.dpmFileInfoPage.Controls.Add(this.fileInfoPanel);
            this.dpmFileInfoPage.Location = new System.Drawing.Point(4, 22);
            this.dpmFileInfoPage.Name = "dpmFileInfoPage";
            this.dpmFileInfoPage.Size = new System.Drawing.Size(722, 510);
            this.dpmFileInfoPage.TabIndex = 10;
            this.dpmFileInfoPage.Text = "IDPMFileInfo";
            this.dpmFileInfoPage.UseVisualStyleBackColor = true;
            // 
            // btnFIBrowse
            // 
            this.btnFIBrowse.Location = new System.Drawing.Point(595, 6);
            this.btnFIBrowse.Name = "btnFIBrowse";
            this.btnFIBrowse.Size = new System.Drawing.Size(58, 22);
            this.btnFIBrowse.TabIndex = 8;
            this.btnFIBrowse.Text = "browse";
            this.btnFIBrowse.UseVisualStyleBackColor = true;
            this.btnFIBrowse.Click += new System.EventHandler(this.btnFIBrowse_Click);
            // 
            // btnFISetFile
            // 
            this.btnFISetFile.Location = new System.Drawing.Point(659, 6);
            this.btnFISetFile.Name = "btnFISetFile";
            this.btnFISetFile.Size = new System.Drawing.Size(58, 22);
            this.btnFISetFile.TabIndex = 7;
            this.btnFISetFile.Text = "set";
            this.btnFISetFile.UseVisualStyleBackColor = true;
            this.btnFISetFile.Click += new System.EventHandler(this.btnFISetFile_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(24, 8);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(32, 13);
            this.label66.TabIndex = 6;
            this.label66.Text = "Path:";
            // 
            // textFISourceFileNameAndPath
            // 
            this.textFISourceFileNameAndPath.Location = new System.Drawing.Point(97, 8);
            this.textFISourceFileNameAndPath.Name = "textFISourceFileNameAndPath";
            this.textFISourceFileNameAndPath.Size = new System.Drawing.Size(492, 20);
            this.textFISourceFileNameAndPath.TabIndex = 5;
            // 
            // fileInfoPanel
            // 
            this.fileInfoPanel.Controls.Add(this.btnFISpokenInstructionList);
            this.fileInfoPanel.Controls.Add(this.btnFIUserStringCount);
            this.fileInfoPanel.Controls.Add(this.textFIUserStringCount);
            this.fileInfoPanel.Controls.Add(this.btnFIRecordingStartTime);
            this.fileInfoPanel.Controls.Add(this.textFIRecordingStartTime);
            this.fileInfoPanel.Controls.Add(this.btnFIRecordingStartDate);
            this.fileInfoPanel.Controls.Add(this.textFIRecordingStartDate);
            this.fileInfoPanel.Controls.Add(this.btnFIRecordingEndTime);
            this.fileInfoPanel.Controls.Add(this.textFIRecordingEndTime);
            this.fileInfoPanel.Controls.Add(this.btnFIRecordingEndDate);
            this.fileInfoPanel.Controls.Add(this.textFIRecordingEndDate);
            this.fileInfoPanel.Controls.Add(this.btnFIProductId);
            this.fileInfoPanel.Controls.Add(this.textFIProductId);
            this.fileInfoPanel.Controls.Add(this.numFIPriority);
            this.fileInfoPanel.Controls.Add(this.btnFIPrioritySet);
            this.fileInfoPanel.Controls.Add(this.btnFIPriorityGet);
            this.fileInfoPanel.Controls.Add(this.btnFIMACAddress);
            this.fileInfoPanel.Controls.Add(this.textFIMACAddress);
            this.fileInfoPanel.Controls.Add(this.btnFILastModifiedTime);
            this.fileInfoPanel.Controls.Add(this.textFILastModifiedTime);
            this.fileInfoPanel.Controls.Add(this.btnFILastModifiedDate);
            this.fileInfoPanel.Controls.Add(this.textFILastModifiedDate);
            this.fileInfoPanel.Controls.Add(this.btnFIKeywordUsageCount);
            this.fileInfoPanel.Controls.Add(this.textFIKeywordUsageCount);
            this.fileInfoPanel.Controls.Add(this.btnFIKeywordContentCount);
            this.fileInfoPanel.Controls.Add(this.textFIKeywordContentCount);
            this.fileInfoPanel.Controls.Add(this.btnFIJobNumber);
            this.fileInfoPanel.Controls.Add(this.textFIJobNumber);
            this.fileInfoPanel.Controls.Add(this.btnFIIsEncrypted);
            this.fileInfoPanel.Controls.Add(this.cbFIIsEncrypted);
            this.fileInfoPanel.Controls.Add(this.btnFIInstructionLength);
            this.fileInfoPanel.Controls.Add(this.textFIInstructionLength);
            this.fileInfoPanel.Controls.Add(this.btnFIInstructionFileName);
            this.fileInfoPanel.Controls.Add(this.textFIInstructionFileName);
            this.fileInfoPanel.Controls.Add(this.label73);
            this.fileInfoPanel.Controls.Add(this.label72);
            this.fileInfoPanel.Controls.Add(this.label71);
            this.fileInfoPanel.Controls.Add(this.numFIUserStringIndex);
            this.fileInfoPanel.Controls.Add(this.numFIKeywordUsageStringIndex);
            this.fileInfoPanel.Controls.Add(this.numFIKeywordContentStringIndex);
            this.fileInfoPanel.Controls.Add(this.btnFIUserStringSet);
            this.fileInfoPanel.Controls.Add(this.btnFIUserStringGet);
            this.fileInfoPanel.Controls.Add(this.textFIUserString);
            this.fileInfoPanel.Controls.Add(this.btnFIKeywordUsageStringSet);
            this.fileInfoPanel.Controls.Add(this.btnFIKeywordUsageStringGet);
            this.fileInfoPanel.Controls.Add(this.textFIKeywordUsageString);
            this.fileInfoPanel.Controls.Add(this.btnFIKeywordContentStringSet);
            this.fileInfoPanel.Controls.Add(this.btnFIKeywordContentStringGet);
            this.fileInfoPanel.Controls.Add(this.textFIKeywordContentString);
            this.fileInfoPanel.Controls.Add(this.label68);
            this.fileInfoPanel.Controls.Add(this.btnFIInstructionFileExists);
            this.fileInfoPanel.Controls.Add(this.cbFIInstructionFileExists);
            this.fileInfoPanel.Controls.Add(this.btnFIFirmwareVersion);
            this.fileInfoPanel.Controls.Add(this.textFIFirmwareVersion);
            this.fileInfoPanel.Controls.Add(this.btnFIFileType);
            this.fileInfoPanel.Controls.Add(this.textFIFileType);
            this.fileInfoPanel.Controls.Add(this.btnFIFileName);
            this.fileInfoPanel.Controls.Add(this.textFIFileName);
            this.fileInfoPanel.Controls.Add(this.btnFIEOLSet);
            this.fileInfoPanel.Controls.Add(this.btnFIEOL);
            this.fileInfoPanel.Controls.Add(this.cbFIEOL);
            this.fileInfoPanel.Controls.Add(this.btnFIDownloadTimeSet);
            this.fileInfoPanel.Controls.Add(this.btnFIDownloadTime);
            this.fileInfoPanel.Controls.Add(this.textFIDownloadTime);
            this.fileInfoPanel.Controls.Add(this.btnFIDownloadDateSet);
            this.fileInfoPanel.Controls.Add(this.btnFIDownloadDate);
            this.fileInfoPanel.Controls.Add(this.textFIDownloadDate);
            this.fileInfoPanel.Controls.Add(this.btnFIDictationLength);
            this.fileInfoPanel.Controls.Add(this.textFIDictationLength);
            this.fileInfoPanel.Controls.Add(this.btnFICompressionMode);
            this.fileInfoPanel.Controls.Add(this.textFICompressionMode);
            this.fileInfoPanel.Controls.Add(this.btnFIAuthorSet);
            this.fileInfoPanel.Controls.Add(this.btnFIBarcodeString);
            this.fileInfoPanel.Controls.Add(this.textFIBarcodeString);
            this.fileInfoPanel.Controls.Add(this.btnFIAuthor);
            this.fileInfoPanel.Controls.Add(this.textFIAuthor);
            this.fileInfoPanel.Location = new System.Drawing.Point(5, 29);
            this.fileInfoPanel.Name = "fileInfoPanel";
            this.fileInfoPanel.Size = new System.Drawing.Size(712, 391);
            this.fileInfoPanel.TabIndex = 0;
            this.fileInfoPanel.Visible = false;
            // 
            // btnFISpokenInstructionList
            // 
            this.btnFISpokenInstructionList.Location = new System.Drawing.Point(461, 312);
            this.btnFISpokenInstructionList.Name = "btnFISpokenInstructionList";
            this.btnFISpokenInstructionList.Size = new System.Drawing.Size(123, 22);
            this.btnFISpokenInstructionList.TabIndex = 81;
            this.btnFISpokenInstructionList.Text = "SpokenInstructionList";
            this.btnFISpokenInstructionList.UseVisualStyleBackColor = true;
            this.btnFISpokenInstructionList.Click += new System.EventHandler(this.btnFISpokenInstructionList_Click);
            // 
            // btnFIUserStringCount
            // 
            this.btnFIUserStringCount.Location = new System.Drawing.Point(461, 290);
            this.btnFIUserStringCount.Name = "btnFIUserStringCount";
            this.btnFIUserStringCount.Size = new System.Drawing.Size(123, 22);
            this.btnFIUserStringCount.TabIndex = 80;
            this.btnFIUserStringCount.Text = "UserStringCount";
            this.btnFIUserStringCount.UseVisualStyleBackColor = true;
            this.btnFIUserStringCount.Click += new System.EventHandler(this.btnFIUserStringCount_Click);
            // 
            // textFIUserStringCount
            // 
            this.textFIUserStringCount.Location = new System.Drawing.Point(590, 291);
            this.textFIUserStringCount.Name = "textFIUserStringCount";
            this.textFIUserStringCount.ReadOnly = true;
            this.textFIUserStringCount.Size = new System.Drawing.Size(120, 20);
            this.textFIUserStringCount.TabIndex = 79;
            // 
            // btnFIRecordingStartTime
            // 
            this.btnFIRecordingStartTime.Location = new System.Drawing.Point(461, 268);
            this.btnFIRecordingStartTime.Name = "btnFIRecordingStartTime";
            this.btnFIRecordingStartTime.Size = new System.Drawing.Size(123, 22);
            this.btnFIRecordingStartTime.TabIndex = 78;
            this.btnFIRecordingStartTime.Text = "RecordingStartTime";
            this.btnFIRecordingStartTime.UseVisualStyleBackColor = true;
            this.btnFIRecordingStartTime.Click += new System.EventHandler(this.btnFIRecordingStartTime_Click);
            // 
            // textFIRecordingStartTime
            // 
            this.textFIRecordingStartTime.Location = new System.Drawing.Point(590, 269);
            this.textFIRecordingStartTime.Name = "textFIRecordingStartTime";
            this.textFIRecordingStartTime.ReadOnly = true;
            this.textFIRecordingStartTime.Size = new System.Drawing.Size(120, 20);
            this.textFIRecordingStartTime.TabIndex = 77;
            // 
            // btnFIRecordingStartDate
            // 
            this.btnFIRecordingStartDate.Location = new System.Drawing.Point(461, 246);
            this.btnFIRecordingStartDate.Name = "btnFIRecordingStartDate";
            this.btnFIRecordingStartDate.Size = new System.Drawing.Size(123, 22);
            this.btnFIRecordingStartDate.TabIndex = 76;
            this.btnFIRecordingStartDate.Text = "RecordingStartDate";
            this.btnFIRecordingStartDate.UseVisualStyleBackColor = true;
            this.btnFIRecordingStartDate.Click += new System.EventHandler(this.btnFIRecordingStartDate_Click);
            // 
            // textFIRecordingStartDate
            // 
            this.textFIRecordingStartDate.Location = new System.Drawing.Point(590, 247);
            this.textFIRecordingStartDate.Name = "textFIRecordingStartDate";
            this.textFIRecordingStartDate.ReadOnly = true;
            this.textFIRecordingStartDate.Size = new System.Drawing.Size(120, 20);
            this.textFIRecordingStartDate.TabIndex = 75;
            // 
            // btnFIRecordingEndTime
            // 
            this.btnFIRecordingEndTime.Location = new System.Drawing.Point(461, 224);
            this.btnFIRecordingEndTime.Name = "btnFIRecordingEndTime";
            this.btnFIRecordingEndTime.Size = new System.Drawing.Size(123, 22);
            this.btnFIRecordingEndTime.TabIndex = 74;
            this.btnFIRecordingEndTime.Text = "RecordingEndTime";
            this.btnFIRecordingEndTime.UseVisualStyleBackColor = true;
            this.btnFIRecordingEndTime.Click += new System.EventHandler(this.btnFIRecordingEndTime_Click);
            // 
            // textFIRecordingEndTime
            // 
            this.textFIRecordingEndTime.Location = new System.Drawing.Point(590, 225);
            this.textFIRecordingEndTime.Name = "textFIRecordingEndTime";
            this.textFIRecordingEndTime.ReadOnly = true;
            this.textFIRecordingEndTime.Size = new System.Drawing.Size(120, 20);
            this.textFIRecordingEndTime.TabIndex = 73;
            // 
            // btnFIRecordingEndDate
            // 
            this.btnFIRecordingEndDate.Location = new System.Drawing.Point(461, 202);
            this.btnFIRecordingEndDate.Name = "btnFIRecordingEndDate";
            this.btnFIRecordingEndDate.Size = new System.Drawing.Size(123, 22);
            this.btnFIRecordingEndDate.TabIndex = 72;
            this.btnFIRecordingEndDate.Text = "RecordingEndDate";
            this.btnFIRecordingEndDate.UseVisualStyleBackColor = true;
            this.btnFIRecordingEndDate.Click += new System.EventHandler(this.btnFIRecordingEndDate_Click);
            // 
            // textFIRecordingEndDate
            // 
            this.textFIRecordingEndDate.Location = new System.Drawing.Point(590, 203);
            this.textFIRecordingEndDate.Name = "textFIRecordingEndDate";
            this.textFIRecordingEndDate.ReadOnly = true;
            this.textFIRecordingEndDate.Size = new System.Drawing.Size(120, 20);
            this.textFIRecordingEndDate.TabIndex = 71;
            // 
            // btnFIProductId
            // 
            this.btnFIProductId.Location = new System.Drawing.Point(461, 180);
            this.btnFIProductId.Name = "btnFIProductId";
            this.btnFIProductId.Size = new System.Drawing.Size(123, 22);
            this.btnFIProductId.TabIndex = 70;
            this.btnFIProductId.Text = "ProductId";
            this.btnFIProductId.UseVisualStyleBackColor = true;
            this.btnFIProductId.Click += new System.EventHandler(this.btnFIProductId_Click);
            // 
            // textFIProductId
            // 
            this.textFIProductId.Location = new System.Drawing.Point(590, 181);
            this.textFIProductId.Name = "textFIProductId";
            this.textFIProductId.ReadOnly = true;
            this.textFIProductId.Size = new System.Drawing.Size(120, 20);
            this.textFIProductId.TabIndex = 69;
            // 
            // numFIPriority
            // 
            this.numFIPriority.Location = new System.Drawing.Point(589, 159);
            this.numFIPriority.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numFIPriority.Name = "numFIPriority";
            this.numFIPriority.Size = new System.Drawing.Size(55, 20);
            this.numFIPriority.TabIndex = 68;
            // 
            // btnFIPrioritySet
            // 
            this.btnFIPrioritySet.Location = new System.Drawing.Point(652, 158);
            this.btnFIPrioritySet.Name = "btnFIPrioritySet";
            this.btnFIPrioritySet.Size = new System.Drawing.Size(58, 22);
            this.btnFIPrioritySet.TabIndex = 67;
            this.btnFIPrioritySet.Text = "set";
            this.btnFIPrioritySet.UseVisualStyleBackColor = true;
            this.btnFIPrioritySet.Click += new System.EventHandler(this.btnFIPrioritySet_Click);
            // 
            // btnFIPriorityGet
            // 
            this.btnFIPriorityGet.Location = new System.Drawing.Point(461, 158);
            this.btnFIPriorityGet.Name = "btnFIPriorityGet";
            this.btnFIPriorityGet.Size = new System.Drawing.Size(123, 22);
            this.btnFIPriorityGet.TabIndex = 66;
            this.btnFIPriorityGet.Text = "Priority";
            this.btnFIPriorityGet.UseVisualStyleBackColor = true;
            this.btnFIPriorityGet.Click += new System.EventHandler(this.btnFIPriorityGet_Click);
            // 
            // btnFIMACAddress
            // 
            this.btnFIMACAddress.Location = new System.Drawing.Point(461, 136);
            this.btnFIMACAddress.Name = "btnFIMACAddress";
            this.btnFIMACAddress.Size = new System.Drawing.Size(123, 22);
            this.btnFIMACAddress.TabIndex = 65;
            this.btnFIMACAddress.Text = "MACAddress";
            this.btnFIMACAddress.UseVisualStyleBackColor = true;
            this.btnFIMACAddress.Click += new System.EventHandler(this.btnFIMACAddress_Click);
            // 
            // textFIMACAddress
            // 
            this.textFIMACAddress.Location = new System.Drawing.Point(590, 137);
            this.textFIMACAddress.Name = "textFIMACAddress";
            this.textFIMACAddress.ReadOnly = true;
            this.textFIMACAddress.Size = new System.Drawing.Size(120, 20);
            this.textFIMACAddress.TabIndex = 64;
            // 
            // btnFILastModifiedTime
            // 
            this.btnFILastModifiedTime.Location = new System.Drawing.Point(461, 114);
            this.btnFILastModifiedTime.Name = "btnFILastModifiedTime";
            this.btnFILastModifiedTime.Size = new System.Drawing.Size(123, 22);
            this.btnFILastModifiedTime.TabIndex = 63;
            this.btnFILastModifiedTime.Text = "LastModifiedTime";
            this.btnFILastModifiedTime.UseVisualStyleBackColor = true;
            this.btnFILastModifiedTime.Click += new System.EventHandler(this.btnFILastModifiedTime_Click);
            // 
            // textFILastModifiedTime
            // 
            this.textFILastModifiedTime.Location = new System.Drawing.Point(590, 115);
            this.textFILastModifiedTime.Name = "textFILastModifiedTime";
            this.textFILastModifiedTime.ReadOnly = true;
            this.textFILastModifiedTime.Size = new System.Drawing.Size(120, 20);
            this.textFILastModifiedTime.TabIndex = 62;
            // 
            // btnFILastModifiedDate
            // 
            this.btnFILastModifiedDate.Location = new System.Drawing.Point(461, 92);
            this.btnFILastModifiedDate.Name = "btnFILastModifiedDate";
            this.btnFILastModifiedDate.Size = new System.Drawing.Size(123, 22);
            this.btnFILastModifiedDate.TabIndex = 61;
            this.btnFILastModifiedDate.Text = "LastModifiedDate";
            this.btnFILastModifiedDate.UseVisualStyleBackColor = true;
            this.btnFILastModifiedDate.Click += new System.EventHandler(this.btnFILastModifiedDate_Click);
            // 
            // textFILastModifiedDate
            // 
            this.textFILastModifiedDate.Location = new System.Drawing.Point(590, 93);
            this.textFILastModifiedDate.Name = "textFILastModifiedDate";
            this.textFILastModifiedDate.ReadOnly = true;
            this.textFILastModifiedDate.Size = new System.Drawing.Size(120, 20);
            this.textFILastModifiedDate.TabIndex = 60;
            // 
            // btnFIKeywordUsageCount
            // 
            this.btnFIKeywordUsageCount.Location = new System.Drawing.Point(461, 70);
            this.btnFIKeywordUsageCount.Name = "btnFIKeywordUsageCount";
            this.btnFIKeywordUsageCount.Size = new System.Drawing.Size(123, 22);
            this.btnFIKeywordUsageCount.TabIndex = 59;
            this.btnFIKeywordUsageCount.Text = "KeywordUsageCount";
            this.btnFIKeywordUsageCount.UseVisualStyleBackColor = true;
            this.btnFIKeywordUsageCount.Click += new System.EventHandler(this.btnFIKeywordUsageCount_Click);
            // 
            // textFIKeywordUsageCount
            // 
            this.textFIKeywordUsageCount.Location = new System.Drawing.Point(590, 71);
            this.textFIKeywordUsageCount.Name = "textFIKeywordUsageCount";
            this.textFIKeywordUsageCount.ReadOnly = true;
            this.textFIKeywordUsageCount.Size = new System.Drawing.Size(120, 20);
            this.textFIKeywordUsageCount.TabIndex = 58;
            // 
            // btnFIKeywordContentCount
            // 
            this.btnFIKeywordContentCount.Location = new System.Drawing.Point(461, 48);
            this.btnFIKeywordContentCount.Name = "btnFIKeywordContentCount";
            this.btnFIKeywordContentCount.Size = new System.Drawing.Size(123, 22);
            this.btnFIKeywordContentCount.TabIndex = 57;
            this.btnFIKeywordContentCount.Text = "KeywordContentCount";
            this.btnFIKeywordContentCount.UseVisualStyleBackColor = true;
            this.btnFIKeywordContentCount.Click += new System.EventHandler(this.btnFIKeywordContentCount_Click);
            // 
            // textFIKeywordContentCount
            // 
            this.textFIKeywordContentCount.Location = new System.Drawing.Point(590, 49);
            this.textFIKeywordContentCount.Name = "textFIKeywordContentCount";
            this.textFIKeywordContentCount.ReadOnly = true;
            this.textFIKeywordContentCount.Size = new System.Drawing.Size(120, 20);
            this.textFIKeywordContentCount.TabIndex = 56;
            // 
            // btnFIJobNumber
            // 
            this.btnFIJobNumber.Location = new System.Drawing.Point(461, 26);
            this.btnFIJobNumber.Name = "btnFIJobNumber";
            this.btnFIJobNumber.Size = new System.Drawing.Size(123, 22);
            this.btnFIJobNumber.TabIndex = 55;
            this.btnFIJobNumber.Text = "JobNumber";
            this.btnFIJobNumber.UseVisualStyleBackColor = true;
            this.btnFIJobNumber.Click += new System.EventHandler(this.btnFIJobNumber_Click);
            // 
            // textFIJobNumber
            // 
            this.textFIJobNumber.Location = new System.Drawing.Point(590, 27);
            this.textFIJobNumber.Name = "textFIJobNumber";
            this.textFIJobNumber.ReadOnly = true;
            this.textFIJobNumber.Size = new System.Drawing.Size(120, 20);
            this.textFIJobNumber.TabIndex = 54;
            // 
            // btnFIIsEncrypted
            // 
            this.btnFIIsEncrypted.Location = new System.Drawing.Point(461, 4);
            this.btnFIIsEncrypted.Name = "btnFIIsEncrypted";
            this.btnFIIsEncrypted.Size = new System.Drawing.Size(123, 22);
            this.btnFIIsEncrypted.TabIndex = 53;
            this.btnFIIsEncrypted.Text = "IsEncrypted";
            this.btnFIIsEncrypted.UseVisualStyleBackColor = true;
            this.btnFIIsEncrypted.Click += new System.EventHandler(this.btnFIIsEncrypted_Click);
            // 
            // cbFIIsEncrypted
            // 
            this.cbFIIsEncrypted.AutoSize = true;
            this.cbFIIsEncrypted.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbFIIsEncrypted.Checked = true;
            this.cbFIIsEncrypted.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbFIIsEncrypted.Location = new System.Drawing.Point(590, 8);
            this.cbFIIsEncrypted.Name = "cbFIIsEncrypted";
            this.cbFIIsEncrypted.Size = new System.Drawing.Size(15, 14);
            this.cbFIIsEncrypted.TabIndex = 52;
            this.cbFIIsEncrypted.UseVisualStyleBackColor = true;
            // 
            // btnFIInstructionLength
            // 
            this.btnFIInstructionLength.Location = new System.Drawing.Point(3, 335);
            this.btnFIInstructionLength.Name = "btnFIInstructionLength";
            this.btnFIInstructionLength.Size = new System.Drawing.Size(123, 22);
            this.btnFIInstructionLength.TabIndex = 51;
            this.btnFIInstructionLength.Text = "InstructionLength";
            this.btnFIInstructionLength.UseVisualStyleBackColor = true;
            this.btnFIInstructionLength.Click += new System.EventHandler(this.btnFIInstructionLength_Click);
            // 
            // textFIInstructionLength
            // 
            this.textFIInstructionLength.Location = new System.Drawing.Point(132, 336);
            this.textFIInstructionLength.Name = "textFIInstructionLength";
            this.textFIInstructionLength.ReadOnly = true;
            this.textFIInstructionLength.Size = new System.Drawing.Size(171, 20);
            this.textFIInstructionLength.TabIndex = 50;
            // 
            // btnFIInstructionFileName
            // 
            this.btnFIInstructionFileName.Location = new System.Drawing.Point(3, 313);
            this.btnFIInstructionFileName.Name = "btnFIInstructionFileName";
            this.btnFIInstructionFileName.Size = new System.Drawing.Size(123, 22);
            this.btnFIInstructionFileName.TabIndex = 49;
            this.btnFIInstructionFileName.Text = "InstructionFileName";
            this.btnFIInstructionFileName.UseVisualStyleBackColor = true;
            this.btnFIInstructionFileName.Click += new System.EventHandler(this.btnFIInstructionFileName_Click);
            // 
            // textFIInstructionFileName
            // 
            this.textFIInstructionFileName.Location = new System.Drawing.Point(132, 314);
            this.textFIInstructionFileName.Name = "textFIInstructionFileName";
            this.textFIInstructionFileName.ReadOnly = true;
            this.textFIInstructionFileName.Size = new System.Drawing.Size(171, 20);
            this.textFIInstructionFileName.TabIndex = 48;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(305, 276);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(35, 13);
            this.label73.TabIndex = 47;
            this.label73.Text = "index:";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(306, 254);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(35, 13);
            this.label72.TabIndex = 46;
            this.label72.Text = "index:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(305, 232);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(35, 13);
            this.label71.TabIndex = 45;
            this.label71.Text = "index:";
            // 
            // numFIUserStringIndex
            // 
            this.numFIUserStringIndex.Location = new System.Drawing.Point(345, 272);
            this.numFIUserStringIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numFIUserStringIndex.Name = "numFIUserStringIndex";
            this.numFIUserStringIndex.Size = new System.Drawing.Size(33, 20);
            this.numFIUserStringIndex.TabIndex = 44;
            // 
            // numFIKeywordUsageStringIndex
            // 
            this.numFIKeywordUsageStringIndex.Location = new System.Drawing.Point(345, 250);
            this.numFIKeywordUsageStringIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numFIKeywordUsageStringIndex.Name = "numFIKeywordUsageStringIndex";
            this.numFIKeywordUsageStringIndex.Size = new System.Drawing.Size(33, 20);
            this.numFIKeywordUsageStringIndex.TabIndex = 43;
            // 
            // numFIKeywordContentStringIndex
            // 
            this.numFIKeywordContentStringIndex.Location = new System.Drawing.Point(344, 228);
            this.numFIKeywordContentStringIndex.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numFIKeywordContentStringIndex.Name = "numFIKeywordContentStringIndex";
            this.numFIKeywordContentStringIndex.Size = new System.Drawing.Size(33, 20);
            this.numFIKeywordContentStringIndex.TabIndex = 42;
            // 
            // btnFIUserStringSet
            // 
            this.btnFIUserStringSet.Location = new System.Drawing.Point(380, 271);
            this.btnFIUserStringSet.Name = "btnFIUserStringSet";
            this.btnFIUserStringSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIUserStringSet.TabIndex = 41;
            this.btnFIUserStringSet.Text = "set";
            this.btnFIUserStringSet.UseVisualStyleBackColor = true;
            this.btnFIUserStringSet.Click += new System.EventHandler(this.btnFIUserStringSet_Click);
            // 
            // btnFIUserStringGet
            // 
            this.btnFIUserStringGet.Location = new System.Drawing.Point(3, 269);
            this.btnFIUserStringGet.Name = "btnFIUserStringGet";
            this.btnFIUserStringGet.Size = new System.Drawing.Size(123, 22);
            this.btnFIUserStringGet.TabIndex = 40;
            this.btnFIUserStringGet.Text = "UserString";
            this.btnFIUserStringGet.UseVisualStyleBackColor = true;
            this.btnFIUserStringGet.Click += new System.EventHandler(this.btnFIUserStringGet_Click);
            // 
            // textFIUserString
            // 
            this.textFIUserString.Location = new System.Drawing.Point(132, 270);
            this.textFIUserString.Name = "textFIUserString";
            this.textFIUserString.Size = new System.Drawing.Size(171, 20);
            this.textFIUserString.TabIndex = 39;
            // 
            // btnFIKeywordUsageStringSet
            // 
            this.btnFIKeywordUsageStringSet.Location = new System.Drawing.Point(380, 249);
            this.btnFIKeywordUsageStringSet.Name = "btnFIKeywordUsageStringSet";
            this.btnFIKeywordUsageStringSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIKeywordUsageStringSet.TabIndex = 37;
            this.btnFIKeywordUsageStringSet.Text = "set";
            this.btnFIKeywordUsageStringSet.UseVisualStyleBackColor = true;
            this.btnFIKeywordUsageStringSet.Click += new System.EventHandler(this.btnFIKeywordUsageStringSet_Click);
            // 
            // btnFIKeywordUsageStringGet
            // 
            this.btnFIKeywordUsageStringGet.Location = new System.Drawing.Point(3, 247);
            this.btnFIKeywordUsageStringGet.Name = "btnFIKeywordUsageStringGet";
            this.btnFIKeywordUsageStringGet.Size = new System.Drawing.Size(123, 22);
            this.btnFIKeywordUsageStringGet.TabIndex = 36;
            this.btnFIKeywordUsageStringGet.Text = "KeywordUsageString";
            this.btnFIKeywordUsageStringGet.UseVisualStyleBackColor = true;
            this.btnFIKeywordUsageStringGet.Click += new System.EventHandler(this.btnFIKeywordUsageStringGet_Click);
            // 
            // textFIKeywordUsageString
            // 
            this.textFIKeywordUsageString.Location = new System.Drawing.Point(132, 248);
            this.textFIKeywordUsageString.Name = "textFIKeywordUsageString";
            this.textFIKeywordUsageString.Size = new System.Drawing.Size(171, 20);
            this.textFIKeywordUsageString.TabIndex = 35;
            // 
            // btnFIKeywordContentStringSet
            // 
            this.btnFIKeywordContentStringSet.Location = new System.Drawing.Point(380, 227);
            this.btnFIKeywordContentStringSet.Name = "btnFIKeywordContentStringSet";
            this.btnFIKeywordContentStringSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIKeywordContentStringSet.TabIndex = 33;
            this.btnFIKeywordContentStringSet.Text = "set";
            this.btnFIKeywordContentStringSet.UseVisualStyleBackColor = true;
            this.btnFIKeywordContentStringSet.Click += new System.EventHandler(this.btnFIKeywordContentStringSet_Click);
            // 
            // btnFIKeywordContentStringGet
            // 
            this.btnFIKeywordContentStringGet.Location = new System.Drawing.Point(3, 225);
            this.btnFIKeywordContentStringGet.Name = "btnFIKeywordContentStringGet";
            this.btnFIKeywordContentStringGet.Size = new System.Drawing.Size(123, 22);
            this.btnFIKeywordContentStringGet.TabIndex = 32;
            this.btnFIKeywordContentStringGet.Text = "KeywordContentString";
            this.btnFIKeywordContentStringGet.UseVisualStyleBackColor = true;
            this.btnFIKeywordContentStringGet.Click += new System.EventHandler(this.btnFIKeywordContentStringGet_Click);
            // 
            // textFIKeywordContentString
            // 
            this.textFIKeywordContentString.Location = new System.Drawing.Point(132, 226);
            this.textFIKeywordContentString.Name = "textFIKeywordContentString";
            this.textFIKeywordContentString.Size = new System.Drawing.Size(171, 20);
            this.textFIKeywordContentString.TabIndex = 31;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(21, 243);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(0, 13);
            this.label68.TabIndex = 30;
            // 
            // btnFIInstructionFileExists
            // 
            this.btnFIInstructionFileExists.Location = new System.Drawing.Point(3, 291);
            this.btnFIInstructionFileExists.Name = "btnFIInstructionFileExists";
            this.btnFIInstructionFileExists.Size = new System.Drawing.Size(123, 22);
            this.btnFIInstructionFileExists.TabIndex = 29;
            this.btnFIInstructionFileExists.Text = "InstructionFileExists";
            this.btnFIInstructionFileExists.UseVisualStyleBackColor = true;
            this.btnFIInstructionFileExists.Click += new System.EventHandler(this.btnFIInstructionFileExists_Click);
            // 
            // cbFIInstructionFileExists
            // 
            this.cbFIInstructionFileExists.AutoSize = true;
            this.cbFIInstructionFileExists.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbFIInstructionFileExists.Checked = true;
            this.cbFIInstructionFileExists.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbFIInstructionFileExists.Location = new System.Drawing.Point(140, 295);
            this.cbFIInstructionFileExists.Name = "cbFIInstructionFileExists";
            this.cbFIInstructionFileExists.Size = new System.Drawing.Size(15, 14);
            this.cbFIInstructionFileExists.TabIndex = 28;
            this.cbFIInstructionFileExists.UseVisualStyleBackColor = true;
            // 
            // btnFIFirmwareVersion
            // 
            this.btnFIFirmwareVersion.Location = new System.Drawing.Point(3, 203);
            this.btnFIFirmwareVersion.Name = "btnFIFirmwareVersion";
            this.btnFIFirmwareVersion.Size = new System.Drawing.Size(123, 22);
            this.btnFIFirmwareVersion.TabIndex = 27;
            this.btnFIFirmwareVersion.Text = "FirmwareVersion";
            this.btnFIFirmwareVersion.UseVisualStyleBackColor = true;
            this.btnFIFirmwareVersion.Click += new System.EventHandler(this.btnFIFirmwareVersion_Click);
            // 
            // textFIFirmwareVersion
            // 
            this.textFIFirmwareVersion.Location = new System.Drawing.Point(132, 204);
            this.textFIFirmwareVersion.Name = "textFIFirmwareVersion";
            this.textFIFirmwareVersion.ReadOnly = true;
            this.textFIFirmwareVersion.Size = new System.Drawing.Size(171, 20);
            this.textFIFirmwareVersion.TabIndex = 26;
            // 
            // btnFIFileType
            // 
            this.btnFIFileType.Location = new System.Drawing.Point(3, 181);
            this.btnFIFileType.Name = "btnFIFileType";
            this.btnFIFileType.Size = new System.Drawing.Size(123, 22);
            this.btnFIFileType.TabIndex = 25;
            this.btnFIFileType.Text = "FileType";
            this.btnFIFileType.UseVisualStyleBackColor = true;
            this.btnFIFileType.Click += new System.EventHandler(this.btnFIFileType_Click);
            // 
            // textFIFileType
            // 
            this.textFIFileType.Location = new System.Drawing.Point(132, 182);
            this.textFIFileType.Name = "textFIFileType";
            this.textFIFileType.ReadOnly = true;
            this.textFIFileType.Size = new System.Drawing.Size(171, 20);
            this.textFIFileType.TabIndex = 24;
            // 
            // btnFIFileName
            // 
            this.btnFIFileName.Location = new System.Drawing.Point(3, 159);
            this.btnFIFileName.Name = "btnFIFileName";
            this.btnFIFileName.Size = new System.Drawing.Size(123, 22);
            this.btnFIFileName.TabIndex = 23;
            this.btnFIFileName.Text = "FileName";
            this.btnFIFileName.UseVisualStyleBackColor = true;
            this.btnFIFileName.Click += new System.EventHandler(this.btnFIFileName_Click);
            // 
            // textFIFileName
            // 
            this.textFIFileName.Location = new System.Drawing.Point(132, 160);
            this.textFIFileName.Name = "textFIFileName";
            this.textFIFileName.ReadOnly = true;
            this.textFIFileName.Size = new System.Drawing.Size(171, 20);
            this.textFIFileName.TabIndex = 22;
            // 
            // btnFIEOLSet
            // 
            this.btnFIEOLSet.Enabled = false;
            this.btnFIEOLSet.Location = new System.Drawing.Point(309, 139);
            this.btnFIEOLSet.Name = "btnFIEOLSet";
            this.btnFIEOLSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIEOLSet.TabIndex = 21;
            this.btnFIEOLSet.Text = "set";
            this.btnFIEOLSet.UseVisualStyleBackColor = true;
            this.btnFIEOLSet.Click += new System.EventHandler(this.btnFIEOLSet_Click);
            // 
            // btnFIEOL
            // 
            this.btnFIEOL.Location = new System.Drawing.Point(3, 137);
            this.btnFIEOL.Name = "btnFIEOL";
            this.btnFIEOL.Size = new System.Drawing.Size(123, 22);
            this.btnFIEOL.TabIndex = 20;
            this.btnFIEOL.Text = "EOL";
            this.btnFIEOL.UseVisualStyleBackColor = true;
            this.btnFIEOL.Click += new System.EventHandler(this.btnFIEOL_Click);
            // 
            // cbFIEOL
            // 
            this.cbFIEOL.AutoSize = true;
            this.cbFIEOL.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbFIEOL.Checked = true;
            this.cbFIEOL.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.cbFIEOL.Location = new System.Drawing.Point(140, 141);
            this.cbFIEOL.Name = "cbFIEOL";
            this.cbFIEOL.Size = new System.Drawing.Size(15, 14);
            this.cbFIEOL.TabIndex = 19;
            this.cbFIEOL.UseVisualStyleBackColor = true;
            this.cbFIEOL.CheckStateChanged += new System.EventHandler(this.EnableAssociatedSetButton);
            // 
            // btnFIDownloadTimeSet
            // 
            this.btnFIDownloadTimeSet.Location = new System.Drawing.Point(309, 117);
            this.btnFIDownloadTimeSet.Name = "btnFIDownloadTimeSet";
            this.btnFIDownloadTimeSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIDownloadTimeSet.TabIndex = 18;
            this.btnFIDownloadTimeSet.Text = "set";
            this.btnFIDownloadTimeSet.UseVisualStyleBackColor = true;
            this.btnFIDownloadTimeSet.Click += new System.EventHandler(this.btnFIDownloadTimeSet_Click);
            // 
            // btnFIDownloadTime
            // 
            this.btnFIDownloadTime.Location = new System.Drawing.Point(3, 115);
            this.btnFIDownloadTime.Name = "btnFIDownloadTime";
            this.btnFIDownloadTime.Size = new System.Drawing.Size(123, 22);
            this.btnFIDownloadTime.TabIndex = 17;
            this.btnFIDownloadTime.Text = "DownloadTime";
            this.btnFIDownloadTime.UseVisualStyleBackColor = true;
            this.btnFIDownloadTime.Click += new System.EventHandler(this.btnFIDownloadTime_Click);
            // 
            // textFIDownloadTime
            // 
            this.textFIDownloadTime.Location = new System.Drawing.Point(132, 116);
            this.textFIDownloadTime.Name = "textFIDownloadTime";
            this.textFIDownloadTime.Size = new System.Drawing.Size(171, 20);
            this.textFIDownloadTime.TabIndex = 16;
            // 
            // btnFIDownloadDateSet
            // 
            this.btnFIDownloadDateSet.Location = new System.Drawing.Point(309, 95);
            this.btnFIDownloadDateSet.Name = "btnFIDownloadDateSet";
            this.btnFIDownloadDateSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIDownloadDateSet.TabIndex = 15;
            this.btnFIDownloadDateSet.Text = "set";
            this.btnFIDownloadDateSet.UseVisualStyleBackColor = true;
            this.btnFIDownloadDateSet.Click += new System.EventHandler(this.btnFIDownloadDateSet_Click);
            // 
            // btnFIDownloadDate
            // 
            this.btnFIDownloadDate.Location = new System.Drawing.Point(3, 93);
            this.btnFIDownloadDate.Name = "btnFIDownloadDate";
            this.btnFIDownloadDate.Size = new System.Drawing.Size(123, 22);
            this.btnFIDownloadDate.TabIndex = 14;
            this.btnFIDownloadDate.Text = "DownloadDate";
            this.btnFIDownloadDate.UseVisualStyleBackColor = true;
            this.btnFIDownloadDate.Click += new System.EventHandler(this.btnFIDownloadDate_Click);
            // 
            // textFIDownloadDate
            // 
            this.textFIDownloadDate.Location = new System.Drawing.Point(132, 94);
            this.textFIDownloadDate.Name = "textFIDownloadDate";
            this.textFIDownloadDate.Size = new System.Drawing.Size(171, 20);
            this.textFIDownloadDate.TabIndex = 13;
            // 
            // btnFIDictationLength
            // 
            this.btnFIDictationLength.Location = new System.Drawing.Point(3, 71);
            this.btnFIDictationLength.Name = "btnFIDictationLength";
            this.btnFIDictationLength.Size = new System.Drawing.Size(123, 22);
            this.btnFIDictationLength.TabIndex = 12;
            this.btnFIDictationLength.Text = "DictationLength";
            this.btnFIDictationLength.UseVisualStyleBackColor = true;
            this.btnFIDictationLength.Click += new System.EventHandler(this.btnFIDictationLength_Click);
            // 
            // textFIDictationLength
            // 
            this.textFIDictationLength.Location = new System.Drawing.Point(132, 72);
            this.textFIDictationLength.Name = "textFIDictationLength";
            this.textFIDictationLength.ReadOnly = true;
            this.textFIDictationLength.Size = new System.Drawing.Size(171, 20);
            this.textFIDictationLength.TabIndex = 11;
            // 
            // btnFICompressionMode
            // 
            this.btnFICompressionMode.Location = new System.Drawing.Point(3, 49);
            this.btnFICompressionMode.Name = "btnFICompressionMode";
            this.btnFICompressionMode.Size = new System.Drawing.Size(123, 22);
            this.btnFICompressionMode.TabIndex = 10;
            this.btnFICompressionMode.Text = "CompressionMode";
            this.btnFICompressionMode.UseVisualStyleBackColor = true;
            this.btnFICompressionMode.Click += new System.EventHandler(this.btnFICompressionMode_Click);
            // 
            // textFICompressionMode
            // 
            this.textFICompressionMode.Location = new System.Drawing.Point(132, 50);
            this.textFICompressionMode.Name = "textFICompressionMode";
            this.textFICompressionMode.ReadOnly = true;
            this.textFICompressionMode.Size = new System.Drawing.Size(171, 20);
            this.textFICompressionMode.TabIndex = 9;
            // 
            // btnFIAuthorSet
            // 
            this.btnFIAuthorSet.Location = new System.Drawing.Point(309, 7);
            this.btnFIAuthorSet.Name = "btnFIAuthorSet";
            this.btnFIAuthorSet.Size = new System.Drawing.Size(58, 22);
            this.btnFIAuthorSet.TabIndex = 8;
            this.btnFIAuthorSet.Text = "set";
            this.btnFIAuthorSet.UseVisualStyleBackColor = true;
            this.btnFIAuthorSet.Click += new System.EventHandler(this.btnFIAuthorSet_Click);
            // 
            // btnFIBarcodeString
            // 
            this.btnFIBarcodeString.Location = new System.Drawing.Point(3, 27);
            this.btnFIBarcodeString.Name = "btnFIBarcodeString";
            this.btnFIBarcodeString.Size = new System.Drawing.Size(123, 22);
            this.btnFIBarcodeString.TabIndex = 3;
            this.btnFIBarcodeString.Text = "BarcodeString";
            this.btnFIBarcodeString.UseVisualStyleBackColor = true;
            this.btnFIBarcodeString.Click += new System.EventHandler(this.btnFIBarcodeString_Click);
            // 
            // textFIBarcodeString
            // 
            this.textFIBarcodeString.Location = new System.Drawing.Point(132, 28);
            this.textFIBarcodeString.Name = "textFIBarcodeString";
            this.textFIBarcodeString.ReadOnly = true;
            this.textFIBarcodeString.Size = new System.Drawing.Size(171, 20);
            this.textFIBarcodeString.TabIndex = 2;
            // 
            // btnFIAuthor
            // 
            this.btnFIAuthor.Location = new System.Drawing.Point(3, 5);
            this.btnFIAuthor.Name = "btnFIAuthor";
            this.btnFIAuthor.Size = new System.Drawing.Size(123, 22);
            this.btnFIAuthor.TabIndex = 1;
            this.btnFIAuthor.Text = "Author";
            this.btnFIAuthor.UseVisualStyleBackColor = true;
            this.btnFIAuthor.Click += new System.EventHandler(this.btnFIAuthor_Click);
            // 
            // textFIAuthor
            // 
            this.textFIAuthor.Location = new System.Drawing.Point(132, 6);
            this.textFIAuthor.Name = "textFIAuthor";
            this.textFIAuthor.Size = new System.Drawing.Size(171, 20);
            this.textFIAuthor.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button8);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.button10);
            this.tabPage1.Controls.Add(this.button11);
            this.tabPage1.Controls.Add(this.button12);
            this.tabPage1.Controls.Add(this.button13);
            this.tabPage1.Controls.Add(this.button14);
            this.tabPage1.Controls.Add(this.button15);
            this.tabPage1.Controls.Add(this.button16);
            this.tabPage1.Controls.Add(this.button17);
            this.tabPage1.Controls.Add(this.button18);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.comboBox4);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.comboBox5);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.comboBox6);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.comboBox7);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.button19);
            this.tabPage1.Controls.Add(this.button20);
            this.tabPage1.Controls.Add(this.button21);
            this.tabPage1.Controls.Add(this.button22);
            this.tabPage1.Controls.Add(this.button23);
            this.tabPage1.Controls.Add(this.button24);
            this.tabPage1.Controls.Add(this.button25);
            this.tabPage1.Controls.Add(this.button26);
            this.tabPage1.Controls.Add(this.button27);
            this.tabPage1.Controls.Add(this.button28);
            this.tabPage1.Controls.Add(this.button29);
            this.tabPage1.Controls.Add(this.button30);
            this.tabPage1.Controls.Add(this.comboBox8);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.comboBox9);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.comboBox10);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.comboBox11);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.comboBox12);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.comboBox13);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.button31);
            this.tabPage1.Controls.Add(this.button32);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.comboBox14);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(623, 255);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Settings 1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(285, 165);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 13);
            this.label18.TabIndex = 127;
            this.label18.Text = "RequiredInputType";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(583, 186);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 21);
            this.button1.TabIndex = 126;
            this.button1.Text = "set";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(546, 186);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(31, 21);
            this.button2.TabIndex = 125;
            this.button2.Text = "get";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(583, 160);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 21);
            this.button7.TabIndex = 124;
            this.button7.Text = "set";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(546, 160);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(31, 21);
            this.button8.TabIndex = 123;
            this.button8.Text = "get";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(586, 133);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(35, 21);
            this.button9.TabIndex = 122;
            this.button9.Text = "set";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(549, 133);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(31, 21);
            this.button10.TabIndex = 121;
            this.button10.Text = "get";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(583, 106);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(35, 21);
            this.button11.TabIndex = 120;
            this.button11.Text = "set";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(546, 106);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(31, 21);
            this.button12.TabIndex = 119;
            this.button12.Text = "get";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(583, 73);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(35, 21);
            this.button13.TabIndex = 118;
            this.button13.Text = "set";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(546, 73);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(31, 21);
            this.button14.TabIndex = 117;
            this.button14.Text = "get";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(583, 42);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(35, 21);
            this.button15.TabIndex = 116;
            this.button15.Text = "set";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(546, 42);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(31, 21);
            this.button16.TabIndex = 115;
            this.button16.Text = "get";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(586, 15);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(35, 21);
            this.button17.TabIndex = 114;
            this.button17.Text = "set";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(549, 15);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(31, 21);
            this.button18.TabIndex = 113;
            this.button18.Text = "get";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(392, 183);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(151, 21);
            this.comboBox1.TabIndex = 112;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(314, 185);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 13);
            this.label19.TabIndex = 111;
            this.label19.Text = "TotalTimeType";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(389, 157);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(151, 21);
            this.comboBox2.TabIndex = 110;
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(389, 130);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(151, 21);
            this.comboBox3.TabIndex = 109;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(326, 133);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(83, 13);
            this.label20.TabIndex = 108;
            this.label20.Text = "RecordingMode";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(389, 103);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(151, 21);
            this.comboBox4.TabIndex = 107;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(340, 106);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(22, 13);
            this.label21.TabIndex = 106;
            this.label21.Text = "OS";
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(389, 74);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(151, 21);
            this.comboBox5.TabIndex = 105;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(277, 77);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(110, 13);
            this.label22.TabIndex = 104;
            this.label22.Text = "MicrophoneSensitivity";
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(389, 42);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(151, 21);
            this.comboBox6.TabIndex = 103;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(325, 50);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 13);
            this.label23.TabIndex = 102;
            this.label23.Text = "LowerArea";
            // 
            // comboBox7
            // 
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(392, 15);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(151, 21);
            this.comboBox7.TabIndex = 101;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(321, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 13);
            this.label24.TabIndex = 100;
            this.label24.Text = "FunctionKey";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(280, 179);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(35, 21);
            this.button19.TabIndex = 99;
            this.button19.Text = "set";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(243, 179);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(31, 21);
            this.button20.TabIndex = 98;
            this.button20.Text = "get";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(280, 151);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(35, 21);
            this.button21.TabIndex = 97;
            this.button21.Text = "set";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(243, 151);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(31, 21);
            this.button22.TabIndex = 96;
            this.button22.Text = "get";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(280, 124);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(35, 21);
            this.button23.TabIndex = 95;
            this.button23.Text = "set";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(243, 124);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(31, 21);
            this.button24.TabIndex = 94;
            this.button24.Text = "get";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(280, 95);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(35, 21);
            this.button25.TabIndex = 93;
            this.button25.Text = "set";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(243, 95);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(31, 21);
            this.button26.TabIndex = 92;
            this.button26.Text = "get";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(280, 64);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(35, 21);
            this.button27.TabIndex = 91;
            this.button27.Text = "set";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(243, 64);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(31, 21);
            this.button28.TabIndex = 90;
            this.button28.Text = "get";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(280, 40);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(35, 21);
            this.button29.TabIndex = 89;
            this.button29.Text = "set";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(243, 40);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(31, 21);
            this.button30.TabIndex = 88;
            this.button30.Text = "get";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // comboBox8
            // 
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(86, 179);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(151, 21);
            this.comboBox8.TabIndex = 86;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(18, 185);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 13);
            this.label25.TabIndex = 85;
            this.label25.Text = "FourPosSwitch";
            // 
            // comboBox9
            // 
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(86, 152);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(151, 21);
            this.comboBox9.TabIndex = 84;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(17, 157);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(98, 13);
            this.label26.TabIndex = 83;
            this.label26.Text = "FileNamePrefixTipe";
            // 
            // comboBox10
            // 
            this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(86, 125);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(151, 21);
            this.comboBox10.TabIndex = 82;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(12, 128);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(94, 13);
            this.label27.TabIndex = 81;
            this.label27.Text = "FileCounterSource";
            // 
            // comboBox11
            // 
            this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(86, 96);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(151, 21);
            this.comboBox11.TabIndex = 80;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(17, 99);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 13);
            this.label28.TabIndex = 79;
            this.label28.Text = "DateTimeFormat";
            // 
            // comboBox12
            // 
            this.comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(86, 67);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(151, 21);
            this.comboBox12.TabIndex = 78;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(14, 65);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 13);
            this.label29.TabIndex = 77;
            this.label29.Text = "BCScanButton";
            // 
            // comboBox13
            // 
            this.comboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(86, 40);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(151, 21);
            this.comboBox13.TabIndex = 76;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(12, 40);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(74, 13);
            this.label30.TabIndex = 75;
            this.label30.Text = "BarcodeMode";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(280, 12);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(35, 21);
            this.button31.TabIndex = 74;
            this.button31.Text = "set";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(243, 12);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(31, 21);
            this.button32.TabIndex = 73;
            this.button32.Text = "get";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(15, 15);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 13);
            this.label31.TabIndex = 72;
            this.label31.Text = "Appearance";
            // 
            // comboBox14
            // 
            this.comboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(86, 12);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(151, 21);
            this.comboBox14.TabIndex = 71;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button33);
            this.tabPage2.Controls.Add(this.button34);
            this.tabPage2.Controls.Add(this.checkBox1);
            this.tabPage2.Controls.Add(this.button35);
            this.tabPage2.Controls.Add(this.button36);
            this.tabPage2.Controls.Add(this.button37);
            this.tabPage2.Controls.Add(this.button38);
            this.tabPage2.Controls.Add(this.button39);
            this.tabPage2.Controls.Add(this.button40);
            this.tabPage2.Controls.Add(this.button41);
            this.tabPage2.Controls.Add(this.button42);
            this.tabPage2.Controls.Add(this.checkBox2);
            this.tabPage2.Controls.Add(this.checkBox3);
            this.tabPage2.Controls.Add(this.checkBox4);
            this.tabPage2.Controls.Add(this.checkBox5);
            this.tabPage2.Controls.Add(this.button43);
            this.tabPage2.Controls.Add(this.button44);
            this.tabPage2.Controls.Add(this.button45);
            this.tabPage2.Controls.Add(this.button46);
            this.tabPage2.Controls.Add(this.button47);
            this.tabPage2.Controls.Add(this.button48);
            this.tabPage2.Controls.Add(this.button49);
            this.tabPage2.Controls.Add(this.button50);
            this.tabPage2.Controls.Add(this.button51);
            this.tabPage2.Controls.Add(this.button52);
            this.tabPage2.Controls.Add(this.button53);
            this.tabPage2.Controls.Add(this.button54);
            this.tabPage2.Controls.Add(this.button55);
            this.tabPage2.Controls.Add(this.button56);
            this.tabPage2.Controls.Add(this.button57);
            this.tabPage2.Controls.Add(this.button58);
            this.tabPage2.Controls.Add(this.checkBox6);
            this.tabPage2.Controls.Add(this.checkBox7);
            this.tabPage2.Controls.Add(this.checkBox8);
            this.tabPage2.Controls.Add(this.checkBox9);
            this.tabPage2.Controls.Add(this.checkBox10);
            this.tabPage2.Controls.Add(this.checkBox11);
            this.tabPage2.Controls.Add(this.checkBox12);
            this.tabPage2.Controls.Add(this.checkBox13);
            this.tabPage2.Controls.Add(this.button59);
            this.tabPage2.Controls.Add(this.button60);
            this.tabPage2.Controls.Add(this.button61);
            this.tabPage2.Controls.Add(this.button62);
            this.tabPage2.Controls.Add(this.button63);
            this.tabPage2.Controls.Add(this.button64);
            this.tabPage2.Controls.Add(this.button65);
            this.tabPage2.Controls.Add(this.button66);
            this.tabPage2.Controls.Add(this.checkBox14);
            this.tabPage2.Controls.Add(this.checkBox15);
            this.tabPage2.Controls.Add(this.checkBox16);
            this.tabPage2.Controls.Add(this.checkBox17);
            this.tabPage2.Controls.Add(this.button67);
            this.tabPage2.Controls.Add(this.button68);
            this.tabPage2.Controls.Add(this.button69);
            this.tabPage2.Controls.Add(this.button70);
            this.tabPage2.Controls.Add(this.button71);
            this.tabPage2.Controls.Add(this.button72);
            this.tabPage2.Controls.Add(this.checkBox18);
            this.tabPage2.Controls.Add(this.checkBox19);
            this.tabPage2.Controls.Add(this.checkBox20);
            this.tabPage2.Controls.Add(this.button73);
            this.tabPage2.Controls.Add(this.button74);
            this.tabPage2.Controls.Add(this.checkBox21);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(623, 255);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Settings 2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(434, 209);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(35, 21);
            this.button33.TabIndex = 130;
            this.button33.Text = "set";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(397, 209);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(31, 21);
            this.button34.TabIndex = 129;
            this.button34.Text = "get";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox1.Location = new System.Drawing.Point(285, 210);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(100, 17);
            this.checkBox1.TabIndex = 128;
            this.checkBox1.Text = "VoiceActivation";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(435, 187);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(35, 21);
            this.button35.TabIndex = 127;
            this.button35.Text = "set";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(398, 187);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(31, 21);
            this.button36.TabIndex = 126;
            this.button36.Text = "get";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(435, 163);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(35, 21);
            this.button37.TabIndex = 125;
            this.button37.Text = "set";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(398, 164);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(31, 21);
            this.button38.TabIndex = 124;
            this.button38.Text = "get";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(435, 140);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(35, 21);
            this.button39.TabIndex = 123;
            this.button39.Text = "set";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(398, 140);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(31, 21);
            this.button40.TabIndex = 122;
            this.button40.Text = "get";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(435, 118);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(35, 21);
            this.button41.TabIndex = 121;
            this.button41.Text = "set";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(398, 117);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(31, 21);
            this.button42.TabIndex = 120;
            this.button42.Text = "get";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox2.Location = new System.Drawing.Point(258, 187);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(127, 17);
            this.checkBox2.TabIndex = 119;
            this.checkBox2.Text = "USBHighPowerMode";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox3.Location = new System.Drawing.Point(225, 162);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(160, 17);
            this.checkBox3.TabIndex = 118;
            this.checkBox3.Text = "ScanKeywordsFromBarcode";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox4.Location = new System.Drawing.Point(297, 140);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(88, 17);
            this.checkBox4.TabIndex = 117;
            this.checkBox4.Text = "RecordNotify";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox5.Checked = true;
            this.checkBox5.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox5.Location = new System.Drawing.Point(283, 117);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(102, 17);
            this.checkBox5.TabIndex = 116;
            this.checkBox5.Text = "RecordLevelInd";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(435, 91);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(35, 21);
            this.button43.TabIndex = 115;
            this.button43.Text = "set";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(398, 91);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(31, 21);
            this.button44.TabIndex = 114;
            this.button44.Text = "get";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(435, 68);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(35, 21);
            this.button45.TabIndex = 113;
            this.button45.Text = "set";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(398, 68);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(31, 21);
            this.button46.TabIndex = 112;
            this.button46.Text = "get";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(436, 45);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(35, 21);
            this.button47.TabIndex = 111;
            this.button47.Text = "set";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(399, 45);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(31, 21);
            this.button48.TabIndex = 110;
            this.button48.Text = "get";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(435, 23);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(35, 21);
            this.button49.TabIndex = 109;
            this.button49.Text = "set";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(399, 23);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(31, 21);
            this.button50.TabIndex = 108;
            this.button50.Text = "get";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(435, 0);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(35, 21);
            this.button51.TabIndex = 107;
            this.button51.Text = "set";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(398, 0);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(31, 21);
            this.button52.TabIndex = 106;
            this.button52.Text = "get";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(196, 229);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(35, 21);
            this.button53.TabIndex = 105;
            this.button53.Text = "set";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(159, 229);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(31, 21);
            this.button54.TabIndex = 104;
            this.button54.Text = "get";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(196, 207);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(35, 21);
            this.button55.TabIndex = 103;
            this.button55.Text = "set";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(159, 208);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(31, 21);
            this.button56.TabIndex = 102;
            this.button56.Text = "get";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(196, 185);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(35, 21);
            this.button57.TabIndex = 101;
            this.button57.Text = "set";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(159, 184);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(31, 21);
            this.button58.TabIndex = 100;
            this.button58.Text = "get";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox6.Checked = true;
            this.checkBox6.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox6.Location = new System.Drawing.Point(291, 94);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(94, 17);
            this.checkBox6.TabIndex = 99;
            this.checkBox6.Text = "ProtectDevice";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox7.Checked = true;
            this.checkBox7.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox7.Location = new System.Drawing.Point(316, 72);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(69, 17);
            this.checkBox7.TabIndex = 98;
            this.checkBox7.Text = "ProMode";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox8.Checked = true;
            this.checkBox8.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox8.Location = new System.Drawing.Point(264, 49);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(121, 17);
            this.checkBox8.TabIndex = 97;
            this.checkBox8.Text = "ProhibitFileAlteration";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox9.Checked = true;
            this.checkBox9.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox9.Location = new System.Drawing.Point(297, 27);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(88, 17);
            this.checkBox9.TabIndex = 96;
            this.checkBox9.Text = "PCMEnabled";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox10.Checked = true;
            this.checkBox10.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox10.Location = new System.Drawing.Point(323, 3);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(62, 17);
            this.checkBox10.TabIndex = 95;
            this.checkBox10.Text = "OneFile";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox11.Checked = true;
            this.checkBox11.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox11.Location = new System.Drawing.Point(51, 232);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(102, 17);
            this.checkBox11.TabIndex = 94;
            this.checkBox11.Text = "NoiseReduction";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox12.Checked = true;
            this.checkBox12.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox12.Location = new System.Drawing.Point(61, 211);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(92, 17);
            this.checkBox12.TabIndex = 93;
            this.checkBox12.Text = "LinkKeywords";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox13.Checked = true;
            this.checkBox13.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox13.Location = new System.Drawing.Point(31, 188);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(122, 17);
            this.checkBox13.TabIndex = 92;
            this.checkBox13.Text = "InsertButtonEnabled";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(196, 164);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(35, 21);
            this.button59.TabIndex = 91;
            this.button59.Text = "set";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(159, 163);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(31, 21);
            this.button60.TabIndex = 90;
            this.button60.Text = "get";
            this.button60.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(196, 141);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(35, 21);
            this.button61.TabIndex = 89;
            this.button61.Text = "set";
            this.button61.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(159, 140);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(31, 21);
            this.button62.TabIndex = 88;
            this.button62.Text = "get";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(196, 118);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(35, 21);
            this.button63.TabIndex = 87;
            this.button63.Text = "set";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(159, 118);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(31, 21);
            this.button64.TabIndex = 86;
            this.button64.Text = "get";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(196, 94);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(35, 21);
            this.button65.TabIndex = 85;
            this.button65.Text = "set";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(159, 95);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(31, 21);
            this.button66.TabIndex = 84;
            this.button66.Text = "get";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox14.Checked = true;
            this.checkBox14.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox14.Location = new System.Drawing.Point(36, 167);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(117, 17);
            this.checkBox14.TabIndex = 83;
            this.checkBox14.Text = "EOLButtonEnabled";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox15.Checked = true;
            this.checkBox15.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox15.Location = new System.Drawing.Point(45, 144);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(108, 17);
            this.checkBox15.TabIndex = 82;
            this.checkBox15.Text = "EnableUSBAudio";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox16.Checked = true;
            this.checkBox16.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox16.Location = new System.Drawing.Point(36, 121);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(117, 17);
            this.checkBox16.TabIndex = 81;
            this.checkBox16.Text = "DLSButtonEnabled";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox17.Checked = true;
            this.checkBox17.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox17.Location = new System.Drawing.Point(68, 98);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(85, 17);
            this.checkBox17.TabIndex = 80;
            this.checkBox17.Text = "DeviceBeep";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(196, 72);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(35, 21);
            this.button67.TabIndex = 79;
            this.button67.Text = "set";
            this.button67.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(159, 72);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(31, 21);
            this.button68.TabIndex = 78;
            this.button68.Text = "get";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(196, 49);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(35, 21);
            this.button69.TabIndex = 77;
            this.button69.Text = "set";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(159, 49);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(31, 21);
            this.button70.TabIndex = 76;
            this.button70.Text = "get";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(196, 25);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(35, 21);
            this.button71.TabIndex = 75;
            this.button71.Text = "set";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(159, 26);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(31, 21);
            this.button72.TabIndex = 74;
            this.button72.Text = "get";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox18.Checked = true;
            this.checkBox18.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox18.Location = new System.Drawing.Point(5, 75);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(148, 17);
            this.checkBox18.TabIndex = 73;
            this.checkBox18.Text = "DeleteFilesAfterDownload";
            this.checkBox18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox19.Checked = true;
            this.checkBox19.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox19.Location = new System.Drawing.Point(36, 52);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(117, 17);
            this.checkBox19.TabIndex = 72;
            this.checkBox19.Text = "DELButtonEnabled";
            this.checkBox19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox20.Checked = true;
            this.checkBox20.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox20.Location = new System.Drawing.Point(41, 29);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(112, 17);
            this.checkBox20.TabIndex = 71;
            this.checkBox20.Text = "CueReviewSound";
            this.checkBox20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(196, 3);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(35, 21);
            this.button73.TabIndex = 70;
            this.button73.Text = "set";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(159, 3);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(31, 21);
            this.button74.TabIndex = 69;
            this.button74.Text = "get";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.checkBox21.Checked = true;
            this.checkBox21.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox21.Location = new System.Drawing.Point(63, 6);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(90, 17);
            this.checkBox21.TabIndex = 68;
            this.checkBox21.Text = "AppendMode";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox5);
            this.tabPage3.Controls.Add(this.textBox6);
            this.tabPage3.Controls.Add(this.textBox7);
            this.tabPage3.Controls.Add(this.textBox8);
            this.tabPage3.Controls.Add(this.label32);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.label34);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(623, 255);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Settings3 ";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(69, 91);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(133, 20);
            this.textBox5.TabIndex = 7;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(69, 65);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(133, 20);
            this.textBox6.TabIndex = 6;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(69, 39);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(133, 20);
            this.textBox7.TabIndex = 5;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(69, 13);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(133, 20);
            this.textBox8.TabIndex = 4;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(15, 98);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 13);
            this.label32.TabIndex = 3;
            this.label32.Text = "label32";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(15, 68);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(41, 13);
            this.label33.TabIndex = 2;
            this.label33.Text = "label33";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(15, 42);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(15, 16);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 0;
            this.label35.Text = "label35";
            // 
            // textLog
            // 
            this.textLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textLog.Location = new System.Drawing.Point(9, 542);
            this.textLog.Name = "textLog";
            this.textLog.ReadOnly = true;
            this.textLog.Size = new System.Drawing.Size(729, 88);
            this.textLog.TabIndex = 3;
            this.textLog.Text = "";
            this.textLog.TextChanged += new System.EventHandler(this.LogTxt_TextChanged);
            // 
            // Mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 660);
            this.Controls.Add(this.textLog);
            this.Controls.Add(this.btnClearLog);
            this.Controls.Add(this.tabControl1);
            this.MinimumSize = new System.Drawing.Size(761, 659);
            this.Name = "Mainform";
            this.Text = "DPMCtrl Test";
            this.deviceSettingsTabPage.ResumeLayout(false);
            this.deviceSettingsTabPage.PerformLayout();
            this.deviceSettingsTabControl.ResumeLayout(false);
            this.deviceSettings1TabPage.ResumeLayout(false);
            this.deviceSettings1TabPage.PerformLayout();
            this.deviceSettings2TabPage.ResumeLayout(false);
            this.deviceSettings2TabPage.PerformLayout();
            this.deviceSettings3TabPage.ResumeLayout(false);
            this.deviceSettings3TabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSliderJumpBackTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUserStringCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLockTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordUsageCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordContentCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDownloadFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDownloadMode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFileCounter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDisplayKeywords)).EndInit();
            this.deviceSettings4TabPage.ResumeLayout(false);
            this.deviceSettings4TabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordContentStringUsageIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numVoiceCommandTypeIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordUsageStringIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordContentStringContentIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordVoiceCommandIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordMandatoryIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKeywordBarcodeScanIndex)).EndInit();
            this.deviceSettings5TabPage.ResumeLayout(false);
            this.deviceSettings5TabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KeywordDisplayAreaStringsIndexNum)).EndInit();
            this.deviceSettings6TabPage.ResumeLayout(false);
            this.deviceSettings6TabPage.PerformLayout();
            this.RecordingProfileGroup.ResumeLayout(false);
            this.RecordingProfileGroup.PerformLayout();
            this.capabilitiesTabPage.ResumeLayout(false);
            this.deviceCapabilitesPanel.ResumeLayout(false);
            this.deviceCapabilitesPanel.PerformLayout();
            this.deviceTabPage.ResumeLayout(false);
            this.DeviceInfoPanel.ResumeLayout(false);
            this.DeviceInfoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numDDenableLedIndex)).EndInit();
            this.initializationTabPage.ResumeLayout(false);
            this.initializationTabPage.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.InitializationGroupBox.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this._tbBarcodeConfiguration.ResumeLayout(false);
            this.barcodeSettingsPanel.ResumeLayout(false);
            this.barcodeSettingsPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dgBarcodePostfix)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._dgBarcodePrefix)).EndInit();
            this.dpmFilesTabPage.ResumeLayout(false);
            this.fileListPanel.ResumeLayout(false);
            this.fileListPanel.PerformLayout();
            this.dpmFileInfoPage.ResumeLayout(false);
            this.dpmFileInfoPage.PerformLayout();
            this.fileInfoPanel.ResumeLayout(false);
            this.fileInfoPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numFIPriority)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFIUserStringIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFIKeywordUsageStringIndex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numFIKeywordContentStringIndex)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.TabPage deviceSettingsTabPage;
        private System.Windows.Forms.Button btnPutSettingsToDevice;
        private System.Windows.Forms.Button btnGetSettingsFromDevice;
        private System.Windows.Forms.Button btnConfigFileBrowse;
        private System.Windows.Forms.TextBox textConfigFilePath;
        private System.Windows.Forms.Button btnExportConfig;
        private System.Windows.Forms.Button btnImportConfig;
        private System.Windows.Forms.TabControl deviceSettingsTabControl;
        private System.Windows.Forms.TabPage deviceSettings1TabPage;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnDSTotalTimeTypeSet;
        private System.Windows.Forms.Button btnDSTotalTimeTypeGet;
        private System.Windows.Forms.Button btnDSRequiredInputTypeSet;
        private System.Windows.Forms.Button btnDSRequiredInputTypeGet;
        private System.Windows.Forms.Button btnDSRecordingModeSet;
        private System.Windows.Forms.Button btnDSRecordingModeGet;
        private System.Windows.Forms.Button btnDSOsSet;
        private System.Windows.Forms.Button btnDSOsGet;
        private System.Windows.Forms.Button btnDSMicrophoneSensitivitySet;
        private System.Windows.Forms.Button btnDSMicrophoneSensitivityGet;
        private System.Windows.Forms.Button btnDSLowerAreaSet;
        private System.Windows.Forms.Button btnDSLowerAreaGet;
        private System.Windows.Forms.Button btnDSFunctionKeySet;
        private System.Windows.Forms.Button btnDSFunctionKeyGet;
        private System.Windows.Forms.ComboBox cmbTotalTimeType;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbRequiredInputType;
        private System.Windows.Forms.ComboBox cmbRecordingMode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbOS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbMicrophoneSensitivity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbLowerArea;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbFunctionKey;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnDSFourPosSwitchSet;
        private System.Windows.Forms.Button btnDSFourPosSwitchGet;
        private System.Windows.Forms.Button btnDSFileNamePrefixSet;
        private System.Windows.Forms.Button btnDSFileNamePrefixGet;
        private System.Windows.Forms.Button btnDSFileCounterSourceSet;
        private System.Windows.Forms.Button btnDSFileCounterSourceGet;
        private System.Windows.Forms.Button btnDSDateTimeFormatSet;
        private System.Windows.Forms.Button btnDSDateTimeFormatGet;
        private System.Windows.Forms.Button btnDSBarCodeScanButtonSet;
        private System.Windows.Forms.Button btnDSBarCodeScanButtonGet;
        private System.Windows.Forms.Button btnDSBarcodeModeSet;
        private System.Windows.Forms.Button btnDSBarcodeModeGet;
        private System.Windows.Forms.ComboBox cmbFourPosSwitch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbFileNamePrefixType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbFileCounterSource;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbDateTimeFormat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbBarcodeScanButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbBarcodeMode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDSAppearanceSet;
        private System.Windows.Forms.Button btnDSAppearanceGet;
        private System.Windows.Forms.Label AppearanceLabel;
        private System.Windows.Forms.ComboBox cmbAppearance;
        private System.Windows.Forms.TabPage deviceSettings2TabPage;
        private System.Windows.Forms.Button btnDSVoiceActivationSet;
        private System.Windows.Forms.Button btnDSVoiceActivationGet;
        private System.Windows.Forms.CheckBox cbVoiceActivation;
        private System.Windows.Forms.Button btnDSUSBHighPowerModeSet;
        private System.Windows.Forms.Button btnDSUSBHighPowerModeGet;
        private System.Windows.Forms.Button btnDSScanKeywordsFromBarcodeSet;
        private System.Windows.Forms.Button btnDSScanKeywordsFromBarcodeGet;
        private System.Windows.Forms.Button btnDSRecordNotifySet;
        private System.Windows.Forms.Button btnDSRecordNotifyGet;
        private System.Windows.Forms.Button btnDSRecordLevelSet;
        private System.Windows.Forms.Button btnDSRecordLevelGet;
        private System.Windows.Forms.CheckBox cbUSBHighPowerMode;
        private System.Windows.Forms.CheckBox cbScanKeywordsFromBarcode;
        private System.Windows.Forms.CheckBox cbRecordNotify;
        private System.Windows.Forms.CheckBox cbRecordLevelInd;
        private System.Windows.Forms.Button btnDSProtectDeviceSet;
        private System.Windows.Forms.Button btnDSProtectDeviceGet;
        private System.Windows.Forms.Button btnDSProModeSet;
        private System.Windows.Forms.Button btnDSProModeGet;
        private System.Windows.Forms.Button btnDSProhibitFileAlterationSet;
        private System.Windows.Forms.Button btnDSProhibitFileAlterationGet;
        private System.Windows.Forms.Button btnDSPCMEnabledSet;
        private System.Windows.Forms.Button btnDSPCMEnabledGet;
        private System.Windows.Forms.Button btnDSOneFileSet;
        private System.Windows.Forms.Button btnDSOneFileGet;
        private System.Windows.Forms.Button btnDSNoiseReductionSet;
        private System.Windows.Forms.Button btnDSNoiseReductionGet;
        private System.Windows.Forms.Button btnDSLinkKeywordsSet;
        private System.Windows.Forms.Button btnDSLinkKeywordsGet;
        private System.Windows.Forms.Button btnDSInsertButtonEnabledSet;
        private System.Windows.Forms.Button btnDSInsertButtonEnabledGet;
        private System.Windows.Forms.CheckBox cbProtectDevice;
        private System.Windows.Forms.CheckBox cbProMode;
        private System.Windows.Forms.CheckBox cbProhibitFileAlteration;
        private System.Windows.Forms.CheckBox cbPCMEnabled;
        private System.Windows.Forms.CheckBox cbOneFile;
        private System.Windows.Forms.CheckBox cbNoiseReduction;
        private System.Windows.Forms.CheckBox cbLinkKeywords;
        private System.Windows.Forms.CheckBox cbInsertButtonEnabled;
        private System.Windows.Forms.Button btnDSEOLButtonEnabledSet;
        private System.Windows.Forms.Button btnDSEOLButtonEnabledGet;
        private System.Windows.Forms.Button btnDSEnableUSBAudioSet;
        private System.Windows.Forms.Button btnDSEnabledUSBAudioGet;
        private System.Windows.Forms.Button btnDSDLSButtonEnabledSet;
        private System.Windows.Forms.Button btnDSDLSButtonEnabledGet;
        private System.Windows.Forms.Button btnDSDeviceBeepSet;
        private System.Windows.Forms.Button btnDSDeviceBeepGet;
        private System.Windows.Forms.CheckBox cbEOLButtonEnabled;
        private System.Windows.Forms.CheckBox cbEnableUSBAudio;
        private System.Windows.Forms.CheckBox cbDLSButtonEnabled;
        private System.Windows.Forms.CheckBox cbDeviceBeep;
        private System.Windows.Forms.Button btnDSDeleteFilesAfterDownloadSet;
        private System.Windows.Forms.Button btnDSDeleteFilesAfterDownloadGet;
        private System.Windows.Forms.Button btnDSDELButtonEnabledSet;
        private System.Windows.Forms.Button btnDSDELButtonEnabledGet;
        private System.Windows.Forms.Button btnDSCueReviewSoundSet;
        private System.Windows.Forms.Button btnDSCueReviewSoundGet;
        private System.Windows.Forms.CheckBox cbDeleteFilesAfterDownload;
        private System.Windows.Forms.CheckBox cbDELButtonEnabled;
        private System.Windows.Forms.CheckBox cbCueReviewSound;
        private System.Windows.Forms.Button btnDSAppendModeSet;
        private System.Windows.Forms.Button btnDSAppendModeGet;
        private System.Windows.Forms.CheckBox cbAppendMode;
        private System.Windows.Forms.TabPage capabilitiesTabPage;
        private System.Windows.Forms.Button btnGetDeviceCapabilities;
        private System.Windows.Forms.Panel deviceCapabilitesPanel;
        private System.Windows.Forms.TabPage deviceTabPage;
        private System.Windows.Forms.Button btnGetDevice;
        private System.Windows.Forms.Panel DeviceInfoPanel;
        private System.Windows.Forms.TextBox textFileCount;
        private System.Windows.Forms.TextBox textFreeDiskSpace;
        private System.Windows.Forms.TextBox textDriveLetter;
        private System.Windows.Forms.Button btnFileCount;
        private System.Windows.Forms.Button btnGetFreeDiskSpace;
        private System.Windows.Forms.Button btnGetDriveLetter;
        private System.Windows.Forms.TextBox textMacAddress;
        private System.Windows.Forms.Button btnGetMacAddress;
        private System.Windows.Forms.TextBox textFirmwareVersion;
        private System.Windows.Forms.Button btmGetFirmwareVersion;
        private System.Windows.Forms.TextBox textBuildNumber;
        private System.Windows.Forms.TextBox textDeviceType;
        private System.Windows.Forms.Button btnGetBuildNumber;
        private System.Windows.Forms.Button btnGetDeviceType;
        private System.Windows.Forms.TabPage initializationTabPage;
        private System.Windows.Forms.GroupBox InitializationGroupBox;
        private System.Windows.Forms.Button btnDeinitialize;
        private System.Windows.Forms.Button btnInitialize;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage deviceSettings3TabPage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textDSMACAddress;
        private System.Windows.Forms.TextBox textKeyword1String;
        private System.Windows.Forms.TextBox textDSFirmwareVersion;
        private System.Windows.Forms.TextBox textFileNamePrefixString;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button btnDSMACAddressGet;
        private System.Windows.Forms.Button btnDSKeyword1StringSet;
        private System.Windows.Forms.Button btnDSKeyword1StringGet;
        private System.Windows.Forms.Button btnDSFirmwareVersionGet;
        private System.Windows.Forms.Button btnDSFileNamePrefixStringSet;
        private System.Windows.Forms.Button btnDSFileNamePrefixStringGet;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.NumericUpDown numFileCounter;
        private System.Windows.Forms.NumericUpDown numDisplayKeywords;
        private System.Windows.Forms.NumericUpDown numDownloadMode;
        private System.Windows.Forms.NumericUpDown numDownloadFilter;
        private System.Windows.Forms.NumericUpDown numKeywordContentCount;
        private System.Windows.Forms.NumericUpDown numKeywordUsageCount;
        private System.Windows.Forms.NumericUpDown numLockTime;
        private System.Windows.Forms.Button btnDSUserStringCountSet;
        private System.Windows.Forms.Button btnDSUserStringCountGet;
        private System.Windows.Forms.Button btnDSLockTimeSet;
        private System.Windows.Forms.Button btnLockTimeGet;
        private System.Windows.Forms.Button btnDSKeywordUsageCountGet;
        private System.Windows.Forms.Button btnDSKeywordContentCountGet;
        private System.Windows.Forms.Button btnDSDownloadFilterSet;
        private System.Windows.Forms.Button btnDSDownloadFilterGet;
        private System.Windows.Forms.Button btnDSDownloadModeSet;
        private System.Windows.Forms.Button btnDSDownloadModeGet;
        private System.Windows.Forms.Button btnDSFileCounterSet;
        private System.Windows.Forms.Button btnDSFileCounterGet;
        private System.Windows.Forms.Button btnDSDisplayKeywordsSet;
        private System.Windows.Forms.Button btnDSDisplayKeywordsGet;
        private System.Windows.Forms.TabPage deviceSettings4TabPage;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button btnKeywordBarcodeScanSet;
        private System.Windows.Forms.Button btnKeywordBarcodeScanGet;
        private System.Windows.Forms.NumericUpDown numKeywordBarcodeScanIndex;
        private System.Windows.Forms.CheckBox cbKeywordBarcodeScan;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btnDSKeywordVoiceCommandSet;
        private System.Windows.Forms.Button btnDSKeywordVoiceCommandGet;
        private System.Windows.Forms.NumericUpDown numKeywordVoiceCommandIndex;
        private System.Windows.Forms.CheckBox cbKeywordVoiceCommand;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button btnKeywordMandatorySet;
        private System.Windows.Forms.Button btnKeywordMandatoryGet;
        private System.Windows.Forms.NumericUpDown numKeywordMandatoryIndex;
        private System.Windows.Forms.CheckBox cbKeywordMandatory;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textKeywordUsageString;
        private System.Windows.Forms.TextBox textKeywordContentString;
        private System.Windows.Forms.Button btnDSKeywordContentStringSet;
        private System.Windows.Forms.Button btnDSKeywordContentStringGet;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.NumericUpDown numKeywordContentStringContentIndex;
        private System.Windows.Forms.ComboBox cmbVoiceCommandType;
        private System.Windows.Forms.Button btnDSVoiceCommandTypeSet;
        private System.Windows.Forms.Button btnDSVoiceCommandTypeGet;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.NumericUpDown numVoiceCommandTypeIndex;
        private System.Windows.Forms.Button btnDSKeywordUsageStringSet;
        private System.Windows.Forms.Button btnKeywordUsageStringGet;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown numKeywordUsageStringIndex;
        private System.Windows.Forms.NumericUpDown numUserStringCount;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.NumericUpDown numKeywordContentStringUsageIndex;
        private System.Windows.Forms.ComboBox cmbDeviceCapabilitesDeviceType;
        private System.Windows.Forms.CheckBox cbDCBarcodeEvent;
        private System.Windows.Forms.Button btnDCBarcodeEventGet;
        private System.Windows.Forms.CheckBox cbDCBarcodeScanButton;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button btnDCKeywordBarcodeScanGet;
        private System.Windows.Forms.CheckBox cbDCKeywordBarcodeScan;
        private System.Windows.Forms.Button btnDCInstructionGet;
        private System.Windows.Forms.CheckBox cbDCInstruction;
        private System.Windows.Forms.Button btnDCFunctionKey;
        private System.Windows.Forms.CheckBox cbDCFunctionKey;
        private System.Windows.Forms.Button btnDCFourPosSwitchGet;
        private System.Windows.Forms.CheckBox cbDCFourPosSwitch;
        private System.Windows.Forms.Button btnDCEncryptionGet;
        private System.Windows.Forms.CheckBox cbDCEncryption;
        private System.Windows.Forms.Button btnDCKeywordContentMaxGet;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button btnDCDisplayModeCountGet;
        private System.Windows.Forms.Button btnDCKeywordsReadOnlyGet;
        private System.Windows.Forms.CheckBox cbDCKeywordsReadOnly;
        private System.Windows.Forms.Button btnDCKeywordMandatoryGet;
        private System.Windows.Forms.CheckBox cbDCKeywordMandatory;
        private System.Windows.Forms.Button btnDCPriorityGet;
        private System.Windows.Forms.CheckBox cbDCPriority;
        private System.Windows.Forms.Button btnDCLinkKeywordsGet;
        private System.Windows.Forms.CheckBox cbDCLinkKeywords;
        private System.Windows.Forms.Button btnDCKeywordVoiceCommandGet;
        private System.Windows.Forms.CheckBox cbDCKeywordVoiceCommand;
        private System.Windows.Forms.Button btnDCKeywordUsageMaxGet;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Button btnDCRequiredInputTypeGet;
        private System.Windows.Forms.CheckBox cbDCRequiredInputType;
        private System.Windows.Forms.Button btnDCQualityPlayGet;
        private System.Windows.Forms.CheckBox cbDCQualityPlay;
        private System.Windows.Forms.Button btnDCProhibitFileAlterationGet;
        private System.Windows.Forms.CheckBox cbDCProhibitFileAlteration;
        private System.Windows.Forms.Button btnDCProductIdGet;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button btnDcSecurityGet;
        private System.Windows.Forms.CheckBox cbDCSecurity;
        private System.Windows.Forms.Button btnDCScanKeywordsFromBarcodeGet;
        private System.Windows.Forms.CheckBox cbDCScanKeywordsFromBarcode;
        private System.Windows.Forms.Button btnDCVendorIdGet;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button btnDCUserStringMaxGet;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Button btnDCDeviceNameGet;
        private System.Windows.Forms.Button btnDCBarcodeScanButtonGet;
        private System.Windows.Forms.ComboBox cmbDCKeywordVoiceCommandMaxCommanfType;
        private System.Windows.Forms.Button btnDCKeywordVoiceCommandMaxGet;
        private System.Windows.Forms.TextBox textDCDeviceName;
        private System.Windows.Forms.TextBox textDcKeywordVoiceCommandMax;
        private System.Windows.Forms.TextBox textDCVendorId;
        private System.Windows.Forms.TextBox textDCUserStringMax;
        private System.Windows.Forms.TextBox textDCProductId;
        private System.Windows.Forms.TextBox textDCKeywordUsageMax;
        private System.Windows.Forms.TextBox textDCKeywordContentMax;
        private System.Windows.Forms.TextBox textDCDisplayModeCount;
        private System.Windows.Forms.TabPage dpmFilesTabPage;
        private System.Windows.Forms.Button btnFLPathBrowse;
        private System.Windows.Forms.Button btnFLPathSet;
        private System.Windows.Forms.Button btnFLPathGet;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textFLPath;
        private System.Windows.Forms.Button btnDSCountGet;
        private System.Windows.Forms.TextBox textFLCount;
        private System.Windows.Forms.Button btnFLFilesGet;
        private System.Windows.Forms.ComboBox cmbFLFileList;
        private System.Windows.Forms.Button btnDDDeleteFile;
        private System.Windows.Forms.Button btnDDDeleteFileBrowse;
        private System.Windows.Forms.TextBox textDDDeleteFile;
        private System.Windows.Forms.Button btnDDDisplayScreen;
        private System.Windows.Forms.Button btnDDDisplayScreenBrowse;
        private System.Windows.Forms.TextBox textDDDisplayScreen;
        private System.Windows.Forms.Button btnDDDisplaySymbol;
        private System.Windows.Forms.ComboBox cmbDDDisplaySymbol;
        private System.Windows.Forms.NumericUpDown numDDenableLedIndex;
        private System.Windows.Forms.ComboBox cmbDDenableLed;
        private System.Windows.Forms.Button btnDDenableLed;
        private System.Windows.Forms.Button btnDDFormatCard;
        private System.Windows.Forms.Button btnDDSetEncryptionPassword;
        private System.Windows.Forms.TextBox textDDSetEncriptionPasswordoldKey;
        private System.Windows.Forms.TextBox textDDSetEncriptionPasswordp2;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox textDDSetPIN_PUK;
        private System.Windows.Forms.TextBox textDDSetPIN_p2;
        private System.Windows.Forms.Button btnDDSetPIN;
        private System.Windows.Forms.Button btnDDSynchronizeDateTime;
        private System.Windows.Forms.TabPage _tbBarcodeConfiguration;
        private System.Windows.Forms.DataGridView _dgBarcodePostfix;
        private System.Windows.Forms.DataGridView _dgBarcodePrefix;
        private System.Windows.Forms.Label _lblKeyboardLayout;
        private System.Windows.Forms.Label _txtInfo;
        private System.Windows.Forms.Button _btnSetBarcodeConfiguration;
        private System.Windows.Forms.Button _btnGetBarcodeConfiguration;
        private System.Windows.Forms.Label _lblBarcodePostfix;
        private System.Windows.Forms.Label _lblPrefixCaption;
        private System.Windows.Forms.Label _lblKeyboardLayoutCaption;
        private System.Windows.Forms.TextBox _txtLayoutID;
        private System.Windows.Forms.ComboBox _cbKeyboardLayout;
        private System.Windows.Forms.Button btnGetDeviceBarcode;
        private System.Windows.Forms.Panel barcodeSettingsPanel;
        private System.Windows.Forms.Button btnDCGetFromIDPMDevice;
        private System.Windows.Forms.Button btnFLSelectFile;
        private System.Windows.Forms.Button btnFLIDPMDeviceDriveLetterSet;
        private System.Windows.Forms.TabPage dpmFileInfoPage;
        private System.Windows.Forms.Panel fileInfoPanel;
        private System.Windows.Forms.Button btnFIBrowse;
        private System.Windows.Forms.Button btnFISetFile;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textFISourceFileNameAndPath;
        private System.Windows.Forms.Button btnFIAuthor;
        private System.Windows.Forms.TextBox textFIAuthor;
        private System.Windows.Forms.Button btnFIBarcodeString;
        private System.Windows.Forms.TextBox textFIBarcodeString;
        private System.Windows.Forms.Button btnFICompressionMode;
        private System.Windows.Forms.TextBox textFICompressionMode;
        private System.Windows.Forms.Button btnFIAuthorSet;
        private System.Windows.Forms.Button btnFIDictationLength;
        private System.Windows.Forms.TextBox textFIDictationLength;
        private System.Windows.Forms.Button btnFIDownloadTimeSet;
        private System.Windows.Forms.Button btnFIDownloadTime;
        private System.Windows.Forms.TextBox textFIDownloadTime;
        private System.Windows.Forms.Button btnFIDownloadDateSet;
        private System.Windows.Forms.Button btnFIDownloadDate;
        private System.Windows.Forms.TextBox textFIDownloadDate;
        private System.Windows.Forms.Button btnFIEOLSet;
        private System.Windows.Forms.Button btnFIEOL;
        private System.Windows.Forms.CheckBox cbFIEOL;
        private System.Windows.Forms.Button btnFIFirmwareVersion;
        private System.Windows.Forms.TextBox textFIFirmwareVersion;
        private System.Windows.Forms.Button btnFIFileType;
        private System.Windows.Forms.TextBox textFIFileType;
        private System.Windows.Forms.Button btnFIFileName;
        private System.Windows.Forms.TextBox textFIFileName;
        private System.Windows.Forms.Button btnFIInstructionFileExists;
        private System.Windows.Forms.CheckBox cbFIInstructionFileExists;
        private System.Windows.Forms.Button btnFIUserStringSet;
        private System.Windows.Forms.Button btnFIUserStringGet;
        private System.Windows.Forms.TextBox textFIUserString;
        private System.Windows.Forms.Button btnFIKeywordUsageStringSet;
        private System.Windows.Forms.Button btnFIKeywordUsageStringGet;
        private System.Windows.Forms.TextBox textFIKeywordUsageString;
        private System.Windows.Forms.Button btnFIKeywordContentStringSet;
        private System.Windows.Forms.Button btnFIKeywordContentStringGet;
        private System.Windows.Forms.TextBox textFIKeywordContentString;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.NumericUpDown numFIUserStringIndex;
        private System.Windows.Forms.NumericUpDown numFIKeywordUsageStringIndex;
        private System.Windows.Forms.NumericUpDown numFIKeywordContentStringIndex;
        private System.Windows.Forms.Button btnFIInstructionFileName;
        private System.Windows.Forms.TextBox textFIInstructionFileName;
        private System.Windows.Forms.Button btnFIInstructionLength;
        private System.Windows.Forms.TextBox textFIInstructionLength;
        private System.Windows.Forms.Button btnFIIsEncrypted;
        private System.Windows.Forms.CheckBox cbFIIsEncrypted;
        private System.Windows.Forms.Button btnFIMACAddress;
        private System.Windows.Forms.TextBox textFIMACAddress;
        private System.Windows.Forms.Button btnFILastModifiedTime;
        private System.Windows.Forms.TextBox textFILastModifiedTime;
        private System.Windows.Forms.Button btnFILastModifiedDate;
        private System.Windows.Forms.TextBox textFILastModifiedDate;
        private System.Windows.Forms.Button btnFIKeywordUsageCount;
        private System.Windows.Forms.TextBox textFIKeywordUsageCount;
        private System.Windows.Forms.Button btnFIKeywordContentCount;
        private System.Windows.Forms.TextBox textFIKeywordContentCount;
        private System.Windows.Forms.Button btnFIJobNumber;
        private System.Windows.Forms.TextBox textFIJobNumber;
        private System.Windows.Forms.NumericUpDown numFIPriority;
        private System.Windows.Forms.Button btnFIPrioritySet;
        private System.Windows.Forms.Button btnFIPriorityGet;
        private System.Windows.Forms.Button btnFIRecordingStartTime;
        private System.Windows.Forms.TextBox textFIRecordingStartTime;
        private System.Windows.Forms.Button btnFIRecordingStartDate;
        private System.Windows.Forms.TextBox textFIRecordingStartDate;
        private System.Windows.Forms.Button btnFIRecordingEndTime;
        private System.Windows.Forms.TextBox textFIRecordingEndTime;
        private System.Windows.Forms.Button btnFIRecordingEndDate;
        private System.Windows.Forms.TextBox textFIRecordingEndDate;
        private System.Windows.Forms.Button btnFIProductId;
        private System.Windows.Forms.TextBox textFIProductId;
        private System.Windows.Forms.Button btnFIUserStringCount;
        private System.Windows.Forms.TextBox textFIUserStringCount;
        private System.Windows.Forms.Button btnFISpokenInstructionList;
        private System.Windows.Forms.TextBox textBarcodeModuleStatus;
        private System.Windows.Forms.Button btnBarcodeModuleStatusGet;
        private System.Windows.Forms.TextBox textDeviceStatus;
        private System.Windows.Forms.Button btnDeviceStatus;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textbstrFileName;
        private System.Windows.Forms.Button btnbstrFileNameBrowse;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.ComboBox cmbConvertAudioFormat;
        private System.Windows.Forms.CheckBox cbDelayTasks;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnDecrypt;
        private System.Windows.Forms.ComboBox cmbDecryptAudioFormat;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnNewFile;
        private System.Windows.Forms.ComboBox cmbNewFileCompressionMode;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox textNewFilePassword;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textDecryptbstrPassword;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox textbstrDestPath;
        private System.Windows.Forms.Button btnbstrDestPathBrowse;
        private System.Windows.Forms.Button btnStartDelayedTasks;
        private System.Windows.Forms.Button btnSeparateSpokenInstructions;
        private System.Windows.Forms.CheckBox cbSeparateSpokenInstructionsbCreateInstruction;
        private System.Windows.Forms.CheckBox cbSeparateSpokenInstructionsbCreateDictation;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Button btnbstrFileNameBrowseNewFile;
        private System.Windows.Forms.TextBox textbstrFileNameNewFile;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textDDPUK;
        private System.Windows.Forms.Button btnDDPukSet;
        private System.Windows.Forms.Button btnDDPUKSetGet;
        private System.Windows.Forms.CheckBox cbDDPUKSet;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.RichTextBox textLog;
        private System.Windows.Forms.Button btnDCEditCustomAudioFormat;
        private System.Windows.Forms.Panel fileListPanel;
        private System.Windows.Forms.Button btnGetIFileList;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Button btnDSMassStorageWriteProtectionSet;
        private System.Windows.Forms.Button btnDSMassStorageWriteProtectionGet;
        private System.Windows.Forms.CheckBox cbMassStorageWriteProtection;
        private System.Windows.Forms.Button btnDSObligatoryKeywordSelectionSet;
        private System.Windows.Forms.Button btnDSObligatoryKeywordSelectionGet;
        private System.Windows.Forms.CheckBox cbObligatoryKeywordSelection;
        private System.Windows.Forms.NumericUpDown numSliderJumpBackTime;
        private System.Windows.Forms.Button btnDSSliderJumpBackTimeSet;
        private System.Windows.Forms.Button btnDSSliderJumpBackTimeGet;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Button btnDSSPro256EnabledSet;
        private System.Windows.Forms.Button btnDSSPro256EnabledGet;
        private System.Windows.Forms.CheckBox cbDSSPro256Enabled;
        private System.Windows.Forms.Button ResetToFactoryDefaultsButton;
        private System.Windows.Forms.TabPage deviceSettings5TabPage;
        private System.Windows.Forms.Button EditMode_SetButton;
        private System.Windows.Forms.Button EditMode_GetButton;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox EditModeCombo;
        private System.Windows.Forms.Button FootpedalMode_SetButton;
        private System.Windows.Forms.Button FootpedalMode_GetButton;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.ComboBox FootpedalModeCombo;
        private System.Windows.Forms.Button Backlight_SetButton;
        private System.Windows.Forms.Button Backlight_GetButton;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.ComboBox BacklightCombo;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.NumericUpDown KeywordDisplayAreaStringsIndexNum;
        private System.Windows.Forms.Button SmartButtonConfiguration_SetButton;
        private System.Windows.Forms.Button SmartButtonConfiguration_GetButton;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.ComboBox SmartButtonConfiguration_RecordingStateCombo;
        private System.Windows.Forms.ComboBox SmartButtonConfiguration_ButtonIndexCombo;
        private System.Windows.Forms.ComboBox SmartButtonConfigurationCombo;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.ComboBox KeywordDisplayAreaStringsCombo;
        private System.Windows.Forms.Button KeywordDisplayAreaStrings_SetButton;
        private System.Windows.Forms.Button KeywordDisplayAreaStrings_GetButton;
        private System.Windows.Forms.Button IsAuthorPinListUsed_SetButton;
        private System.Windows.Forms.Button MinusButtonEnabled_SetButton;
        private System.Windows.Forms.Button PlusButtonEnabled_SetButton;
        private System.Windows.Forms.Button IsAuthorPinListUsed_GetButton;
        private System.Windows.Forms.Button MinusButtonEnabled_GetButton;
        private System.Windows.Forms.Button PlusButtonEnabled_GetButton;
        private System.Windows.Forms.CheckBox IsAuthorPinListUsedCheck;
        private System.Windows.Forms.CheckBox MinusButtonEnabledCheck;
        private System.Windows.Forms.CheckBox PlusButtonEnabledCheck;
        private System.Windows.Forms.TabPage deviceSettings6TabPage;
        private System.Windows.Forms.Button ActiveRecordingProfile_SetButton;
        private System.Windows.Forms.Button ActiveRecordingProfile_GetButton;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.ComboBox ActiveRecordingProfileCombo;
        private System.Windows.Forms.Button RecordingProfile_GetButton;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.ComboBox RecordingProfileCombo;
        private System.Windows.Forms.GroupBox RecordingProfileGroup;
        private System.Windows.Forms.Button MicrophoneDirectivityOnRecordingProfile_SetButton;
        private System.Windows.Forms.Button MicrophoneSensitivityOnRecordingProfile_SetButton;
        private System.Windows.Forms.Button MicrophoneDirectivityOnRecordingProfile_GetButton;
        private System.Windows.Forms.Button MicrophoneSensitivityOnRecordingProfile_GetButton;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.ComboBox MicrophoneDirectivityOnRecordingProfile_DevicePositionIndexCombo;
        private System.Windows.Forms.ComboBox MicrophoneDirectivityOnRecordingProfileCombo;
        private System.Windows.Forms.ComboBox MicrophoneSensitivityOnRecordingProfileCombo;
        private System.Windows.Forms.Button RecordingModeOnRecordingProfile_SetButton;
        private System.Windows.Forms.Button RecordingModeOnRecordingProfile_GetButton;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.ComboBox RecordingModeOnRecordingProfileCombo;
        private System.Windows.Forms.TextBox textDCMaxKeywordLength;
        private System.Windows.Forms.Button btnDCMaxKeywordLengthGet;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Button WelcomeScreenHashGetButton;
        private System.Windows.Forms.TextBox WelcomeScreenHashTxt;
        private System.Windows.Forms.Button btnDisplaySymbolsEnabledSet;
        private System.Windows.Forms.Button btnDisplaySymbolsEnabledGet;
        private System.Windows.Forms.CheckBox cbDisplaySymbolsEnabled;
    }
}

