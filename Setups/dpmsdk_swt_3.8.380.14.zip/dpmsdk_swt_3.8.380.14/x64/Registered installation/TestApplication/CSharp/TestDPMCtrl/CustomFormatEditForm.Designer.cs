﻿namespace TestDPMCtrl
{
    partial class CustomFormatEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose ();
            }
            base.Dispose (disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ()
        {
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label label8;
            System.Windows.Forms.Label label9;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomFormatEditForm));
            this.cbExtraTxt = new System.Windows.Forms.TextBox();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.OKBtn = new System.Windows.Forms.Button();
            this.wFormatTagNumCtrl = new System.Windows.Forms.NumericUpDown();
            this.nChannelsNumCtrl = new System.Windows.Forms.NumericUpDown();
            this.nSamplesPerSecNumCtrl = new System.Windows.Forms.NumericUpDown();
            this.nAvgBytesPerSecNumCtrl = new System.Windows.Forms.NumericUpDown();
            this.nBlockAlignNumCtrl = new System.Windows.Forms.NumericUpDown();
            this.wBitsPerSampleNumCtrl = new System.Windows.Forms.NumericUpDown();
            this.cbSizeNumCtrl = new System.Windows.Forms.NumericUpDown();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.wFormatTagNumCtrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nChannelsNumCtrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSamplesPerSecNumCtrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nAvgBytesPerSecNumCtrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBlockAlignNumCtrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wBitsPerSampleNumCtrl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbSizeNumCtrl)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 15);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(66, 13);
            label1.TabIndex = 0;
            label1.Text = "wFormatTag";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(12, 41);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(57, 13);
            label2.TabIndex = 2;
            label2.Text = "nChannels";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(12, 67);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(88, 13);
            label3.TabIndex = 4;
            label3.Text = "nSamplesPerSec";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(12, 93);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(93, 13);
            label4.TabIndex = 6;
            label4.Text = "nAvgBytesPerSec";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(12, 119);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(63, 13);
            label5.TabIndex = 8;
            label5.Text = "nBlockAlign";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(12, 145);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(83, 13);
            label6.TabIndex = 10;
            label6.Text = "wBitsPerSample";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(12, 171);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(39, 13);
            label7.TabIndex = 12;
            label7.Text = "cbSize";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(12, 197);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(43, 13);
            label8.TabIndex = 14;
            label8.Text = "cbExtra";
            // 
            // label9
            // 
            label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            label9.Location = new System.Drawing.Point(114, 218);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(428, 73);
            label9.TabIndex = 16;
            label9.Text = resources.GetString("label9.Text");
            // 
            // cbExtraTxt
            // 
            this.cbExtraTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbExtraTxt.Location = new System.Drawing.Point(114, 195);
            this.cbExtraTxt.MaxLength = 64;
            this.cbExtraTxt.Name = "cbExtraTxt";
            this.cbExtraTxt.Size = new System.Drawing.Size(428, 20);
            this.cbExtraTxt.TabIndex = 15;
            // 
            // CancelBtn
            // 
            this.CancelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelBtn.Location = new System.Drawing.Point(467, 294);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 18;
            this.CancelBtn.Text = "Cancel";
            this.CancelBtn.UseVisualStyleBackColor = true;
            // 
            // OKBtn
            // 
            this.OKBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OKBtn.Location = new System.Drawing.Point(388, 294);
            this.OKBtn.Name = "OKBtn";
            this.OKBtn.Size = new System.Drawing.Size(75, 23);
            this.OKBtn.TabIndex = 17;
            this.OKBtn.Text = "OK";
            this.OKBtn.UseVisualStyleBackColor = true;
            this.OKBtn.Click += new System.EventHandler(this.OKBtn_Click);
            // 
            // wFormatTagNumCtrl
            // 
            this.wFormatTagNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.wFormatTagNumCtrl.Location = new System.Drawing.Point(114, 12);
            this.wFormatTagNumCtrl.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.wFormatTagNumCtrl.Minimum = new decimal(new int[] {
            32768,
            0,
            0,
            -2147483648});
            this.wFormatTagNumCtrl.Name = "wFormatTagNumCtrl";
            this.wFormatTagNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.wFormatTagNumCtrl.TabIndex = 1;
            // 
            // nChannelsNumCtrl
            // 
            this.nChannelsNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.nChannelsNumCtrl.Location = new System.Drawing.Point(114, 39);
            this.nChannelsNumCtrl.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.nChannelsNumCtrl.Minimum = new decimal(new int[] {
            32768,
            0,
            0,
            -2147483648});
            this.nChannelsNumCtrl.Name = "nChannelsNumCtrl";
            this.nChannelsNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.nChannelsNumCtrl.TabIndex = 3;
            // 
            // nSamplesPerSecNumCtrl
            // 
            this.nSamplesPerSecNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.nSamplesPerSecNumCtrl.Location = new System.Drawing.Point(114, 65);
            this.nSamplesPerSecNumCtrl.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.nSamplesPerSecNumCtrl.Minimum = new decimal(new int[] {
            -2147483648,
            0,
            0,
            -2147483648});
            this.nSamplesPerSecNumCtrl.Name = "nSamplesPerSecNumCtrl";
            this.nSamplesPerSecNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.nSamplesPerSecNumCtrl.TabIndex = 5;
            // 
            // nAvgBytesPerSecNumCtrl
            // 
            this.nAvgBytesPerSecNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.nAvgBytesPerSecNumCtrl.Location = new System.Drawing.Point(114, 91);
            this.nAvgBytesPerSecNumCtrl.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.nAvgBytesPerSecNumCtrl.Minimum = new decimal(new int[] {
            -2147483648,
            0,
            0,
            -2147483648});
            this.nAvgBytesPerSecNumCtrl.Name = "nAvgBytesPerSecNumCtrl";
            this.nAvgBytesPerSecNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.nAvgBytesPerSecNumCtrl.TabIndex = 7;
            // 
            // nBlockAlignNumCtrl
            // 
            this.nBlockAlignNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.nBlockAlignNumCtrl.Location = new System.Drawing.Point(114, 117);
            this.nBlockAlignNumCtrl.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.nBlockAlignNumCtrl.Minimum = new decimal(new int[] {
            32768,
            0,
            0,
            -2147483648});
            this.nBlockAlignNumCtrl.Name = "nBlockAlignNumCtrl";
            this.nBlockAlignNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.nBlockAlignNumCtrl.TabIndex = 9;
            // 
            // wBitsPerSampleNumCtrl
            // 
            this.wBitsPerSampleNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.wBitsPerSampleNumCtrl.Location = new System.Drawing.Point(114, 143);
            this.wBitsPerSampleNumCtrl.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.wBitsPerSampleNumCtrl.Minimum = new decimal(new int[] {
            32768,
            0,
            0,
            -2147483648});
            this.wBitsPerSampleNumCtrl.Name = "wBitsPerSampleNumCtrl";
            this.wBitsPerSampleNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.wBitsPerSampleNumCtrl.TabIndex = 11;
            // 
            // cbSizeNumCtrl
            // 
            this.cbSizeNumCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cbSizeNumCtrl.Location = new System.Drawing.Point(114, 169);
            this.cbSizeNumCtrl.Maximum = new decimal(new int[] {
            32768,
            0,
            0,
            0});
            this.cbSizeNumCtrl.Minimum = new decimal(new int[] {
            32768,
            0,
            0,
            -2147483648});
            this.cbSizeNumCtrl.Name = "cbSizeNumCtrl";
            this.cbSizeNumCtrl.Size = new System.Drawing.Size(428, 20);
            this.cbSizeNumCtrl.TabIndex = 13;
            // 
            // CustomFormatEditForm
            // 
            this.AcceptButton = this.OKBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CancelBtn;
            this.ClientSize = new System.Drawing.Size(554, 329);
            this.Controls.Add(this.cbSizeNumCtrl);
            this.Controls.Add(this.wBitsPerSampleNumCtrl);
            this.Controls.Add(this.nBlockAlignNumCtrl);
            this.Controls.Add(this.nAvgBytesPerSecNumCtrl);
            this.Controls.Add(this.nSamplesPerSecNumCtrl);
            this.Controls.Add(this.nChannelsNumCtrl);
            this.Controls.Add(this.wFormatTagNumCtrl);
            this.Controls.Add(label9);
            this.Controls.Add(this.OKBtn);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(label8);
            this.Controls.Add(label7);
            this.Controls.Add(label6);
            this.Controls.Add(label5);
            this.Controls.Add(label4);
            this.Controls.Add(label3);
            this.Controls.Add(label2);
            this.Controls.Add(label1);
            this.Controls.Add(this.cbExtraTxt);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomFormatEditForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Custom Format";
            ((System.ComponentModel.ISupportInitialize)(this.wFormatTagNumCtrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nChannelsNumCtrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nSamplesPerSecNumCtrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nAvgBytesPerSecNumCtrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nBlockAlignNumCtrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wBitsPerSampleNumCtrl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbSizeNumCtrl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox cbExtraTxt;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.Button OKBtn;
        private System.Windows.Forms.NumericUpDown wFormatTagNumCtrl;
        private System.Windows.Forms.NumericUpDown nChannelsNumCtrl;
        private System.Windows.Forms.NumericUpDown nSamplesPerSecNumCtrl;
        private System.Windows.Forms.NumericUpDown nAvgBytesPerSecNumCtrl;
        private System.Windows.Forms.NumericUpDown nBlockAlignNumCtrl;
        private System.Windows.Forms.NumericUpDown wBitsPerSampleNumCtrl;
        private System.Windows.Forms.NumericUpDown cbSizeNumCtrl;
    }
}