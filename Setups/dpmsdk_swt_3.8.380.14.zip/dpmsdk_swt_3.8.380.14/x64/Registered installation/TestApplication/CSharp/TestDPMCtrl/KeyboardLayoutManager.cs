﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Microsoft.Win32;

namespace TestDPMCtrl
{
    public static class KeyboardLayoutManager
    {
        private static Hashtable _KeyboardLayouts = new Hashtable();

        public static Hashtable KeyboardLayouts
        {
            get
            {
                return _KeyboardLayouts;
            }
        }

        static KeyboardLayoutManager ()
        {
            // enumerate keyboard layouts from registry
            RegistryKey key = Registry.LocalMachine;
            key = key.OpenSubKey("SYSTEM");
            key = key.OpenSubKey("CurrentControlSet");
            key = key.OpenSubKey("Control");
            key = key.OpenSubKey("Keyboard layouts");
            foreach (string Keyname in key.GetSubKeyNames())
            {
                RegistryKey klkey = key.OpenSubKey(Keyname);
                string LayoutText = String.Format("{0} ({1})", klkey.GetValue("Layout Text").ToString(), Keyname);
                _KeyboardLayouts.Add(LayoutText, Keyname.ToLower());
            }
        }
    }
}
