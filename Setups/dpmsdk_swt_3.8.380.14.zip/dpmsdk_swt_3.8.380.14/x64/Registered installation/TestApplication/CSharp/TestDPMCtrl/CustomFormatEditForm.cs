﻿using System;
using System.Windows.Forms;
using PIA.DpmCtrlLib;
using System.Text;
using System.Collections.Generic;

namespace TestDPMCtrl
{
    public partial class CustomFormatEditForm : Form
    {
        public CustomFormatEditForm (dpmWAVEFORMATEX audioFormat)
        {
            InitializeComponent ();
            Init (audioFormat);
        }

        private void Init(dpmWAVEFORMATEX audioFormat)
        {
            wFormatTagNumCtrl.Value = audioFormat.wFormatTag;
            nChannelsNumCtrl.Value = audioFormat.nChannels;
            nSamplesPerSecNumCtrl.Value = audioFormat.nSamplesPerSec;
            nAvgBytesPerSecNumCtrl.Value = audioFormat.nAvgBytesPerSec;
            nBlockAlignNumCtrl.Value = audioFormat.nBlockAlign;
            wBitsPerSampleNumCtrl.Value = audioFormat.wBitsPerSample;
            cbSizeNumCtrl.Value = audioFormat.cbSize;

            if (audioFormat.cbExtra != null)
            {
                StringBuilder s = new StringBuilder ();
                foreach (byte b in audioFormat.cbExtra)
                {
                    s.AppendFormat ("{0:X2}", b);
                }
                cbExtraTxt.Text = s.ToString ();
            }
        }

        private bool ValidateAndSave ()
        {
            _Result = new dpmWAVEFORMATEX();

            _Result.wFormatTag = Convert.ToInt16 (wFormatTagNumCtrl.Value);
            _Result.nChannels = Convert.ToInt16 (nChannelsNumCtrl.Value);
            _Result.nSamplesPerSec = Convert.ToInt32 (nSamplesPerSecNumCtrl.Value);
            _Result.nAvgBytesPerSec = Convert.ToInt32 (nAvgBytesPerSecNumCtrl.Value);
            _Result.nBlockAlign = Convert.ToInt16 (nBlockAlignNumCtrl.Value);
            _Result.wBitsPerSample = Convert.ToInt16 (wBitsPerSampleNumCtrl.Value);
            _Result.cbSize = Convert.ToInt16 (cbSizeNumCtrl.Value);

            if (cbExtraTxt.TextLength == 0)
            {
                _Result.cbExtra = null;
            }
            else
            {
                if (cbExtraTxt.TextLength % 2 != 0)
                {
                    MessageBox.Show (this, "Length of cbExtra should be even", "TestDPMCtrl test");
                    return false;
                }

                int count = cbExtraTxt.TextLength / 2;

                if (count > 32)
                {
                    MessageBox.Show (this, "Length of cbExtra should not be more than 32 bytes", "SmExAudio test");
                    return false;
                }

                _Result.cbExtra = new byte[32];
                for (int i = 0; i < count; i++)
                {
                    try
                    {
                        _Result.cbExtra[i] = Convert.ToByte (cbExtraTxt.Text.Substring (i * 2, 2), 16);
                    }
                    catch (FormatException)
                    {
                        MessageBox.Show (this, "Invalid hexadecimal character in cbExtra", "SmExAudio test");
                        return false;
                    }
                }
            }

            return true;
        }

        private void OKBtn_Click (object sender, EventArgs e)
        {
            if (ValidateAndSave ())
            {
                DialogResult = DialogResult.OK;
                Close ();
            }
        }

        public dpmWAVEFORMATEX Result
        {
            get { return _Result; }
        }
        private dpmWAVEFORMATEX _Result;


    }
}
