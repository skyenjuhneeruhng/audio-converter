﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TestDPMCtrl
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Mainform.OnThreadException);
            try
            {
                Application.Run(new Mainform());
            }
            catch (Exception e)
            {
                MessageBox.Show(String.Format("Exception: {0}", e.Message), "TestDPMCtrl", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
