------------------------------------------------------------------
                           README.TXT
                 SpeechADPCMDecode V3.8 Build 380.14
   
------------------------------------------------------------------
   Copyright (c) 2016 Speech Processing Solutions GmbH
------------------------------------------------------------------

This file contains last minute information on the software.

1. Supported operating systems
==============================
- Windows 7 x64 SP1
- Windows Server 2008 R2
    Desktop Experience is required

2. SpeechADPCMDecode
====================

Description:
------------
SpeechADPCMDecode.exe is a command line tool to convert Speech ADPCM WAV files to
PCM WAV files. The destination format is 16kHz 16bit mono PCM.

Installation:
-------------
1. Install ADPCM codec using SpeechADPCMsetup.exe
2. Copy SpeechADPCMDecode.exe, SpeechADPCMDecode.ini and XPSPLOG.dll to destination folder

Usage:
------
Specify the path of the source ADPCM WAV file and the destination PCM WAV file.
If a path contains space then you must enclose the path within quotation marks.
  SpeechADPCMDecode.exe source_file_path destination_file_path

Sample:
  SpeechADPCMDecode.exe "c:\source\adpcm.wav" "c:\destination\converted pcm.wav"

------------------------------------------------------------------
Philips and the Philips� Shield Emblem are registered trademarks of 
Koninklijke Philips Electronics N.V. and are used by Speech Processing Solutions GmbH 
under license from Koninklijke Philips Electronics N.V.

Windows XP, Windows 7, Windows 8, Windows Server 2008 and Windows Server 2012 are 
registered trademarks of Microsoft Corporation. All other names are 
trademarks, registered trademarks or service marks of their 
respective owner.


